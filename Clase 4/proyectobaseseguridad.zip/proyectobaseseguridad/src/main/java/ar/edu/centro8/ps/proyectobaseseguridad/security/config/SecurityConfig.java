package ar.edu.centro8.ps.proyectobaseseguridad.security.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import static org.springframework.security.config.Customizer.withDefaults;

// import static org.springframework.security.config.withDefaults;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import java.util.Collections;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

// Codigo para usuario y contraseña definidos por el usuario

@Configuration
@EnableWebSecurity
public class SecurityConfig {
    @Value("${SS_USER}")
    private String user;

    @Value("${SS_PASSWORD}")
    private String password;

    // OPCIÓN 1: Formulario por defecto (Bean completo - Descomentar para probar)
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        return http
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/holanoseg").permitAll()
                        .anyRequest().authenticated())
                .formLogin(withDefaults())
                .logout(logout -> logout
                        .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
                        .permitAll())
                .build();
    }

    // OPCIÓN 2: Formulario con redirección personalizada a /holaseg (Bean completo
    // - Descomentar para probar)
    // @Bean
    // public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
    // return http
    // .authorizeHttpRequests(auth -> auth
    // .requestMatchers("/holanoseg").permitAll()
    // .anyRequest().authenticated())
    // .formLogin(form -> form
    // .defaultSuccessUrl("/holaseg", true))
    // .logout(logout -> logout
    // .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
    // .permitAll())
    // .build();
    // }

    // OPCIÓN 3: Alternar entre login por defecto y personalizado comentando una
    // sola línea (Descomentar para probar)
    // @Bean
    // public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
    // return http
    // .authorizeHttpRequests(auth -> auth
    // .requestMatchers("/holanoseg").permitAll()
    // .anyRequest().authenticated())
    // // Alternativa A: Login por defecto
    // // .formLogin(withDefaults())

    // // Alternativa B: Login con redirección personalizada
    // .formLogin(form -> form.defaultSuccessUrl("/holaseg", true))

    // .logout(logout -> logout
    // .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
    // .permitAll())
    // .build();
    // }

    // OPCIÓN 4: Formulario y Logout 100% en Español con formulario personalizado
    // (Activo)
    // @Bean
    // public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
    // return http
    // // Si prefieres desactivar CSRF para pruebas locales sin token en el HTML:
    // // .csrf(csrf -> csrf.disable())
    // .authorizeHttpRequests(auth -> auth
    // .requestMatchers("/holanoseg", "/login").permitAll()
    // .anyRequest().authenticated())
    // .formLogin(form -> form
    // .loginPage("/login") // Vista personalizada en español
    // .defaultSuccessUrl("/holaseg", true) // Redirección al ingresar con éxito
    // .failureUrl("/login?error=true") // Redirección en caso de error de
    // credenciales
    // .permitAll())
    // .logout(logout -> logout
    // .logoutRequestMatcher(new AntPathRequestMatcher("/logout")) // Acepta GET y
    // POST desde la barra de direcciones o enlaces
    // .logoutSuccessUrl("/login?logout=true") // Redirección al cerrar sesión en
    // español
    // .permitAll())
    // .build();
    // }

    @Bean
    public UserDetailsService userDetailsService() {
        UserDetails user = User.withUsername(this.user)
                .password(passwordEncoder().encode(this.password))
                .roles("USER")
                .build();

        return new InMemoryUserDetailsManager(Collections.singleton(user));
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
