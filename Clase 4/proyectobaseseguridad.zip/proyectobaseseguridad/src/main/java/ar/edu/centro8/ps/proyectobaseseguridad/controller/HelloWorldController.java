package ar.edu.centro8.ps.proyectobaseseguridad.controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorldController {

    @GetMapping("/holaseg")
    public String secHelloWorld() {
        return "<h1>Hola Mundo con seguridad</h1><p><a href='/logout'>Cerrar sesión</a></p>";
    }

    @GetMapping("/holanoseg")
    public String noSecHelloWorld() {
        
        return "Hola mundo sin seguridad";
    }

}


