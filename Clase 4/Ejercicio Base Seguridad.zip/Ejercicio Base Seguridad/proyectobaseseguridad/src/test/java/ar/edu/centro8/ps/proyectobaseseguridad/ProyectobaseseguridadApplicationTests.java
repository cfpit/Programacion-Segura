package ar.edu.centro8.ps.proyectobaseseguridad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectobaseseguridadApplicationTests {

	@Test
	void contextLoads() {
	}

}
