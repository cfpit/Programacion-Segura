package ar.edu.centro8.ps.proyectobaseseguridad.security.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import static org.springframework.security.config.Customizer.withDefaults;


// import static org.springframework.security.config.withDefaults;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import java.util.Collections;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

// Codigo para usuario(user) y contraseña(ofrecida por el IDE) por defecto
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain (HttpSecurity httpSecurity) throws Exception {
        return httpSecurity
                .authorizeHttpRequests(authorize -> authorize
                    .requestMatchers("/holanoseg").permitAll()
                    .anyRequest().authenticated())
                
                .formLogin(withDefaults())
                .build();
    }
}





// Codigo para usuario(user) y contraseña(ofrecida por el IDE) por defecto

// @Configuration
// @EnableWebSecurity
// public class SecurityConfig {
//     @Value("${SS_USER}")
//     private String user;
    
//     @Value("${SS_PASSWORD}")
//     private String password;
    
//     @Bean
//     public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
//         return http
//             .authorizeHttpRequests(auth -> auth
//                 .requestMatchers("/holanoseg").permitAll()
//                 .anyRequest().authenticated()
//             )
//             .formLogin(withDefaults())
//             .logout(withDefaults())
//             .userDetailsService(userDetailsService())  // Configura el usuario
//             .build();
//     }
    
//     @Bean
//     public UserDetailsService userDetailsService() {
//         UserDetails user = User.withUsername(this.user)
//             .password(passwordEncoder().encode(this.password))
//             .roles("USER")
//             .build();
            
//         return new InMemoryUserDetailsManager(Collections.singleton(user));
//     }

//     @Bean
//     public PasswordEncoder passwordEncoder() {
//         return new BCryptPasswordEncoder();
//     }
// }











