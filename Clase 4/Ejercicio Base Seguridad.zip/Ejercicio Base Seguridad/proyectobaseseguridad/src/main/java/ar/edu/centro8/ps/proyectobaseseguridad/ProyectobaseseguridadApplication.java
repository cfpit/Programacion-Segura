package ar.edu.centro8.ps.proyectobaseseguridad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.Environment;

@SpringBootApplication
public class ProyectobaseseguridadApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectobaseseguridadApplication.class, args);


		// ConfigurableApplicationContext context = SpringApplication.run(ProyectobaseseguridadApplication.class, args);
        // Environment env = context.getEnvironment();
        
        // // Verificar las variables
        // System.out.println("SS_USER: " + env.getProperty("SS_USER"));
        // System.out.println("SS_PASSWORD: " + env.getProperty("SS_PASSWORD"));
	}

}
