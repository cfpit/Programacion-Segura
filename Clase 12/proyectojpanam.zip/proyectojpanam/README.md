# Proyecto JPA: Relación Muchos a Muchos (@ManyToMany)

Este proyecto es una aplicación desarrollada en **Spring Boot 3** con **Spring Data JPA**, **Hibernate** y **MySQL** que modela y gestiona una relación de cardinalidad **Muchos a Muchos (N a M)** entre dos entidades: `Estudiante` y `Curso`.

Adicionalmente, se desacopló la carga inicial por consola para exponer una **API REST interactiva** testeable mediante **Bruno**.

---

## 1. Explicación Detallada de la Relación `@ManyToMany`

En una relación Muchos a Muchos (N a M):
* Un **Estudiante** puede inscribirse en **varios Cursos**.
* Un **Curso** puede tener inscriptos a **varios Estudiantes**.

Las bases de datos relacionales no pueden almacenar colecciones directamente en una sola columna; por ello, la relación se implementa físicamente mediante una **tabla intermedia** o de unión (`estudiante_curso`).

### A. La Entidad Propietaria (Owner Side): `Estudiante`

```java
@Entity
public class Estudiante {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nombre", nullable = false)
    private String nombre;

    @com.fasterxml.jackson.annotation.JsonIgnoreProperties("estudiantes")
    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.MERGE)
    @JoinTable(
        name = "estudiante_curso", 
        joinColumns = @JoinColumn(name = "id_estudiante", referencedColumnName = "id"),
        inverseJoinColumns = @JoinColumn(name = "id_curso", referencedColumnName = "id")    
    )
    private List<Curso> cursos;
}
```

#### Desglose de cada término y anotación:

1. **`@ManyToMany`**:
   Indica que existe una relación de muchos a muchos entre `Estudiante` y `Curso`.

2. **`fetch = FetchType.EAGER`**:
   Define la estrategia de carga. 
   * `EAGER` (ansiosa): Al cargar un estudiante de la base de datos, JPA realiza un `JOIN` y carga automáticamente todos los cursos asociados al mismo en memoria.
   * `LAZY` (perezosa): Solo traería la lista cuando explícitamente se acceda a ella (`getNombre()`, etc.).

3. **`cascade = CascadeType.MERGE`**:
   Controla la propagación de operaciones de persistencia.
   * `MERGE` propaga la acción de actualización: si modificas un estudiante con cursos asociados y lo guardas, los cambios y asociaciones se actualizan en cascada.
   * Se usa `MERGE` en lugar de `ALL` para evitar borrar accidentalmente un curso de la base de datos si se elimina a un estudiante (`REMOVE` no se propaga).

4. **`@JoinTable`**:
   Define la tabla intermedia que materializa la relación en la base de datos MySQL.
   * **`name = "estudiante_curso"`**: Nombre que tendrá la tabla intermedia en MySQL.
   * **`joinColumns`**: Especifica la columna de clave foránea (FK) que apunta a la entidad actual (`Estudiante`). En este caso, la columna `id_estudiante` referencia a la PK `id` de `Estudiante`.
   * **`inverseJoinColumns`**: Especifica la columna de clave foránea (FK) que apunta a la otra entidad (`Curso`). Aquí, la columna `id_curso` referencia a la PK `id` de `Curso`.

5. **`@JsonIgnoreProperties("estudiantes")`**:
   Evita la **recursión infinita (bucle cíclico)** al serializar a formato JSON. Sin esta anotación, `Estudiante` intentaría imprimir `cursos`, y cada `Curso` intentaría imprimir sus `estudiantes`, provocando un error `StackOverflowError`.

---

### B. La Entidad Inversa (Inverse / Non-owning Side): `Curso`

```java
@Entity
public class Curso {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nombre", nullable = false)
    private String nombre;

    @com.fasterxml.jackson.annotation.JsonIgnoreProperties("cursos")
    @ManyToMany(mappedBy = "cursos")
    private List<Estudiante> estudiantes;
}
```

#### Desglose de términos:
1. **`mappedBy = "cursos"`**:
   * Indica a JPA que esta entidad **no es la dueña** de la relación ni define la tabla intermedia.
   * Apunta al atributo `cursos` de la clase `Estudiante`.
   * Gracias a `mappedBy`, Hibernate sabe que ambas entidades están enlazadas a través de la misma tabla intermedia `estudiante_curso` y no intenta crear una segunda tabla cruzada innecesaria.

---

## 2. Explicación de los Controladores (Controllers)

El proyecto cuenta con dos controladores REST: `CursoController` y `EstudianteController`.

### `CursoController` (`/cursos`)
Gestiona el catálogo de asignaturas disponibles:
* **`GET /cursos`**: Obtiene y lista todos los cursos registrados en la base de datos.
* **`GET /cursos/{id}`**: Busca un curso por su clave primaria. Si existe responde con `200 OK`; si no, con `404 Not Found`.
* **`POST /cursos`**: Recibe un objeto JSON con el nombre del curso y lo persiste mediante `cursoRepository.save(curso)`. Retorna código `201 Created`.

---

### `EstudianteController` (`/estudiantes`)
Gestiona los estudiantes y su vinculación con los cursos:
* **`GET /estudiantes`**: Lista todos los estudiantes junto con el detalle de los cursos a los que están inscriptos.
* **`GET /estudiantes/{id}`**: Retorna los datos de un estudiante específico junto con su lista de cursos.
* **`POST /estudiantes`**: Registra un nuevo estudiante en la base de datos.
* **`PUT /estudiantes/{estudianteId}/cursos/{cursoId}`**: Endpoint para crear el vínculo N a M entre un estudiante y un curso.

---

## 3. ¿Qué son y qué hacen los `PUT` en las Relaciones en Bruno?

En la carpeta **`bruno/Relaciones/`** existen peticiones de tipo **PUT**, por ejemplo:
```http
PUT http://localhost:8080/estudiantes/1/cursos/2
```

### ¿Por qué se utiliza el método HTTP `PUT`?
* En la arquitectura REST, **`PUT`** se utiliza para **actualizar o modificar el estado de un recurso existente**.
* Cuando asocias un estudiante a un curso, no estás creando un estudiante nuevo ni un curso nuevo (para eso existe `POST`). Estás **modificando la colección de cursos que le pertenecen al estudiante**, lo cual inserta una fila en la tabla intermedia `estudiante_curso`.

### ¿Cómo funciona internamente el Endpoint?
```java
@PutMapping("/{estudianteId}/cursos/{cursoId}")
public ResponseEntity<?> asociarCurso(@PathVariable Long estudianteId, @PathVariable Long cursoId) {
    return estudianteRepository.findById(estudianteId).map(estudiante -> {
        return cursoRepository.findById(cursoId).map(curso -> {
            if (!estudiante.getCursos().contains(curso)) {
                estudiante.getCursos().add(curso);
                estudianteRepository.save(estudiante); // Inserta en tabla intermedia
            }
            return ResponseEntity.ok(estudiante);
        }).orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }).orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
}
```
1. Busca el `Estudiante` por su `id` (`estudianteId`).
2. Busca el `Curso` por su `id` (`cursoId`).
3. Agrega el `Curso` a la lista `cursos` del estudiante.
4. Al hacer `estudianteRepository.save(estudiante)`, JPA ejecuta automáticamente la sentencia SQL:
   ```sql
   INSERT INTO estudiante_curso (id_estudiante, id_curso) VALUES (1, 2);
   ```
5. Devuelve el estudiante actualizado con sus cursos asociados.

---

## 4. Guía de Ejecución y Pruebas con Bruno

### 1. Iniciar la aplicación
Ejecuta con Java 17 desde terminal:
```powershell
$env:JAVA_HOME="C:\Program Files\Java\jdk-17"; .\mvnw.cmd spring-boot:run
```
*(O usa el botón derecho **"Run Java"** en `ProyectojpanamApplication.java` con las configuraciones ya creadas).*

### 2. Abrir la Colección en Bruno
1. Abre la aplicación **Bruno**.
2. Presiona **"Open Collection"**.
3. Selecciona la carpeta:
   `c:\Users\smata\OneDrive\Documentos\Nueva carpeta\ps\RelacionNaM\proyectojpanam\bruno`

### 3. Orden de ejecución sugerido en Bruno
1. **`Cursos -> Crear Curso Java`** (POST `/cursos`)
2. **`Cursos -> Crear Curso Python`** (POST `/cursos`)
3. **`Estudiantes -> Crear Estudiante Juan`** (POST `/estudiantes`)
4. **`Estudiantes -> Crear Estudiante Maria`** (POST `/estudiantes`)
5. **`Relaciones -> Asociar Juan a Java`** (PUT `/estudiantes/1/cursos/1`)
6. **`Relaciones -> Asociar Juan a Python`** (PUT `/estudiantes/1/cursos/2`)
7. **`Relaciones -> Asociar Maria a Java`** (PUT `/estudiantes/2/cursos/1`)
8. **`Estudiantes -> Listar Estudiantes`** (GET `/estudiantes`) para verificar todas las relaciones creadas.

---

## Diferencia entre `@JsonIgnoreProperties` vs `@JsonManagedReference` y `@JsonBackReference`

Ambas opciones se utilizan en Jackson (Spring Boot / JPA) para resolver el problema de la **recursión infinita (bucle infinito)** al serializar relaciones bidireccionales (`@OneToMany` / `@ManyToOne`, `@ManyToMany`), pero funcionan de maneras distintas:

### 1. `@JsonManagedReference` y `@JsonBackReference` (Padre / Hijo)

Trabajan **en pareja** y están diseñadas específicamente para relaciones bidireccionales jerárquicas:

* **`@JsonManagedReference`**: Se coloca en el lado "propietario" o padre (por ejemplo, en `List<Pedido> pedidos` dentro de `Cliente`). **Este atributo SÍ se serializa** a JSON normalmente.
* **`@JsonBackReference`**: Se coloca en el lado hijo o inverso (por ejemplo, en `Cliente cliente` dentro de `Pedido`). **Este atributo se OMITE** en la serialización hacia JSON para cortar el ciclo, pero Jackson lo restaura automáticamente al deserializar (reconstruye la referencia del objeto).

#### Ejemplo:
```java
// Entidad Padre
public class Cliente {
    private Long id;
    private String nombre;

    @JsonManagedReference
    @OneToMany(mappedBy = "cliente")
    private List<Pedido> pedidos;
}

// Entidad Hija
public class Pedido {
    private Long id;
    private Double total;

    @JsonBackReference
    @ManyToOne
    @JoinColumn(name = "cliente_id")
    private Cliente cliente;
}
```

* **Comportamiento**: Al serializar `Cliente`, muestra sus pedidos.
* **Limitación**: Si consultas un `Pedido` directamente (ej. `GET /pedidos/1`), el campo `cliente` no aparecerá en el JSON porque `@JsonBackReference` nunca se serializa.

---

### 2. `@JsonIgnoreProperties`

Es una anotación más flexible y general. Permite indicar explícitamente qué campos o propiedades anidadas deben ignorarse al serializar/deserializar.

* Se coloca a nivel de clase o sobre el atributo.
* Para cortar bucles bidireccionales, se le indica al campo que ignore la propiedad inversa que vuelve a apuntar a sí mismo.

#### Ejemplo:
```java
public class Cliente {
    private Long id;
    private String nombre;

    @OneToMany(mappedBy = "cliente")
    @JsonIgnoreProperties("cliente") // Dentro de cada Pedido, ignora el campo 'cliente'
    private List<Pedido> pedidos;
}

public class Pedido {
    private Long id;
    private Double total;

    @ManyToOne
    @JoinColumn(name = "cliente_id")
    @JsonIgnoreProperties("pedidos") // Dentro del Cliente, ignora la lista 'pedidos'
    private Cliente cliente;
}
```

* **Ventaja clave**: Si consultas un `Cliente`, obtienes sus `pedidos`. Si consultas un `Pedido` directamente, **también obtienes su `cliente`** (únicamente se corta la recursión para que ese `cliente` no vuelva a incluir `pedidos`).
* **Otros usos comunes**: Ignorar proxies de Hibernate agregando `@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})` a nivel de entidad.

---

### Resumen Comparativo

| Característica | `@JsonManagedReference` / `@JsonBackReference` | `@JsonIgnoreProperties` |
| :--- | :--- | :--- |
| **Uso principal** | Específico para relaciones bidireccionales padre-hijo. | General (ignorar campos directos, bucles recursivos o proxies de Hibernate). |
| **Configuración** | Requiere dos anotaciones (una en cada lado). | Se puede usar en un solo lado o en ambos especificando los nombres de atributos. |
| **Serialización independiente del hijo** | No incluye al padre en el JSON del hijo (`@JsonBackReference` se omite siempre). | **Sí incluye al padre** (solo omite la lista recursiva dentro del padre). |
| **Deserialización** | Restaura la referencia bidireccional en memoria. | Solo ignora el mapeo del campo indicado. |

