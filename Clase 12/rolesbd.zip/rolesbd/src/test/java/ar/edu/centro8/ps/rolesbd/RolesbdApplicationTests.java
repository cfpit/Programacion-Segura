package ar.edu.centro8.ps.rolesbd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RolesbdApplicationTests {

	@Test
	void contextLoads() {
	}

}
