package ar.edu.centro8.ps.oauth2.config.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
        return httpSecurity
                // Deshabilitamos CSRF para facilitar pruebas con herramientas HTTP (Bruno, cURL, etc.)
                .csrf(csrf -> csrf.disable())

                // ==========================================================================================
                // OPCIÓN 1: PÁGINA DE LOGIN POR DEFECTO DE SPRING SECURITY (SIN ICONOS, ENLACES DE TEXTO)
                // Para usar esta opción: Descomenta este bloque y comenta la OPCIÓN 2 abajo.
                // =========================================================================
                /*
                // Autenticación tradicional mediante formulario por defecto
                .formLogin(Customizer.withDefaults())

                // Autenticación delegada OAuth2 / OIDC por defecto (enlaces simples de texto: "github", "google")
                .oauth2Login(Customizer.withDefaults())
                */

                // ==========================================================================================
                // OPCIÓN 2: PÁGINA DE LOGIN PERSONALIZADA CON ICONOS (Google multicolor y GitHub)
                // Despacha /login.html desde el controlador SaludoController.
                // Para usar la OPCIÓN 1: Comenta este bloque y descomenta la OPCIÓN 1 arriba.
                // ==========================================================================================
                .authorizeHttpRequests(auth -> auth
                        // Permitir acceso público a la página de login y a recursos estáticos
                        .requestMatchers("/login", "/login.html", "/images/**", "/css/**", "/favicon.ico").permitAll()
                        .anyRequest().permitAll()
                )
                .formLogin(form -> form
                        .loginPage("/login")
                        .loginProcessingUrl("/login")
                        .defaultSuccessUrl("/", true)
                        .permitAll()
                )
                .oauth2Login(oauth2 -> oauth2
                        .loginPage("/login")
                        .defaultSuccessUrl("/", true)
                )

                // ==========================================================================================
                // Configuración común de cierre de sesión
                // ==========================================================================================
                .logout(logout -> logout
                        .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
                        .logoutSuccessUrl("/login")
                        .invalidateHttpSession(true)
                        .clearAuthentication(true)
                        .deleteCookies("JSESSIONID")
                )
                .build();
    }
}
