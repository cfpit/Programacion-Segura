package ar.edu.centro8.ps.oauth2.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@PreAuthorize("denyAll()")
public class SaludoController {

    @GetMapping("/")
    @PreAuthorize("permitAll()")
    public String inicio() {
        return "Bienvenido a la aplicación de autenticación OAuth2 y OpenID Connect (OIDC)";
    }

    @GetMapping("/login")
    @PreAuthorize("permitAll()")
    public void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/login.html").forward(request, response);
    }

    @GetMapping("/decirhola")
    @PreAuthorize("permitAll()")
    public String decirHola() {
        return "Hola! Este endpoint no esta securizado";
    }

    @GetMapping("/decirholasec")
    @PreAuthorize("isAuthenticated()")
    public String decirHolaSec() {
        return "Hola! Este endpoint esta securizado";
    }

    /**
     * Endpoint para inspeccionar la información del usuario autenticado.
     * Soporta de manera polimórfica:
     *  1. Google OIDC (OidcUser): cuenta con ID Token JWT y claims estandarizados.
     *  2. GitHub OAuth 2.0 (OAuth2User): cuenta con atributos obtenidos mediante GET /user.
     *  3. Formulario tradicional: usuario en memoria gestionado por Spring Security.
     */
    @GetMapping("/user")
    @PreAuthorize("isAuthenticated()")
    public Map<String, Object> obtenerUsuarioAutenticado(
            Authentication authentication,
            @AuthenticationPrincipal Object principal) {

        Map<String, Object> respuesta = new LinkedHashMap<>();
        respuesta.put("mensaje", "Usuario autenticado con éxito");

        if (principal instanceof OidcUser oidcUser) {
            // Caso Google con OpenID Connect (OIDC)
            respuesta.put("tipoAutenticacion", "Google OIDC (OpenID Connect 1.0)");
            respuesta.put("nombre", oidcUser.getFullName());
            respuesta.put("email", oidcUser.getEmail());
            respuesta.put("subject", oidcUser.getSubject());
            respuesta.put("emailVerificado", oidcUser.getEmailVerified());
            respuesta.put("avatar", oidcUser.getPicture());
            respuesta.put("idTokenJwt", oidcUser.getIdToken().getTokenValue());
            respuesta.put("claims", oidcUser.getClaims());
        } else if (principal instanceof OAuth2User oauth2User) {
            // Caso GitHub (OAuth 2.0 puro sin ID Token)
            respuesta.put("tipoAutenticacion", "OAuth 2.0 Puro (GitHub u otro proveedor estándar)");
            respuesta.put("login", oauth2User.getAttribute("login"));
            respuesta.put("nombre", oauth2User.getAttribute("name"));
            respuesta.put("atributos", oauth2User.getAttributes());
        } else {
            // Caso Formulario clásico en memoria
            respuesta.put("tipoAutenticacion", "Formulario Tradicional (In-Memory)");
            respuesta.put("usuario", authentication.getName());
            respuesta.put("roles", authentication.getAuthorities().stream()
                    .map(GrantedAuthority::getAuthority)
                    .toList());
        }

        return respuesta;
    }

    /**
     * Endpoint exclusivo para inspeccionar las propiedades del ID Token
     * emitido en flujos OpenID Connect (OIDC) como el de Google.
     */
    @GetMapping("/user/oidc")
    @PreAuthorize("isAuthenticated()")
    public Map<String, Object> obtenerClaimsOidc(@AuthenticationPrincipal OidcUser oidcUser) {
        Map<String, Object> detalleOidc = new LinkedHashMap<>();

        if (oidcUser == null) {
            detalleOidc.put("estado", "No disponible para la sesión actual");
            detalleOidc.put("explicacion", "Este endpoint solo expone datos cuando la autenticación se realiza mediante un proveedor OIDC como Google. La sesión actual proviene de formulario o de un proveedor OAuth 2.0 puro (como GitHub) que no emite ID Token.");
            return detalleOidc;
        }

        detalleOidc.put("estado", "OK");
        detalleOidc.put("proveedor", "Google OpenID Connect (OIDC)");
        detalleOidc.put("emisor", oidcUser.getIdToken().getIssuer().toString());
        detalleOidc.put("subject", oidcUser.getIdToken().getSubject());
        detalleOidc.put("audiencia", oidcUser.getIdToken().getAudience());
        detalleOidc.put("emitidoEn", oidcUser.getIdToken().getIssuedAt());
        detalleOidc.put("expiraEn", oidcUser.getIdToken().getExpiresAt());
        detalleOidc.put("email", oidcUser.getEmail());
        detalleOidc.put("emailVerificado", oidcUser.getEmailVerified());
        detalleOidc.put("nombreCompleto", oidcUser.getFullName());
        detalleOidc.put("nombre", oidcUser.getGivenName());
        detalleOidc.put("apellido", oidcUser.getFamilyName());
        detalleOidc.put("foto", oidcUser.getPicture());
        detalleOidc.put("idTokenRawJwt", oidcUser.getIdToken().getTokenValue());
        detalleOidc.put("todosLosClaims", oidcUser.getIdToken().getClaims());

        return detalleOidc;
    }
}
