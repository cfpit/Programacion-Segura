# Autenticación con Google mediante OpenID Connect (OIDC) en Spring Boot 3

Este proyecto amplía la configuración base de seguridad de Spring Security para incorporar autenticación federada con **Google** mediante el protocolo **OpenID Connect (OIDC)**, manteniendo la compatibilidad con proveedores OAuth 2.0 tradicionales (como GitHub) y autenticación clásica por formulario.

---

<a id="indice"></a>
## Índice

1. [Fundamentos Teóricos: OAuth 2.0 frente a OpenID Connect (OIDC)](#1-fundamentos-teoricos)
   - [¿Por qué OAuth 2.0 no era suficiente para autenticar?](#por-que-oauth-20)
   - [¿Qué añade OpenID Connect (OIDC)?](#que-anade-oidc)
   - [Anatomía del ID Token (JWT)](#anatomia-id-token)
2. [Flujo Técnico Detallado de Autenticación con Google (OIDC)](#2-flujo-tecnico-google)
   - [Roles del Protocolo](#roles-del-protocolo)
   - [Diagrama de Secuencia Completo](#diagrama-de-secuencia)
   - [Explicación Paso a Paso del Flujo (Front-Channel y Back-Channel)](#explicacion-paso-a-paso)
   - [Validación Criptográfica del ID Token (JWKS)](#validacion-criptografica-jwks)
   - [Manejo de Sesión Local (`JSESSIONID`) frente a Sesión en Google](#manejo-de-sesion-local)
3. [Comparativa Técnica: Google (OIDC) vs. GitHub (OAuth 2.0)](#3-comparativa-tecnica)
4. [Guía Paso a Paso: Registro de la Aplicación en Google Cloud](#4-guia-paso-a-paso-google-cloud)
5. [Análisis de la Arquitectura y Código Fuente](#5-analisis-arquitectura)
   - [pom.xml (Dependencias y Nimbus JOSE)](#pomxml)
   - [application.properties (Configuración de Proveedores)](#applicationproperties)
   - [SecurityConfig (Cadena de Filtros de Seguridad)](#securityconfig)
   - [SaludoController (Consumo de Identidad y Claims)](#saludocontroller)
6. [Variables de Entorno y Ejecución](#6-variables-de-entorno)
7. [Pruebas con Bruno](#7-pruebas-con-bruno)
8. [Personalización de la Pantalla de Login: Iconos vs. Enlaces por Defecto](#8-personalizacion-login)
   - [¿Por qué Spring Security muestra texto plano por defecto?](#por-que-texto-plano)
   - [Cómo alternar entre ambas opciones comentando/descomentando código](#como-alternar-opciones)
   - [Archivos que componen la solución personalizada](#archivos-solucion-personalizada)

---

<a id="1-fundamentos-teoricos"></a>
## 1. Fundamentos Teóricos: OAuth 2.0 frente a OpenID Connect (OIDC)

<a id="por-que-oauth-20"></a>
### ¿Por qué OAuth 2.0 no era suficiente para autenticar?

**OAuth 2.0** (RFC 6749) es un protocolo diseñado exclusivamente para **autorización** delegada. Su propósito original es responder a la pregunta:
> *"¿Tiene esta aplicación permiso para realizar acciones en nombre del usuario sobre un recurso protegido?"*

En OAuth 2.0 puro:
- El servidor de autorización emite un **Access Token** (token de acceso).
- El estándar **no define el formato del Access Token** (puede ser una cadena aleatoria opaca o un identificador interno de base de datos).
- El estándar **no proporciona información sobre quién es el usuario** (no incluye nombre, correo, identificador global ni mecanismos para verificar su sesión).
- Para saber quién se autenticó, cada proveedor inventó su propia API REST propietaria (por ejemplo, GitHub creó `GET https://api.github.com/user`, Facebook creó Graph API, etc.), obligando a escribir código específico para cada servicio.

<a id="que-anade-oidc"></a>
### ¿Qué añade OpenID Connect (OIDC)?

**OpenID Connect 1.0 (OIDC)** es una capa de **identidad y autenticación** estandarizada que se monta directamente sobre OAuth 2.0. Su propósito es responder a la pregunta:
> *"¿Quién es el usuario y cómo se autenticó?"*

Para lograrlo, OIDC introduce tres conceptos fundamentales:
1. **El ID Token**: Un token con formato **JSON Web Token (JWT)** firmado digitalmente que contiene la identidad verificada del usuario.
2. **El endpoint de UserInfo estandarizado**: Una ruta estándar (`/userinfo`) para consultar atributos adicionales en caso de requerirlos.
3. **El alcance `openid`**: Un scope obligatorio que le indica al servidor de autorización que debe operar bajo las reglas de OIDC y emitir un ID Token.

```
+-------------------------------------------------------------+
|                OpenID Connect 1.0 (Identidad)               |
|      (ID Token JWT, UserInfo Endpoint, Scopes estándar)     |
+-------------------------------------------------------------+
|                   OAuth 2.0 (Autorización)                  |
|     (Authorization Code Flow, Access Tokens, Scopes)        |
+-------------------------------------------------------------+
```

---

<a id="anatomia-id-token"></a>
### Anatomía del ID Token (JWT)

El **ID Token** que emite Google es una cadena con tres partes separadas por puntos (`header.payload.signature`):

1. **Header (Encabezado)**:
   ```json
   {
     "alg": "RS256",
     "kid": "d8e3b4a56c78...",
     "typ": "JWT"
   }
   ```
   - `alg`: Algoritmo de firma digital asimétrica (RSA con SHA-256).
   - `kid` (*Key ID*): Identificador de la clave pública con la que Google firmó este token específico.

2. **Payload (Claims / Afirmaciones de Identidad)**:
   ```json
   {
     "iss": "https://accounts.google.com",
     "sub": "109823472938472918234",
     "aud": "1234567890-abcdef.apps.googleusercontent.com",
     "iat": 1700000000,
     "exp": 1700003600,
     "nonce": "n-0S6_WzA2Mj...",
     "email": "usuario@gmail.com",
     "email_verified": true,
     "name": "Juan Pérez",
     "picture": "https://lh3.googleusercontent.com/a/..."
   }
   ```
   - `iss` (*Issuer*): Quién emitió el token (debe ser estrictamente Google).
   - `sub` (*Subject*): Identificador único, permanente e irrepetible del usuario en Google.
   - `aud` (*Audience*): Destinatario del token; **debe coincidir exactamente con el `client-id`** de tu aplicación para evitar que un token generado para otra app sea usado en la tuya.
   - `iat` (*Issued At*) y `exp` (*Expiration*): Marcas de tiempo de emisión y expiración.
   - `nonce`: Cadena de seguridad vinculada a la petición original para prevenir ataques de repetición (*replay attacks*).
   - Claims de perfil: `email`, `name`, `picture`, `given_name`, `family_name`.

3. **Signature (Firma Digital Criptográfica)**:
   Generada por Google utilizando su **clave privada RSA**. Cualquier modificación en el encabezado o en los claims invalida la firma de inmediato.

---

<a id="2-flujo-tecnico-google"></a>
## 2. Flujo Técnico Detallado de Autenticación con Google (OIDC)

<a id="roles-del-protocolo"></a>
### Roles del Protocolo

1. **Resource Owner (Usuario Final)**: La persona sentada frente al navegador que es dueña de su cuenta de Google.
2. **Client (Nuestra aplicación Spring Boot)**: El servidor web que necesita verificar la identidad del usuario para concederle acceso.
3. **Authorization Server & OpenID Provider (Google Accounts - `accounts.google.com`)**: El servidor de Google que autentica al usuario y emite los tokens.
4. **User Agent (Navegador Web)**: El intermediario que transporta redirecciones HTTP entre el usuario, Spring Boot y Google.

---

<a id="diagrama-de-secuencia"></a>
### Diagrama de Secuencia Completo

```
NAVEGADOR                        SPRING BOOT                      GOOGLE ACCOUNTS
 (User Agent)                     (Client)                       (OpenID Provider)
      |                              |                                   |
      | ==== FASE 1: INICIO Y REDIRECCIÓN (Front-Channel) ============== |
      |                              |                                   |
      | 1. GET /oauth2/auth/google ->|                                   |
      |                              | Genera state (anti-CSRF)          |
      |                              | Genera nonce (anti-replay)        |
      |                              | Guarda state y nonce en sesión    |
      | <--- 2. 302 Redirect --------|                                   |
      |      a Google Accounts       |                                   |
      |                              |                                   |
      | ==== FASE 2: AUTENTICACIÓN Y CONSENTIMIENTO ==================== |
      |                              |                                   |
      | 3. GET /o/oauth2/v2/auth?client_id=...&scope=openid... --------->|
      |                              |                                   |
      | <--- 4. Muestra pantalla de Login / Selección de Cuenta ---------|
      | 5. Ingresa credenciales y aprueba permisos --------------------->|
      |                              |                                   |
      | ==== FASE 3: ENTREGA DEL CÓDIGO (Front-Channel) ================ |
      |                              |                                   |
      | <--- 6. 302 Redirect a /login/oauth2/code/google?code=XYZ&state=S |
      |                              |                                   |
      | 7. GET /login/oauth2/code/google?code=XYZ&state=S -------------->|
      |                              |                                   |
      |                              | Valida que 'state' == S guardado  |
      |                              |                                   |
      | ==== FASE 4: INTERCAMBIO DE TOKENS (Back-Channel Seguro) ======== |
      |                              |                                   |
      |                              | 8. POST /token ------------------>|
      |                              |    (code=XYZ, client_id,          |
      |                              |     client_secret, redirect_uri)  |
      |                              |                                   |
      |                              | <-- 9. Responde HTTP 200 JSON --- |
      |                              |    {                              |
      |                              |      "access_token": "ya29...",   |
      |                              |      "id_token": "eyJhbGciOi...", |
      |                              |      "token_type": "Bearer"       |
      |                              |    }                              |
      |                              |                                   |
      | ==== FASE 5: VALIDACIÓN CRIPTOGRÁFICA Y SESIÓN LOCAL =========== |
      |                              |                                   |
      |                              | 10. Consulta JWKS de Google       |
      |                              |     (certs públicos)              |
      |                              | 11. Valida firma del id_token     |
      |                              | 12. Valida iss, aud, exp y nonce  |
      |                              | 13. Crea OidcUser y AuthToken     |
      |                              | 14. Crea HttpSession (Tomcat)     |
      |                              |                                   |
      | <--- 15. Set-Cookie: JSESSIONID=ABCD1234... -------------------- |
      |      302 Redirect a "/" (Inicio)                                 |
      |                              |                                   |
      | 16. GET / (con Cookie JSESSIONID) -----------------------------> |
      | <--- 17. 200 OK "Bienvenido a la aplicación..." ----------------- |
```

---

<a id="explicacion-paso-a-paso"></a>
### Explicación Paso a Paso del Flujo (Front-Channel y Back-Channel)

El flujo de autenticación combina dos canales de comunicación para garantizar la máxima seguridad:

#### Fase 1: Inicio y Redirección (Front-Channel)
1. El usuario intenta ingresar a una ruta protegida o hace clic en el enlace *"Login with Google"* (`/oauth2/authorization/google`).
2. El filtro de Spring Security `OAuth2AuthorizationRequestRedirectFilter` intercepta la solicitud.
3. Spring genera dos cadenas criptográficas aleatorias:
   - **`state`**: Se almacena temporalmente en la sesión del usuario. Sirve para evitar ataques de falsificación de peticiones entre sitios (CSRF).
   - **`nonce`**: Se almacena en la sesión para vincular la solicitud con el ID Token futuro.
4. Spring construye la URL de autorización hacia Google y responde con `302 Found`:
   ```http
   Location: https://accounts.google.com/o/oauth2/v2/auth
             ?response_type=code
             &client_id=1234567890-abcdef.apps.googleusercontent.com
             &scope=openid%20profile%20email
             &redirect_uri=http://localhost:8080/login/oauth2/code/google
             &state=ab76cd89ef...
             &nonce=xy12zw34...
   ```

#### Fase 2: Autenticación en Google
5. El navegador del usuario viaja a Google.
6. Si el usuario no tiene una sesión activa en Google, ingresa su correo y contraseña (y segundo factor de autenticación 2FA si aplica).
7. Google presenta la **Pantalla de Consentimiento** informando que la aplicación solicita ver su identidad, correo y perfil básico.
8. El usuario presiona "Continuar" / "Permitir".

#### Fase 3: Retorno del Código de Autorización (Front-Channel)
9. Google genera un **código de autorización temporal (`code`)** con un tiempo de vida muy corto (generalmente menos de 60 segundos).
10. Google redirige al navegador de vuelta a la aplicación:
    ```http
    Location: http://localhost:8080/login/oauth2/code/google?code=4/0AY0e-xyz123...&state=ab76cd89ef...
    ```
11. El navegador ejecuta esa petición `GET` contra Spring Boot.
12. El filtro `OAuth2LoginAuthenticationFilter` de Spring Security captura la petición:
    - Compara el parámetro `state` recibido con el que guardó en el Paso 3. Si no coinciden, aborta la petición por posible ataque CSRF.

#### Fase 4: Intercambio de Código por Tokens (Back-Channel Seguro)
13. Spring Boot realiza una llamada HTTP directa **servidor a servidor** (sin pasar por el navegador del usuario):
    ```http
    POST https://oauth2.googleapis.com/token
    Content-Type: application/x-www-form-urlencoded

    grant_type=authorization_code
    &code=4/0AY0e-xyz123...
    &redirect_uri=http://localhost:8080/login/oauth2/code/google
    &client_id=1234567890-abcdef.apps.googleusercontent.com
    &client_secret=GOCSPX-MiSecretoPrivado...
    ```
    > [!IMPORTANT]
    > **Seguridad del canal directo:** El `client_secret` **nunca viaja por el navegador**. Solo viaja cifrado por HTTPS entre tu servidor backend y los servidores de Google.

14. Google valida que el código sea legítimo, que pertenezca a ese `client_id` y que el `client_secret` sea correcto.
15. Google responde con un JSON conteniendo:
    - **`access_token`**: Para realizar llamadas a APIs de Google.
    - **`id_token`**: El JWT que certifica quién es el usuario.

---

<a id="validacion-criptografica-jwks"></a>
### Validación Criptográfica del ID Token (JWKS)

En cuanto Spring Boot recibe el `id_token`, no se limita a leerlo ciegamente; ejecuta una estricta validación criptográfica a través de `OidcAuthorizationCodeAuthenticationProvider`:

1. **Obtención de Claves Públicas (JWKS)**:
   Google publica periódicamente sus claves públicas criptográficas en:
   `https://www.googleapis.com/oauth2/v3/certs`
2. **Verificación de la Firma Asimétrica**:
   Spring Security busca la clave pública correspondiente al `kid` del encabezado del token y verifica que la firma matemática coincida. Esto garantiza que el token fue emitido exclusivamente por Google y que nadie en el camino pudo alterar su contenido.
3. **Verificación de Claims de Seguridad**:
   - `iss == "https://accounts.google.com"`
   - `aud == GOOGLE_CLIENT_ID`
   - `exp > hora_actual`
   - `nonce == nonce_enviado_en_paso_3`

---

<a id="manejo-de-sesion-local"></a>
### Manejo de Sesión Local (`JSESSIONID`) frente a Sesión en Google

Una duda muy común al trabajar con OIDC es: **¿Quién gestiona la sesión una vez completado el login?**

1. **La sesión es 100% de Spring Boot (Tomcat)**:
   - Una vez que Spring valida el `id_token`, construye un objeto `OidcUser` y un `OAuth2AuthenticationToken`.
   - Spring Boot crea una sesión HTTP tradicional en memoria y emite una cookie al navegador:
     ```http
     Set-Cookie: JSESSIONID=7F9A0B1C2D3E...; Path=/; HttpOnly; SameSite=Lax
     ```
   - **Los tokens de Google (`access_token` e `id_token`) nunca se envían al navegador**. Permanecen seguros en el backend dentro del `OAuth2AuthorizedClientService`.
2. **Peticiones posteriores**:
   - Para cualquier petición siguiente (por ejemplo, a `/user` o a `/decirholasec`), el navegador únicamente envía la cookie `JSESSIONID`. Spring Boot busca la sesión en memoria y autoriza la petición.
3. **Cierre de sesión local (`/logout`) vs. Google**:
   - Cuando haces `POST /logout` en Spring Boot, se destruye la cookie `JSESSIONID` y la sesión en tu servidor.
   - **Sin embargo, la sesión de Google en tu navegador permanece abierta**, al igual que el consentimiento previo otorgado a la app. Por esta razón, si vuelves a hacer clic en *"Login with Google"*, Google puede autenticarte de forma inmediata sin volver a pedir contraseña a menos que se configure el parámetro `prompt=consent select_account`.

---

<a id="3-comparativa-tecnica"></a>
## 3. Comparativa Técnica: Google (OIDC) vs. GitHub (OAuth 2.0)

| Dimensión | Google (OpenID Connect 1.0) | GitHub (OAuth 2.0 Puro) |
| :--- | :--- | :--- |
| **Estándar utilizado** | OpenID Connect (extensión sobre OAuth 2.0) | OAuth 2.0 básico (RFC 6749) |
| **Token de identidad** | **Sí emite `id_token`** (JWT firmado criptográficamente) | **No emite token de identidad** (solo entrega `access_token`) |
| **¿Cómo sabe Spring quién es el usuario?** | Lee y valida directamente los claims del `id_token` | Obligado a hacer una segunda petición HTTP: `GET https://api.github.com/user` |
| **Peticiones de backend tras recibir el código** | **1 sola petición**: `POST /token` (obtiene token de acceso + ID Token) | **2 peticiones**: `POST /token` (para el token) y luego `GET /user` (para los datos) |
| **Clase principal en Spring Security** | `OidcUser` (subinterfaz de `OAuth2User` con métodos como `.getIdToken()`, `.getEmail()`) | `DefaultOAuth2User` (solo contiene un mapa genérico de atributos `.getAttributes()`) |
| **Garantía criptográfica** | Firma verificable contra el servidor de certificados JWKS | Confianza ciega en la respuesta JSON de la API `/user` |

---

<a id="4-guia-paso-a-paso-google-cloud"></a>
## 4. Guía Paso a Paso: Registro de la Aplicación en Google Cloud

Para poder utilizar el inicio de sesión con Google, es necesario registrar la aplicación en la consola de Google Cloud y obtener las credenciales de cliente.

### Paso 1: Crear o seleccionar un proyecto en Google Cloud Console

1. Ingresa a [Google Cloud Console](https://console.cloud.google.com/).
2. Inicia sesión con tu cuenta de Google.
3. En la barra superior, haz clic en el selector de proyectos y luego en **Nuevo proyecto** (o selecciona uno existente).
4. Asigna un nombre al proyecto (por ejemplo, `Spring Boot OIDC Demo`) y haz clic en **Crear**.

---

### Paso 2: Configurar la Pantalla de Consentimiento OAuth

Antes de crear credenciales, Google exige configurar la información que verán los usuarios al autenticarse:

1. En el menú de navegación izquierdo, dirígete a **APIs y servicios** > **Pantalla de consentimiento de OAuth**.
2. **Tipo de usuario**:
   - Selecciona **Externo** (disponible para cualquier usuario con cuenta de Google) y presiona **Crear**.
3. **Paso 1: Información de la aplicación**:
   - **Nombre de la aplicación**: `OAuth2 Spring Boot App`
   - **Correo electrónico de soporte del usuario**: selecciona tu dirección de correo.
   - **Datos de contacto del desarrollador**: ingresa tu dirección de correo electrónico.
   - Haz clic en **Guardar y continuar**.
4. **Paso 2: Permisos (Scopes)**:
   - Haz clic en **Agregar o quitar permisos**.
   - Marca los permisos básicos de OpenID Connect:
     - `.../auth/userinfo.email`
     - `.../auth/userinfo.profile`
     - `openid`
   - Haz clic en **Actualizar** y luego en **Guardar y continuar**.
5. **Paso 3: Usuarios de prueba (Test Users)**:
   - Mientras la aplicación esté en estado de publicación "En prueba" (*Testing*), solo los usuarios registrados aquí podrán iniciar sesión.
   - Haz clic en **Add Users** e ingresa la dirección de correo de Google con la que realizarás las pruebas.
   - Haz clic en **Guardar y continuar**.
6. **Paso 4: Resumen**: Revisa la configuración y regresa al panel principal.

---

### Paso 3: Crear las Credenciales OAuth 2.0

1. En el menú izquierdo, selecciona **APIs y servicios** > **Credenciales**.
2. En la parte superior, haz clic en **+ Crear credenciales** y elige **ID de cliente de OAuth**.
3. En **Tipo de aplicación**, selecciona **Aplicación web**.
4. En **Nombre**, escribe una referencia identificatoria (ejemplo: `Spring Boot Local Client`).
5. En la sección **Orígenes de JavaScript autorizados**, añade:
   - `http://localhost:8080`
6. En la sección **URIs de redirección autorizados**, añade **exactamente** la siguiente URL:
   - `http://localhost:8080/login/oauth2/code/google`

> [!IMPORTANT]
> La ruta `/login/oauth2/code/{registrationId}` es la convención estricta que utiliza Spring Security para capturar la respuesta del proveedor. En este caso, al estar registrado con el identificador `google`, el endpoint de retorno debe terminar en `/code/google`.

7. Haz clic en **Crear**.
8. Aparecerá una ventana modal con:
   - **ID de cliente** (ejemplo: `1234567890-abcdefgh.apps.googleusercontent.com`)
   - **Secreto de cliente** (ejemplo: `GOCSPX-abc123xyz...`)
9. Copia ambos valores para configurarlos en las variables de entorno de tu entorno de desarrollo.

---

<a id="5-analisis-arquitectura"></a>
## 5. Análisis de la Arquitectura y Código Fuente

<a id="pomxml"></a>
### pom.xml (Dependencias y Nimbus JOSE)

Para implementar OAuth2 y OIDC, el descriptor [`pom.xml`](pom.xml) incluye la dependencia oficial:

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-oauth2-client</artifactId>
</dependency>
```

#### ¿Por qué no se requieren librerías adicionales para JWT?
El starter `spring-boot-starter-oauth2-client` incluye de forma transitiva:
1. `spring-security-oauth2-client`: Gestiona los clientes registrados, los filtros de autorización (`OAuth2LoginAuthenticationFilter`) y el almacenamiento de credenciales.
2. `spring-security-oauth2-core`: Provee las interfaces `OAuth2User`, `OidcUser`, `OidcIdToken` y utilidades del estándar.
3. `spring-security-oauth2-jose`: Incorpora la librería **Nimbus JOSE+JWT**, permitiendo decodificar, validar firmas criptográficas (JWS) y verificar claims de los ID Tokens OIDC contra el JWKS de Google sin escribir una sola línea de código manual.

---

<a id="applicationproperties"></a>
### application.properties (Configuración de Proveedores)

En [`src/main/resources/application.properties`](src/main/resources/application.properties), se configuran las propiedades de conexión:

```properties
spring.application.name=oauth2

# Usuario tradicional en memoria para pruebas
spring.security.user.name=${SS_USER:centro8}
spring.security.user.password=${SS_PASSWORD:1234}
spring.security.user.roles=${ROLE:ADMIN}

# Proveedor 1: GitHub (OAuth 2.0 estándar)
spring.security.oauth2.client.registration.github.client-id=${GITHUB_CLIENT_ID:dummy-gh-client-id}
spring.security.oauth2.client.registration.github.client-secret=${GITHUB_CLIENT_SECRET:dummy-gh-client-secret}

# Proveedor 2: Google (OpenID Connect - OIDC)
spring.security.oauth2.client.registration.google.client-id=${GOOGLE_CLIENT_ID:dummy-google-client-id}
spring.security.oauth2.client.registration.google.client-secret=${GOOGLE_CLIENT_SECRET:dummy-google-client-secret}
spring.security.oauth2.client.registration.google.scope=openid,profile,email
```

#### Puntos técnicos clave:
1. **Detección automática de Google**: Spring Security cuenta con una clase interna denominada `CommonOAuth2Provider.GOOGLE` que define de manera predeterminada los endpoints de Google (`authorization-uri`, `token-uri`, `jwk-set-uri`, `user-info-uri`). Por ello, no es necesario declararlos manualmente.
2. **El rol del scope `openid`**: La presencia del scope `openid` instruye a Spring Security a solicitar un flujo OIDC en lugar de OAuth 2.0 puro. Google emitirá el ID Token firmado y Spring Security activará el `OidcUserService` en lugar del `DefaultOAuth2UserService`.
3. **Valores por defecto**: La sintaxis `${VARIABLE:valor_defecto}` previene fallos de inicialización del contenedor si no se han cargado variables de entorno locales, facilitando la ejecución directa del proyecto.

---

<a id="securityconfig"></a>
### SecurityConfig (Cadena de Filtros de Seguridad)

Ubicación: [`SecurityConfig.java`](src/main/java/ar/edu/centro8/ps/oauth2/config/security/SecurityConfig.java)

```java
@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
        return httpSecurity
                .csrf(csrf -> csrf.disable())
                .formLogin(Customizer.withDefaults())
                .oauth2Login(Customizer.withDefaults())
                .logout(logout -> logout
                        .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
                        .logoutSuccessUrl("/login")
                        .invalidateHttpSession(true)
                        .clearAuthentication(true)
                        .deleteCookies("JSESSIONID")
                )
                .build();
    }
}
```

#### Explicación de los componentes de seguridad:
- **`@EnableMethodSecurity`**: Habilita el control de acceso fino a nivel de métodos y controladores utilizando `@PreAuthorize`.
- **`.oauth2Login(Customizer.withDefaults())`**:
  - Habilita los endpoints de inicio de sesión de cada proveedor registrado (`/oauth2/authorization/{registrationId}`).
  - Instala el filtro `OAuth2LoginAuthenticationFilter`, que intercepta el callback en `/login/oauth2/code/*`.
  - Conecta el `OidcAuthorizationCodeAuthenticationProvider` para procesar y validar el ID Token emitido por Google.
- **`.formLogin(Customizer.withDefaults())`**: Mantiene la página de login por defecto de Spring Security (`/login`), la cual ahora muestra tanto el formulario de credenciales de prueba como los enlaces para autenticarse con **Google** o **GitHub**.
- **`.logout(...)`**: Limpia la sesión HTTP (`invalidateHttpSession(true)`), purga la información de autenticación del hilo actual (`clearAuthentication(true)`) y solicita al navegador la eliminación de la cookie de sesión (`deleteCookies("JSESSIONID")`).

---

<a id="saludocontroller"></a>
### SaludoController (Consumo de Identidad y Claims)

Ubicación: [`SaludoController.java`](src/main/java/ar/edu/centro8/ps/oauth2/controller/SaludoController.java)

El controlador implementa una política base restrictiva con `@PreAuthorize("denyAll()")` en la clase, habilitando de forma explícita cada endpoint:

```java
@RestController
@PreAuthorize("denyAll()")
public class SaludoController {

    @GetMapping("/")
    @PreAuthorize("permitAll()")
    public String inicio() {
        return "Bienvenido a la aplicación de autenticación OAuth2 y OpenID Connect (OIDC)";
    }

    @GetMapping("/decirhola")
    @PreAuthorize("permitAll()")
    public String decirHola() {
        return "Hola! Este endpoint no esta securizado";
    }

    @GetMapping("/decirholasec")
    @PreAuthorize("isAuthenticated()")
    public String decirHolaSec() {
        return "Hola! Este endpoint esta securizado";
    }

    @GetMapping("/user")
    @PreAuthorize("isAuthenticated()")
    public Map<String, Object> obtenerUsuarioAutenticado(
            Authentication authentication,
            @AuthenticationPrincipal Object principal) {
        // Inspecciona si el principal es OidcUser, OAuth2User o UserDetails
        ...
    }

    @GetMapping("/user/oidc")
    @PreAuthorize("isAuthenticated()")
    public Map<String, Object> obtenerClaimsOidc(@AuthenticationPrincipal OidcUser oidcUser) {
        // Expone el ID Token firmado y todos los claims OIDC de Google
        ...
    }
}
```

#### Uso de `@AuthenticationPrincipal`:
- Al autenticarse con **Google**, Spring Security inyecta un `OidcUser`. Esto permite acceder a:
  - `oidcUser.getEmail()`: Correo electrónico del usuario.
  - `oidcUser.getFullName()`: Nombre completo según el perfil de Google.
  - `oidcUser.getIdToken()`: Objeto `OidcIdToken` con el JWT decodificado y su firma.
  - `oidcUser.getClaims()`: Mapa con los atributos estándar de OIDC (`sub`, `iss`, `aud`, `iat`, `exp`, `email_verified`, `picture`).
- Si la autenticación se realizó con **GitHub**, el principal será una instancia de `OAuth2User` (sin ID Token).
- Si se utilizó el **formulario en memoria**, el principal será un objeto `UserDetails`.

---

<a id="6-variables-de-entorno"></a>
## 6. Variables de Entorno y Ejecución

Para ejecutar la aplicación con credenciales reales de Google:

### PowerShell (Windows):

```powershell
$env:GOOGLE_CLIENT_ID="TU_CLIENT_ID_DE_GOOGLE.apps.googleusercontent.com"
$env:GOOGLE_CLIENT_SECRET="TU_CLIENT_SECRET_DE_GOOGLE"
.\mvnw.cmd spring-boot:run
```

### CMD (Windows):

```cmd
set GOOGLE_CLIENT_ID=TU_CLIENT_ID_DE_GOOGLE.apps.googleusercontent.com
set GOOGLE_CLIENT_SECRET=TU_CLIENT_SECRET_DE_GOOGLE
mvnw.cmd spring-boot:run
```

### Linux / macOS:

```bash
export GOOGLE_CLIENT_ID="TU_CLIENT_ID_DE_GOOGLE.apps.googleusercontent.com"
export GOOGLE_CLIENT_SECRET="TU_CLIENT_SECRET_DE_GOOGLE"
./mvnw spring-boot:run
```

---

<a id="7-pruebas-con-bruno"></a>
## 7. Pruebas con Bruno

La carpeta `bruno/` contiene la colección de solicitudes organizada secuencialmente para validar todo el comportamiento de la aplicación:

| Archivo | Método | URL | Descripción |
| :--- | :---: | :--- | :--- |
| [`01 - Decir Hola (Publico).bru`](bruno/01%20-%20Decir%20Hola%20%28Publico%29.bru) | `GET` | `http://localhost:8080/decirhola` | Acceso público sin credenciales (`200 OK`). |
| [`02 - Decir Hola Securizado (Sin Auth).bru`](bruno/02%20-%20Decir%20Hola%20Securizado%20%28Sin%20Auth%29.bru) | `GET` | `http://localhost:8080/decirholasec` | Rechazo de acceso sin autenticación (redirige a `/login`). |
| [`03 - Login Formulario (centro8).bru`](bruno/03%20-%20Login%20Formulario%20%28centro8%29.bru) | `POST` | `http://localhost:8080/login` | Inicia sesión en memoria y genera cookie `JSESSIONID`. |
| [`04 - Decir Hola Securizado (Autenticado).bru`](bruno/04%20-%20Decir%20Hola%20Securizado%20%28Autenticado%29.bru) | `GET` | `http://localhost:8080/decirholasec` | Acceso exitoso al endpoint protegido con cookie de sesión activa. |
| [`05 - Pagina Login Spring Security.bru`](bruno/05%20-%20Pagina%20Login%20Spring%20Security.bru) | `GET` | `http://localhost:8080/login` | HTML de login generado por Spring, con formulario y enlaces a GitHub y Google. |
| [`06 - Redireccion OAuth2 GitHub.bru`](bruno/06%20-%20Redireccion%20OAuth2%20GitHub.bru) | `GET` | `http://localhost:8080/oauth2/authorization/github` | Inicia redirección a GitHub (`302 Found`). |
| [`07 - Logout (Cerrar Sesion).bru`](bruno/07%20-%20Logout%20%28Cerrar%20Sesion%29.bru) | `POST` | `http://localhost:8080/logout` | Invalida la sesión actual y destruye la cookie. |
| [`08 - Redireccion OAuth2 Google (OIDC).bru`](bruno/08%20-%20Redireccion%20OAuth2%20Google%20%28OIDC%29.bru) | `GET` | `http://localhost:8080/oauth2/authorization/google` | Inicia el flujo OIDC con Google solicitando `openid`, `profile` y `email`. |
| [`09 - Detalle Usuario Autenticado.bru`](bruno/09%20-%20Detalle%20Usuario%20Autenticado.bru) | `GET` | `http://localhost:8080/user` | Muestra polimórficamente los datos del usuario autenticado en la sesión. |
| [`10 - Claims OIDC Google (ID Token).bru`](bruno/10%20-%20Claims%20OIDC%20Google%20%28ID%20Token%29.bru) | `GET` | `http://localhost:8080/user/oidc` | Muestra el ID Token (JWT) y los claims de identidad de Google. |

---

<a id="8-personalizacion-login"></a>
## 8. Personalización de la Pantalla de Login: Iconos vs. Enlaces por Defecto

<a id="por-que-texto-plano"></a>
### ¿Por qué Spring Security muestra texto plano por defecto?

Cuando se utiliza la configuración estándar:

```java
.formLogin(Customizer.withDefaults())
.oauth2Login(Customizer.withDefaults())
```

Spring Security activa internamente un filtro denominado `DefaultLoginPageGeneratingFilter`. Este filtro autogenera un HTML minimalista donde los proveedores de OAuth2 se renderizan como simples enlaces de texto:
- `<a href="/oauth2/authorization/github">github</a>`
- `<a href="/oauth2/authorization/google">google</a>`

El código de este filtro es interno de Spring Security y **no ofrece propiedades de configuración para inyectar imágenes, iconos o clases CSS personalizadas**.

---

<a id="como-alternar-opciones"></a>
### Cómo alternar entre ambas opciones comentando/descomentando código

En el archivo [`SecurityConfig.java`](src/main/java/ar/edu/centro8/ps/oauth2/config/security/SecurityConfig.java) se dejaron preparadas las dos opciones para alternar fácilmente según las necesidades de la clase o demostración:

#### Opción 1: Pantalla por Defecto de Spring Security (Sin iconos, enlaces de texto)

Para volver a la pantalla automática generada por Spring Security:
1. **Descomenta** el bloque de la Opción 1.
2. **Comenta** el bloque de la Opción 2.

```java
// ==========================================================================================
// OPCIÓN 1: PÁGINA DE LOGIN POR DEFECTO DE SPRING SECURITY (SIN ICONOS, ENLACES DE TEXTO)
// ==========================================================================================
.formLogin(Customizer.withDefaults())
.oauth2Login(Customizer.withDefaults())
```

#### Opción 2: Pantalla Personalizada con Iconos SVG Oficiales (Google y GitHub)

Para usar la pantalla moderna con tarjetas e iconos estilizados:
1. **Comenta** la Opción 1.
2. **Descomenta** la Opción 2.

```java
// ==========================================================================================
// OPCIÓN 2: PÁGINA DE LOGIN PERSONALIZADA CON ICONOS (Google multicolor y GitHub)
// ==========================================================================================
.authorizeHttpRequests(auth -> auth
        .requestMatchers("/login", "/login.html", "/images/**", "/css/**", "/favicon.ico").permitAll()
        .anyRequest().permitAll()
)
.formLogin(form -> form
        .loginPage("/login")
        .loginProcessingUrl("/login")
        .defaultSuccessUrl("/", true)
        .permitAll()
)
.oauth2Login(oauth2 -> oauth2
        .loginPage("/login")
        .defaultSuccessUrl("/", true)
)
```

> [!NOTE]
> Al configurar explícitamente `.loginPage("/login")`, Spring Security desactiva de forma automática el `DefaultLoginPageGeneratingFilter`, cediendo el control del renderizado a nuestro archivo HTML.

---

<a id="archivos-solucion-personalizada"></a>
### Archivos que componen la solución personalizada

1. **[`SaludoController.java`](src/main/java/ar/edu/centro8/ps/oauth2/controller/SaludoController.java)**:
   El endpoint `@GetMapping("/login")` reenvía internamente la petición hacia `/login.html` mediante `request.getRequestDispatcher("/login.html").forward(request, response)`.
2. **[`login.html`](src/main/resources/static/login.html)**:
   Página web estilizada que incluye:
   - Formulario de credenciales local (`username` y `password` procesados por `POST /login`).
   - Botón de **Google** con su logotipo oficial vectorial SVG multicolor (`/oauth2/authorization/google`).
   - Botón de **GitHub** con su logotipo oficial SVG (`/oauth2/authorization/github`).
   - Script ligero para detectar automáticamente los parámetros `?error` (credenciales incorrectas) y `?logout` (sesión cerrada) y mostrar alertas contextuales.

