# Trabajo Práctico Nº 4: Spring Security - Sistema de Gestión Escolar

Este proyecto es una API REST desarrollada con **Spring Boot 3** y **Java 21**, diseñada para demostrar la implementación de mecanismos de autenticación y autorización utilizando **Spring Security 6** mediante **HTTP Basic Authentication** y control de acceso a nivel de método (**Method Security** con `@PreAuthorize`).

---

## 📋 Tabla de Contenidos

1. [Descripción General](#-descripción-general)
2. [Tecnologías y Dependencias](#-tecnologías-y-dependencias)
3. [Estructura del Proyecto](#-estructura-del-proyecto)
4. [Análisis Detallado de Componentes Clave](#-análisis-detallado-de-componentes-clave)
   - [SecurityConfig.java](#1-securityconfigjava)
   - [ColegioController.java](#2-colegiocontrollerjava)
   - [Modelos (Curso y Docente)](#3-modelos-curso-y-docente)
5. [Matriz de Roles y Autorizaciones](#-matriz-de-roles-y-autorizaciones)
6. [Resumen de Endpoints](#-resumen-de-endpoints)
7. [Cómo Ejecutar el Proyecto](#-cómo-ejecutar-el-proyecto)
8. [Pruebas con Bruno](#-pruebas-con-bruno)

---

## 📖 Descripción General

El sistema gestiona de forma simplificada (en memoria) dos recursos principales de un colegio:
- **Cursos** (`/cursos`)
- **Docentes** (`/docentes`)
- Un endpoint informativo público (`/public`)

La seguridad implementa el principio de **menor privilegio** y **denegación por defecto** (*deny-by-default*), donde cada método del controlador exige permisos puntuales (`authorities`) que deben coincidir con los otorgados al usuario autenticado.

---

## 🛠 Tecnologías y Dependencias

- **Java 21**
- **Spring Boot 3.4.4**
- **Spring Boot Starter Web**: Para la creación de servicios REST y controladores MVC.
- **Spring Boot Starter Security**: Filtros de autenticación, control de accesos y codificación de contraseñas.
- **BCrypt Password Encoder**: Hashing seguro de credenciales.
- **Lombok**: Reducción de código repetitivo (getters, setters, constructores).
- **Maven**: Gestor de dependencias y construcción del proyecto.

---

## 📁 Estructura del Proyecto

```text
tpn4/
├── bruno/                             # Colección de peticiones HTTP para Bruno
│   ├── bruno.json
│   ├── README.md
│   ├── environments/local.bru
│   ├── Public/
│   ├── Cursos/
│   └── Docentes/
├── src/
│   ├── main/
│   │   ├── java/ar/edu/centro8/ps/tpn4/
│   │   │   ├── Tpn4Application.java               # Punto de entrada de la aplicación
│   │   │   ├── controller/
│   │   │   │   └── ColegioController.java         # Endpoints REST y reglas de acceso
│   │   │   ├── model/
│   │   │   │   ├── Curso.java                     # Entidad Curso
│   │   │   │   └── Docente.java                   # Entidad Docente
│   │   │   └── security/config/
│   │   │       └── SecurityConfig.java            # Configuración de Spring Security
│   │   └── resources/
│   │       └── application.properties             # Parámetros de la aplicación
│   └── test/                                      # Pruebas unitarias y de integración
├── pom.xml
└── README.md
```

---

## 🔍 Análisis Detallado de Componentes Clave

### 1. `SecurityConfig.java`

Ubicado en: [`ar.edu.centro8.ps.tpn4.security.config.SecurityConfig`](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/ps/tpn4/tpn4/src/main/java/ar/edu/centro8/ps/tpn4/security/config/SecurityConfig.java)

Esta clase es el núcleo de la infraestructura de seguridad. Posee las siguientes anotaciones:
- `@Configuration`: Marca la clase como fuente de definiciones de beans para el contexto de Spring.
- `@EnableWebSecurity`: Habilita la cadena de filtros de seguridad web de Spring Security.
- `@EnableMethodSecurity`: Habilita el soporte para anotaciones de autorización en métodos (como `@PreAuthorize`, `@PostAuthorize`, `@Secured`), permitiendo validar permisos directamente sobre los endpoints del controlador.

#### Beans Configurados:

1. **`securityFilterChain(HttpSecurity http)`**:
   ```java
   @Bean
   public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
       return http
               .csrf(csrf -> csrf.disable()) // Deshabilita CSRF
               .httpBasic(Customizer.withDefaults()) // Autenticación HTTP Basic
               .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)) // Sin sesiones HTTP
               .build();
   }
   ```
   - **`csrf.disable()`**: Como se trata de una API REST consumida por clientes HTTP sin estado (y no por formularios web tradicionales basados en cookies de sesión), se desactiva la protección CSRF.
   - **`httpBasic(...)`**: Configura el estándar de autenticación básica HTTP (`Authorization: Basic base64(user:pass)`).
   - **`sessionCreationPolicy(STATELESS)`**: Indica que Spring Security no creará ni utilizará sesiones HTTP (`HttpSession`) para almacenar el `SecurityContext`. Cada petición debe enviar sus credenciales.

2. **`userDetailsService()`**:
   Crea y gestiona los usuarios en memoria (`InMemoryUserDetailsManager`) con sus contraseñas encriptadas, roles y autoridades explícitas:
   - **`admin`**: Posee el rol `ADMIN` y 4 permisos (`READ_CURSOS`, `WRITE_CURSOS`, `READ_DOCENTES`, `WRITE_DOCENTES`).
   - **`docente`**: Posee el rol `DOCENTE` y 2 permisos de lectura (`READ_CURSOS`, `READ_DOCENTES`).
   - **`estudiante`**: Posee el rol `ESTUDIANTE` y 1 permiso (`READ_CURSOS`).

3. **`passwordEncoder()`**:
   Define `new BCryptPasswordEncoder()`, el algoritmo estándar y seguro para hashear y verificar contraseñas.

4. **`authenticationProvider()` & `authenticationManager()`**:
   - `DaoAuthenticationProvider` enlaza el servicio de usuarios (`UserDetailsService`) con el codificador de contraseñas (`PasswordEncoder`) para procesar la autenticación.

---

### 2. `ColegioController.java`

Ubicado en: [`ar.edu.centro8.ps.tpn4.controller.ColegioController`](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/ps/tpn4/tpn4/src/main/java/ar/edu/centro8/ps/tpn4/controller/ColegioController.java)

Controlador REST que expone las operaciones de negocio y aplica las restricciones de autorización.

#### Estrategia de Seguridad Aplicada:

1. **Denegación por Defecto (`@PreAuthorize("denyAll()")`) a nivel clase:**
   ```java
   @RestController
   @PreAuthorize("denyAll()")
   public class ColegioController { ... }
   ```
   Esta es una excelente práctica de diseño de seguridad defensiva. Si en el futuro un desarrollador agrega un nuevo método al controlador y olvida anotarlo con `@PreAuthorize`, el acceso estará bloqueado por defecto (`403 Forbidden`) en lugar de quedar expuesto accidentalmente.

2. **Endpoint Público (`@PreAuthorize("permitAll()")`):**
   ```java
   @GetMapping("/public")
   @PreAuthorize("permitAll()")
   public String bienvenida() { ... }
   ```
   Sobrescribe la regla de la clase y permite el acceso anónimo o autenticado sin restricciones.

3. **Endpoints Protegidos por Autoridades (`hasAuthority(...)`):**
   Cada método especifica de forma granular el permiso exacto requerido:
   - **`GET /cursos`**: Requiere `@PreAuthorize("hasAuthority('READ_CURSOS')")`.
   - **`POST /cursos`**: Requiere `@PreAuthorize("hasAuthority('WRITE_CURSOS')")`.
   - **`GET /docentes`**: Requiere `@PreAuthorize("hasAuthority('READ_DOCENTES')")`.
   - **`POST /docentes`**: Requiere `@PreAuthorize("hasAuthority('WRITE_DOCENTES')")`.

---

### 3. Modelos (`Curso` y `Docente`)

- [Curso.java](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/ps/tpn4/tpn4/src/main/java/ar/edu/centro8/ps/tpn4/model/Curso.java):
  - Atributos: `id` (Long), `nombre` (String), `descripcion` (String).
- [Docente.java](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/ps/tpn4/tpn4/src/main/java/ar/edu/centro8/ps/tpn4/model/Docente.java):
  - Atributos: `id` (Long), `nombre` (String), `especialidad` (String).

Ambos cuentan con constructores y métodos getters/setters necesarios para la deserialización y serialización JSON de Spring Web (Jackson).

---

## 🔐 Matriz de Roles y Autorizaciones

| Usuario | Contraseña | Rol | READ_CURSOS | WRITE_CURSOS | READ_DOCENTES | WRITE_DOCENTES |
|---|---|---|:---:|:---:|:---:|:---:|
| **`admin`** | `admin123` | `ADMIN` | ✅ | ✅ | ✅ | ✅ |
| **`docente`** | `docente123` | `DOCENTE` | ✅ | ❌ | ✅ | ❌ |
| **`estudiante`** | `estudiante123` | `ESTUDIANTE` | ✅ | ❌ | ❌ | ❌ |
| **Anónimo** | *(ninguna)* | - | ❌ (401) | ❌ (401) | ❌ (401) | ❌ (401) |

---

## 📡 Resumen de Endpoints

| Método | Endpoint | Permiso Requerido | Descripción | Respuestas Típicas |
|---|---|---|---|---|
| `GET` | `/public` | *Ninguno* (`permitAll`) | Mensaje de bienvenida | `200 OK` |
| `GET` | `/cursos` | `READ_CURSOS` | Retorna la lista de cursos | `200 OK`, `401 Unauthorized` |
| `POST` | `/cursos` | `WRITE_CURSOS` | Registra un nuevo curso | `200 OK`, `403 Forbidden` |
| `GET` | `/docentes` | `READ_DOCENTES` | Retorna la lista de docentes | `200 OK`, `403 Forbidden` |
| `POST` | `/docentes` | `WRITE_DOCENTES` | Registra un nuevo docente | `200 OK`, `403 Forbidden` |

### Ejemplo de Payload para `POST /cursos`:
```json
{
  "nombre": "Spring Boot & Security",
  "descripcion": "Curso práctico de APIs REST seguras"
}
```

### Ejemplo de Payload para `POST /docentes`:
```json
{
  "nombre": "Carlos Gómez",
  "especialidad": "Arquitectura de Software"
}
```

---

## 🚀 Cómo Ejecutar el Proyecto

### Requisitos previos:
- JDK 21 instalado y configurado en el `JAVA_HOME`.
- Maven (o utilizar el wrapper incluido `./mvnw`).

### Pasos:

1. **Compilar y empaquetar:**
   ```bash
   ./mvnw clean package
   ```
   *(En Windows PowerShell: `.\mvnw.cmd clean package`)*

2. **Iniciar el servidor:**
   ```bash
   ./mvnw spring-boot:run
   ```
   *(En Windows PowerShell: `.\mvnw.cmd spring-boot:run`)*

3. La aplicación estará escuchando por defecto en:
   ```
   http://localhost:8080
   ```

---

## 🧪 Pruebas con Bruno

El proyecto cuenta con la suite de pruebas lista en la carpeta [bruno](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/ps/tpn4/tpn4/bruno).

1. Abre la aplicación de escritorio **Bruno**.
2. Haz clic en **Open Collection** y selecciona la carpeta raíz `bruno/`.
3. En el selector de entornos (arriba a la derecha), elige el entorno **`local`**.
4. Podrás ejecutar:
   - Casos de éxito (200 OK) para cada usuario.
   - Casos de rechazo deliberado (403 Forbidden) para verificar que las restricciones de seguridad funcionan correctamente.
