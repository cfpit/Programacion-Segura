# Colección Bruno - TPN4 API

Esta colección de Bruno permite probar todos los endpoints de la API y las restricciones de seguridad configuradas en Spring Security con autenticación básica.

## Estructura de la Colección

- **`environments/local.bru`**: Define la variable `baseUrl` (`http://localhost:8080`).
- **`Public/`**:
  - `Bienvenida`: Endpoint libre `GET /public`.
- **`Cursos/`**:
  - `Listar Cursos - Admin`: `GET /cursos` con credenciales de `admin`.
  - `Listar Cursos - Estudiante`: `GET /cursos` con credenciales de `estudiante`.
  - `Crear Curso - Admin`: `POST /cursos` con JSON para dar de alta un curso.
  - `Crear Curso - Estudiante (403)`: `POST /cursos` intentando crear curso como `estudiante` (valida respuesta HTTP 403 Forbidden).
- **`Docentes/`**:
  - `Listar Docentes - Docente`: `GET /docentes` con credenciales de `docente`.
  - `Listar Docentes - Estudiante (403)`: `GET /docentes` con credenciales de `estudiante` (valida respuesta HTTP 403 Forbidden).
  - `Crear Docente - Admin`: `POST /docentes` con JSON para dar de alta un docente.
  - `Crear Docente - Docente (403)`: `POST /docentes` intentando crear docente como `docente` (valida respuesta HTTP 403 Forbidden).

## Usuarios y Credenciales Configurados

| Usuario | Contraseña | Roles / Permisos |
|---|---|---|
| `admin` | `admin123` | `READ_CURSOS`, `WRITE_CURSOS`, `READ_DOCENTES`, `WRITE_DOCENTES` |
| `docente` | `docente123` | `READ_CURSOS`, `READ_DOCENTES` |
| `estudiante` | `estudiante123` | `READ_CURSOS` |

## Cómo abrir en Bruno

1. Abre la aplicación **Bruno**.
2. Selecciona **Open Collection**.
3. Elige la carpeta [bruno](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/ps/tpn4/tpn4/bruno).
4. Selecciona el entorno `local` arriba a la derecha.
