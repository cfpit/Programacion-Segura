package ar.edu.centro8.ps.tpn4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tpn4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
