package ar.edu.centro8.ps.tpn4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tpn4Application {

	public static void main(String[] args) {
		SpringApplication.run(Tpn4Application.class, args);
	}

}
