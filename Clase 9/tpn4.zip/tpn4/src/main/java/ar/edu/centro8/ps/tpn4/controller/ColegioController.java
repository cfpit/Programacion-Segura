package ar.edu.centro8.ps.tpn4.controller;

import ar.edu.centro8.ps.tpn4.model.Curso;
import ar.edu.centro8.ps.tpn4.model.Docente;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@PreAuthorize("denyAll()") // Niega acceso por defecto a todos los métodos
public class ColegioController {

    // Simulamos almacenamiento en memoria
    private List<Curso> cursos = new ArrayList<>();
    private List<Docente> docentes = new ArrayList<>();
    private Long cursoId = 1L;
    private Long docenteId = 1L;

    // Endpoint público, no requiere autenticación
    @GetMapping("/public")
    @PreAuthorize("permitAll()")
    public String bienvenida() {
        return "Bienvenido al Sistema de Gestión de Cursos del Colegio";
    }

    // Lista todos los cursos, requiere permiso READ_CURSOS
    @GetMapping("/cursos")
    @PreAuthorize("hasAuthority('READ_CURSOS')")
    public List<Curso> listarCursos() {
        return cursos;
    }

    // Crea un nuevo curso, requiere permiso WRITE_CURSOS
    @PostMapping("/cursos")
    @PreAuthorize("hasAuthority('WRITE_CURSOS')")
    public Curso crearCurso(@RequestBody Curso curso) {
        curso.setId(cursoId++);
        cursos.add(curso);
        return curso;
    }

    // Lista todos los docentes, requiere permiso READ_DOCENTES
    @GetMapping("/docentes")
    @PreAuthorize("hasAuthority('READ_DOCENTES')")
    public List<Docente> listarDocentes() {
        return docentes;
    }

    // Crea un nuevo docente, requiere permiso WRITE_DOCENTES
    @PostMapping("/docentes")
    @PreAuthorize("hasAuthority('WRITE_DOCENTES')")
    public Docente crearDocente(@RequestBody Docente docente) {
        docente.setId(docenteId++);
        docentes.add(docente);
        return docente;
    }

}

