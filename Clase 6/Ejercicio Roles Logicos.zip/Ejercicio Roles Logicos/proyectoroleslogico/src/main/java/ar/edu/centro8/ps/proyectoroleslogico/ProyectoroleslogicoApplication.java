package ar.edu.centro8.ps.proyectoroleslogico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoroleslogicoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoroleslogicoApplication.class, args);
	}

}
