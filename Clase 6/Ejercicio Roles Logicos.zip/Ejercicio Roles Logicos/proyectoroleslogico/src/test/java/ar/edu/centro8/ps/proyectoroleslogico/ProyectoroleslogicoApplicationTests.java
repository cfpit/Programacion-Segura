package ar.edu.centro8.ps.proyectoroleslogico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoroleslogicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
