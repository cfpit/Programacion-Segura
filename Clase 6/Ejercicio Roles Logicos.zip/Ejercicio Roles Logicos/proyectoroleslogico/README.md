# Proyecto Roles Lógicos con Spring Security

Este proyecto es una aplicación **Spring Boot** desarrollada como ejemplo práctico para la gestión de seguridad, autenticación HTTP Basic y autorización basada en **roles y autoridades (permisos) lógicos** en memoria.

---

## 🛠️ Tecnologías Utilizadas

- **Java 21**
- **Spring Boot 3.4.3**
- **Spring Security**
- **Maven**

---

## 📂 Explicación del Código

### 1. `HelloWorldController.java`
Ubicación: `src/main/java/ar/edu/centro8/ps/proyectoroleslogico/controller/HelloWorldController.java`

El controlador expone dos endpoints HTTP de tipo `GET`:

- **`GET /holanoseg`**:
  - **Método**: `noSecHelloWorld()`
  - **Respuesta**: `"Hola mundo sin seguridad"`
  - **Acceso**: Público. Cualquier usuario o cliente sin autenticarse puede acceder a esta ruta.

- **`GET /holaseg`**:
  - **Método**: `secHelloWorld()`
  - **Respuesta**: `"Hola Mundo con seguridad"`
  - **Acceso**: Protegido. Requiere que el usuario esté autenticado y posea explícitamente el permiso / autoridad **`READ`**.

---

### 2. `SecurityConfig.java`
Ubicación: `src/main/java/ar/edu/centro8/ps/proyectoroleslogico/security/config/SecurityConfig.java`

Esta clase configura toda la capa de seguridad de la aplicación mediante Spring Security.

#### Anotaciones Principales:
- `@Configuration`: Marca la clase como una fuente de definiciones de beans para el contenedor de Spring.
- `@EnableWebSecurity`: Habilita el soporte de seguridad web de Spring Security.
- `@EnableMethodSecurity`: Permite el uso de anotaciones de seguridad a nivel de métodos (como `@PreAuthorize` o `@Secured`).

#### Beans Configurados:

1. **`securityFilterChain(HttpSecurity httpSecurity)`**:
   Define la cadena de filtros de seguridad HTTP:
   - **`csrf(csrf -> csrf.disable())`**: Deshabilita la protección CSRF (adecuado para APIs REST stateless).
   - **`httpBasic(Customizer.withDefaults())`**: Activa la autenticación **HTTP Basic**, enviando las credenciales en el encabezado `Authorization: Basic <base64>`.
   - **`sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))`**: Establece que la aplicación no guardará sesiones HTTP en el servidor (Stateless).
   - **`authorizeHttpRequests(...)`**: Define las reglas de acceso por URL y método HTTP:
     - `/holanoseg` (GET): `permitAll()` -> Acceso público sin autenticación.
     - `/holaseg` (GET): `hasAuthority("READ")` -> Solo usuarios con la autoridad `READ`.
     - `anyRequest().denyAll()` -> Cualquier otra solicitud no especificada se rechaza explícitamente.

2. **`userDetailsService()`**:
   Crea y gestiona los usuarios en memoria (`InMemoryUserDetailsManager`) simulando una base de datos o servicio externo de usuarios:

   | Usuario | Contraseña | Roles | Autoridades (Permisos) | Acceso a `/holaseg` |
   | :--- | :--- | :--- | :--- | :--- |
   | `centro8` | `1234` | `ADMIN` | `CREATE`, `READ`, `UPDATE`, `DELETE` | **Sí** (200 OK) |
   | `seguidor` | `1234` | `USER` | `READ` | **Sí** (200 OK) |
   | `actualizador` | `1234` | `USER` | `UPDATE` | **No** (403 Forbidden) |

3. **`authenticationManager(...)` y `authenticationProvider()`**:
   - `authenticationProvider()`: Configura un `DaoAuthenticationProvider` asociando el `UserDetailsService` y el `PasswordEncoder`.
   - `authenticationManager(...)`: Obtiene el gestor de autenticación principal provisto por Spring Security.

4. **`passwordEncoder()`**:
   - Retorna `NoOpPasswordEncoder.getInstance()`.
   - > **Nota de Seguridad**: Compara contraseñas en texto plano sin encriptar. Se utiliza únicamente con fines educativos y de prueba. En entornos de producción se debe utilizar `BCryptPasswordEncoder`.

---

## 🔐 Alternativas a HTTP Basic

Además de **HTTP Basic** (utilizado en este proyecto), existen otros mecanismos de autenticación comunes en Spring Security:

1. **🔑 JWT (JSON Web Tokens) / Bearer Token** *(El estándar para APIs REST y SPAs/Móviles)*:
   - El cliente se autentica en `/login` y recibe un token firmado.
   - Envía el encabezado `Authorization: Bearer <token>` en las solicitudes posteriores.
   - Es 100% Stateless y no requiere guardar sesiones en el servidor.

2. **📝 Form-Based Authentication** *(Aplicaciones Web Tradicionales)*:
   - Utilizado en webs con renderizado en servidor (Thymeleaf/HTML).
   - Genera un formulario de login y maneja cookies de sesión (`JSESSIONID`).

3. **🌐 OAuth2 / OpenID Connect (OIDC)** *(Login con Google, GitHub, Auth0, Keycloak)*:
   - Delega el proceso de autenticación a un proveedor de identidad externo.

4. **🏷️ API Keys**:
   - Claves enviadas mediante encabezados personalizados como `X-API-KEY`.

### Tabla Comparativa

| Método | Dónde se usa más | Mantiene Sesión | Seguridad |
| :--- | :--- | :---: | :---: |
| **HTTP Basic** | Pruebas / Microservicios internos | ❌ No | ⚠️ Baja (requiere HTTPS) |
| **JWT** | APIs REST, React, Angular, Mobile | ❌ No (Stateless) | 🔒 Alta |
| **Form Login** | Webs tradicionales (Thymeleaf/HTML) |  Sí (Cookies) | 🔒 Media/Alta (requiere CSRF) |
| **OAuth2 / OIDC** | SSO, Login Social (Google/Auth0) | ❌ No / 🌐 Delegado | 🔒🔒 Muy Alta |

---

## 🧠 Conceptos Clave: Stateless vs Stateful y CSRF

### 1. ¿Cómo funciona la arquitectura Stateless en este proyecto? (HTTP Basic sin JWT)

Al configurar `SessionCreationPolicy.STATELESS` y usar `.httpBasic()`:
- **No se requiere JWT obligatoriamente**: "Stateless" (sin estado) no significa usar solo JWT. JWT es un tipo de token firmado, mientras que **HTTP Basic** transmite las credenciales `usuario:password` codificadas en Base64 en el encabezado `Authorization: Basic ...` en **cada petición HTTP**.
- **Validación en cada solicitud**: El servidor no almacena sesiones en memoria ni emite cookies `JSESSIONID`. En cada solicitud, Spring Security lee el encabezado `Authorization`, valida las credenciales contra el `UserDetailsService` (en este caso, `InMemoryUserDetailsManager`), otorga los permisos para esa solicitud puntual y olvida todo al finalizar.
- **¿Por qué se deshabilita CSRF (`csrf.disable()`)?**: El ataque **Cross-Site Request Forgery (CSRF)** aprovecha que los navegadores envían automáticamente las cookies de sesión (`JSESSIONID`) en peticiones hacia el backend. Al ser una API **Stateless** autenticada mediante encabezados HTTP explícitos (Headers) y sin cookies de sesión, el ataque CSRF deja de ser un riesgo relevante.

---

### 2. ¿Cómo sería la arquitectura si fuera Stateful (con Sesión y `JSESSIONID`)?

Si quisiéramos mantener el estado del usuario en el servidor utilizando cookies de sesión:

#### Configuración en `SecurityConfig.java`:
```java
@Bean
public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
    return httpSecurity
            // 1. En aplicaciones Stateful DEBES mantener habilitado CSRF
            .csrf(Customizer.withDefaults()) 
            
            // 2. Autenticación por Formulario o HTTP Basic
            .formLogin(Customizer.withDefaults())
            .httpBasic(Customizer.withDefaults())

            // 3. Crear sesión cuando sea necesario (Comportamiento por defecto)
            .sessionManagement(session -> session
                .sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED)
            )
            .authorizeHttpRequests(http -> {
                http.requestMatchers(HttpMethod.GET, "/holanoseg").permitAll();
                http.requestMatchers(HttpMethod.GET, "/holaseg").hasAuthority("READ");
                http.anyRequest().denyAll();
            })
            .build();
}
```

#### Flujo de trabajo Stateful:
1. **Autenticación inicial**: El usuario envía sus credenciales (vía formulario `POST /login` o primera solicitud `HTTP Basic`).
2. **Generación de Cookie**: Spring Security valida el usuario, crea una `HttpSession` en el servidor y responde con la cookie `Set-Cookie: JSESSIONID=...`.
3. **Peticiones subsecuentes**: El navegador adjunta automáticamente la cookie `JSESSIONID` en las siguientes solicitudes. El cliente ya no necesita reenviar el usuario y contraseña mientras dure la sesión.
4. **Protección CSRF Obligatoria**: Al depender de cookies de sesión que el navegador adjunta automáticamente, se debe mantener activado CSRF (`Customizer.withDefaults()`) y requerir un token CSRF (`X-CSRF-TOKEN`) en peticiones mutativas (`POST`, `PUT`, `DELETE`).

---

## 💡 Formulario HTML (`formLogin`) vs HTTP Basic (`httpBasic`)

### 1. ¿Cómo se percibe fácticamente? (Comportamiento)

| Aspecto | HTTP Basic (`httpBasic`) | Formulario HTML (`formLogin`) |
| :--- | :--- | :--- |
| **Público Objetivo** | APIs REST, aplicaciones móviles, clientes HTTP (Bruno, Postman). | Usuarios navegando en una web tradicional (HTML/Thymeleaf/JSP). |
| **Respuesta al entrar sin autenticación** | Retorna estado HTTP **`401 Unauthorized`** + header `WWW-Authenticate: Basic`. | Retorna redirección HTTP **`302 Found`** hacia la URL `/login`. |
| **Comportamiento en Navegador Web** | Muestra una **ventana emergente (pop-up nativo feo)** del navegador pidiendo usuario y contraseña. | Redirige a una **página web visual HTML** con un formulario (`<form>`). |
| **Envío de Credenciales** | En **cada petición** mediante la cabecera `Authorization: Basic <base64>`. | Mediante una petición `POST /login` con los datos del formulario (`username` y `password`). |
| **Mantenimiento de Sesión** | Suele usarse Stateless (sin sesión en servidor, en cada request se re-envía la cabecera). | Se crea una cookie de sesión `JSESSIONID` tras hacer login exitoso. |

---

### 2. ¿Cómo se distingue en el Código? (Spring Security)

En `SecurityConfig.java`:

- **Con HTTP Basic** (Configuración de este proyecto):
  ```java
  return httpSecurity
          .csrf(csrf -> csrf.disable())
          .httpBasic(Customizer.withDefaults()) // <--- Filtro BasicAuthenticationFilter
          .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
          .authorizeHttpRequests(...)
          .build();
  ```

- **Con Formulario HTML**:
  ```java
  return httpSecurity
          .csrf(csrf -> csrf.disable())
          .formLogin(Customizer.withDefaults()) // <--- Genera la página HTML /login y el filtro de formulario
          .authorizeHttpRequests(...)
          .build();
  ```

---

### 3. ¿Cómo se percibe y testea en Bruno?

1. **Con HTTP Basic (`.httpBasic()`)**:
   - **Sin Autenticar**: Bruno recibe un código HTTP **`401 Unauthorized`** limpio y la cabecera `WWW-Authenticate: Basic`.
   - **Autenticado**: Al usar la solapa `Auth -> Basic` en Bruno, este envía automáticamente la cabecera `Authorization: Basic Y2VudHJvODoxMjM0` (Base64 de `centro8:1234`) y recibe **`200 OK`**.

2. **Con Formulario HTML (`.formLogin()`)**:
   - **Sin Autenticar**: Al hacer `GET /holaseg`, Bruno **NO** recibe un `401 Unauthorized`, sino una redirección **`302 Found`** o el **cuerpo HTML completo** de la página de login de Spring (`<!DOCTYPE html>...`).
   - **Autenticado**: La pestaña `Auth -> Basic` de Bruno no funciona. Habría que enviar un `POST` a `/login` enviando `username` y `password` por `Form Data`, guardar la cookie `JSESSIONID` devuelta y adjuntarla en solicitudes posteriores.

---

## 🧪 Pruebas con Bruno

El proyecto incluye una carpeta `bruno/` lista para importar en el cliente de APIs **Bruno**.

### Solicitudes preparadas:
1. `1 - Hola No Seg (Publico)`: `GET /holanoseg` -> Retorna `200 OK` sin credenciales.
2. `2 - Hola Seg - Admin (Centro8)`: `GET /holaseg` con auth `centro8:1234` -> Retorna `200 OK`.
3. `3 - Hola Seg - Seguidor (Con READ)`: `GET /holaseg` con auth `seguidor:1234` -> Retorna `200 OK`.
4. `4 - Hola Seg - Actualizador (Sin READ)`: `GET /holaseg` con auth `actualizador:1234` -> Retorna `403 Forbidden` (no posee el permiso `READ`).
5. `5 - Hola Seg - Sin Autenticacion`: `GET /holaseg` sin credenciales -> Retorna `401 Unauthorized`.

---

## 🚀 Cómo Ejecutar la Aplicación

1. Asegúrate de tener instalado Java 21.
2. Desde la terminal en la raíz del proyecto, ejecuta:

   ```bash
   # En Windows:
   .\mvnw.cmd spring-boot:run

   # En Linux / macOS:
   ./mvnw spring-boot:run
   ```

3. La aplicación se iniciará por defecto en `http://localhost:8080`.
