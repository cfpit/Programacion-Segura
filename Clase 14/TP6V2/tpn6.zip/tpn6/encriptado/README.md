# 🔐 Setup TP N6 Encriptación de Contraseñas

---

## 🗂️ Tabla de roles y permisos

| Rol   | Permisos asignados          |
| ----- | --------------------------- |
| ADMIN | READ, CREATE                |
| USER  | READ                        |
| GUEST | (ninguno o los que asignes) |

---

## 🚩 Paso 1: Preparación inicial

- Comenta todas las anotaciones `@PreAuthorize` en los diferentes controllers.
- En el archivo `SecurityConfig`, permite la creación de permisos, roles y usuarios (respetar este orden):

```java
@Bean
public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
    return httpSecurity
            .csrf(csrf -> csrf.disable())
            .httpBasic(Customizer.withDefaults())
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/holanoseg").permitAll()
                .requestMatchers("/api/permissions", "/api/permissions/**").permitAll()
                .requestMatchers("/api/roles", "/api/roles/**").permitAll()
                .requestMatchers("/api/users", "/api/users/**").permitAll()
                .anyRequest().authenticated()
            )
            .build();
}
```

## 🛠️ Paso 2: Crear permisos, roles y usuario admin

* Crea los permisos `READ` y `CREATE`.
* Crea los roles `ADMIN` y `USER`.
* Crea el usuario `centro8` con clave `1234` y asígnale el rol `ADMIN`.
* Verifica en la base de datos el correcto ingreso de registros.

## 🔄 Paso 3: Activar seguridad

- Descomenta todas las anotaciones `@PreAuthorize`.
- Deja el siguiente código en `SecurityConfig`:

```java
@Bean
public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
    return httpSecurity
            .csrf(csrf -> csrf.disable())
            .httpBasic(Customizer.withDefaults())
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/holanoseg").permitAll()
                //.requestMatchers("/api/permissions", "/api/permissions/**").permitAll()
                //.requestMatchers("/api/roles", "/api/roles/**").permitAll()
                //.requestMatchers("/api/users", "/api/users/**").permitAll()
                .anyRequest().authenticated()
            )
            .build();
}
```

* Reinicia la aplicación.

---

## 👤 Paso 4: Crear usuarios adicionales

* Usando la autorización del usuario `centro8` (ADMIN), crea otro usuario (`seguidor` con rol `READ`).

---

## 🧪 Paso 5: Testear endpoints con Postman

* `GET http://localhost:8080/holaseg` → solo el usuario con rol ADMIN puede acceder
* `GET http://localhost:8080/holanoseg` → cualquiera puede acceder
* Listar todos los permisos, luego un solo permiso
* Listar todos los roles, luego un solo rol
* Listar todos los usuarios, luego un solo usuario
* Crear un tercer usuario (`seguidor2` con rol `READ`)
* Crear el rol `GUEST`
* Crear un cuarto usuario (`invitado` con rol `GUEST`)
* Modificar el rol para que el usuario invitado no tenga más permisos
* Verificar, listando todos los usuarios, que el usuario invitado no puede acceder
