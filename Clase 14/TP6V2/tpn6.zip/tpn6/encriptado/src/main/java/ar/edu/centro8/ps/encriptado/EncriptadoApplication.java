package ar.edu.centro8.ps.encriptado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EncriptadoApplication {

	public static void main(String[] args) {
		// System.out.println(new org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder().encode("1234"));
		SpringApplication.run(EncriptadoApplication.class, args);
	}

}
