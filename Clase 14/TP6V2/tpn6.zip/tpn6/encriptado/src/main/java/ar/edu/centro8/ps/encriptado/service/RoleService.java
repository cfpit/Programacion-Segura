package ar.edu.centro8.ps.encriptado.service;

import ar.edu.centro8.ps.encriptado.model.Role;
import ar.edu.centro8.ps.encriptado.repository.IRoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RoleService implements IRoleService {

    @Autowired
    private IRoleRepository roleRepository;

    @Override
    public List<Role> findAll() {
        return roleRepository.findAll();
    }

    @Override
    public Optional<Role> findById(Long id) {
        return roleRepository.findById(id);
    }

    @Override
    public Role save(Role role) {
        return roleRepository.save(role);
    }

    @Override
    public void deleteById(Long id) {
        roleRepository.deleteById(id);
    }

    // @Override
    // public Role update(Role role) {
    // return roleRepository.save(role);
    // }

    @Override
    public Role update(Role role) {
        // Solo actualiza si el rol ya existe
        if (role.getId() != null && roleRepository.existsById(role.getId())) {
            return roleRepository.save(role);
        }
        throw new IllegalArgumentException("El rol no existe para actualizar");
    }
}
