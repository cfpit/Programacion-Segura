package ar.edu.centro8.ps.rolesbd.repository;

import ar.edu.centro8.ps.rolesbd.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IRoleRepository extends JpaRepository<Role, Long> {
}
