package ar.edu.centro8.ps.rolesbd.controller;

import ar.edu.centro8.ps.rolesbd.model.Permission;
import ar.edu.centro8.ps.rolesbd.model.Role;
import ar.edu.centro8.ps.rolesbd.service.IPermissionService;
import ar.edu.centro8.ps.rolesbd.service.IRoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@RestController
@RequestMapping("/api/roles")
public class RoleController {

    @Autowired
    private IRoleService roleService;

    @Autowired
    private IPermissionService permiService;

    @GetMapping
    public ResponseEntity<List<Role>> getAllRoles() {
        List<Role> roles = roleService.findAll();
        return ResponseEntity.ok(roles);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Role> getRoleById(@PathVariable Long id) {
        Optional<Role> role = roleService.findById(id);
        return role.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Role> createRole(@RequestBody Role role) {
        Set<Permission> permiList = new HashSet<>();
        Permission readPermission;

        // Recuperar la/s Permission/s por su ID
        if (role.getPermissionsList() != null) {
            for (Permission per : role.getPermissionsList()) {
                if (per.getId() != null) {
                    readPermission = permiService.findById(per.getId()).orElse(null);
                    if (readPermission != null) {
                        permiList.add(readPermission);
                    }
                }
            }
        }
        role.setPermissionsList(permiList);
        Role newRole = roleService.save(role);
        return ResponseEntity.ok(newRole);
    }
}
