package ar.edu.centro8.ps.rolesbd.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorldController {

    @GetMapping("/holanoseg")
    @PreAuthorize("permitAll()")
    public String holaNoSeg() {
        return "Hola mundo sin seguridad";
    }

    @GetMapping("/holaseg")
    @PreAuthorize("hasAuthority('READ')")
    public String holaSeg() {
        return "Hola mundo con seguridad (requiere permiso READ)";
    }
}
