# TP N° 5: Roles en Bases de Datos (Spring Security + JPA + MySQL)

Este proyecto corresponde al desarrollo del **Trabajo Práctico N° 5 - Roles en Bases de Datos** de la materia de Práctica Supervisada (Centro 8).

La aplicación es una API REST construida con **Java (JDK 25)**, **Maven** y **Spring Boot (4.1.1)** que implementa autenticación y autorización en base de datos mediante **Spring Security**, mapeando entidades relacionales con **JPA / Hibernate** sobre **MySQL**.

---

## 🛠️ Tecnologías y Dependencias

- **Lenguaje:** Java 25 (LTS)
- **Gestor de dependencias:** Apache Maven
- **Framework:** Spring Boot 4.1.1
  - `spring-boot-starter-web`: Exposición de endpoints RESTful.
  - `spring-boot-starter-security`: Control de acceso y autenticación HTTP Basic.
  - `spring-boot-starter-data-jpa`: Persistencia y ORM con Hibernate.
  - `mysql-connector-j`: Driver oficial para conexión con MySQL.
  - `lombok` (v1.18.48): Generación de getters, setters, constructores y reductor de boilerplate.
  - `spring-boot-devtools`: Recarga rápida en desarrollo.
  - `spring-boot-starter-test` & `spring-security-test`: Soporte para pruebas unitarias y de integración.

---

## 📐 Estructura del Proyecto

El código respeta la ruta base del paquete: `ar.edu.centro8.ps.rolesbd`:

```text
tpn5/
├── pom.xml                                      # Configuración Maven y dependencias
├── README.md                                    # Documentación completa del proyecto
├── bruno/                                       # Colección de pruebas para Bruno API Client
│   ├── bruno.json                               # Configuración de colección Bruno
│   ├── 1. Permisos/                             # Creación y listado de permisos
│   │   ├── 1 - Crear Permiso READ.bru
│   │   ├── 2 - Crear Permiso CREATE.bru
│   │   └── 3 - Listar Permisos.bru
│   ├── 2. Roles/                                # Creación y listado de roles con permisos asociados
│   │   ├── 1 - Crear Rol ADMIN.bru
│   │   ├── 2 - Crear Rol USER.bru
│   │   └── 3 - Listar Roles.bru
│   ├── 3. Usuarios/                             # Creación y listado de usuarios con roles asociados
│   │   ├── 1 - Crear Usuario centro8.bru
│   │   ├── 2 - Crear Usuario seguidor.bru
│   │   └── 3 - Listar Usuarios.bru
│   └── 4. Pruebas Seguridad/                    # Verificación de endpoints securizados y públicos
│       ├── 1 - Hola No Seg (Sin Auth).bru
│       ├── 2 - Hola Seg (centro8 - 200 OK).bru
│       ├── 3 - Hola Seg (seguidor - 200 OK).bru
│       └── 4 - Hola Seg (Sin Auth - 401).bru
└── src/
    ├── main/
    │   ├── java/ar/edu/centro8/ps/rolesbd/
    │   │   ├── RolesbdApplication.java          # Clase principal de arranque Spring Boot
    │   │   ├── config/
    │   │   │   └── SecurityConfig.java          # Configuración de Spring Security, DaoAuthenticationProvider, PasswordEncoder
    │   │   ├── controller/
    │   │   │   ├── HelloWorldController.java    # Endpoints de prueba (/holanoseg, /holaseg)
    │   │   │   ├── PermissionController.java    # CRUD /api/permissions
    │   │   │   ├── RoleController.java          # CRUD /api/roles
    │   │   │   └── UserController.java          # CRUD /api/users
    │   │   ├── model/
    │   │   │   ├── Permission.java              # Entidad Permission (@Table permissions)
    │   │   │   ├── Role.java                    # Entidad Role (@Table roles) + @ManyToMany con Permission
    │   │   │   └── UserSec.java                 # Entidad UserSec (@Table users) + @ManyToMany con Role
    │   │   ├── repository/
    │   │   │   ├── IPermissionRepository.java   # Spring Data JPA Repository para Permission
    │   │   │   ├── IRoleRepository.java         # Spring Data JPA Repository para Role
    │   │   │   └── IUserRepository.java         # findUserEntityByUsername(username)
    │   │   └── service/
    │   │       ├── IPermissionService.java / PermissionService.java
    │   │       ├── IRoleService.java / RoleService.java
    │   │       ├── IUserService.java / UserService.java
    │   │       └── UserDetailsServiceImp.java   # Carga usuario desde BD y mapea roles ("ROLE_...") y permisos como GrantedAuthority
    │   └── resources/
    │       └── application.properties           # Cadena de conexión JDBC MySQL y variables
    └── test/
```

---

## 🗄️ Modelo de Base de Datos y Relaciones

El modelo implementa dos relaciones `@ManyToMany` unidireccionales utilizando tablas intermedias y colecciones `Set` para prevenir duplicados:

1. **`UserSec` ── (ManyToMany) ──> `Role`**
   - Tabla intermedia: `user_roles`
   - Claves foráneas: `user_id` y `role_id`
   - Carga: `FetchType.EAGER`
2. **`Role` ── (ManyToMany) ──> `Permission`**
   - Tabla intermedia: `roles_permissions`
   - Claves foráneas: `role_id` y `permission_id`
   - Carga: `FetchType.EAGER`

---

## ⚙️ Configuración de Base de Datos (`application.properties`)

Antes de iniciar la aplicación, asegúrate de tener una instancia de MySQL en ejecución:

```properties
spring.application.name=rolesbd

# Configuración Hibernate y MySQL
spring.jpa.hibernate.ddl-auto=update
spring.datasource.url=jdbc:mysql://localhost:3306/security?useSSL=false&serverTimezone=UTC&createDatabaseIfNotExist=true&allowPublicKeyRetrieval=true
spring.datasource.username=${DB_USER:root}
spring.datasource.password=${DB_PASSWORD:1234}
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver

# Formateo SQL en consola
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.format_sql=true
```

> [!NOTE]
> La base de datos `security` se creará automáticamente si tu usuario de MySQL tiene privilegios, gracias al parámetro `createDatabaseIfNotExist=true`.

---

## 🚀 Compilación y Ejecución

Desde la carpeta raíz del proyecto (`tpn5`):

```bash
# Compilar el proyecto
mvn clean compile

# Ejecutar la aplicación
mvn spring-boot:run
```

---

## 🧪 Pruebas con Bruno API Client

La carpeta `bruno/` contiene todas las colecciones listas para importar y testear.

### ⚠️ Orden estricto de inserción:
Debido a la integridad referencial y las relaciones entre entidades, **deben ejecutarse en el siguiente orden**:

1. **Crear Permisos** (`/api/permissions`)
   - `READ` (ID generado: 1)
   - `CREATE` (ID generado: 2)
2. **Crear Roles** (`/api/roles`)
   - `ADMIN` con `permissionsList`: IDs `[1, 2]` (READ + CREATE)
   - `USER` con `permissionsList`: ID `[1]` (READ)
3. **Crear Usuarios** (`/api/users`)
   - `centro8` (password: `1234`) con `rolesList`: ID `[1]` (ADMIN)
   - `seguidor` (password: `1234`) con `rolesList`: ID `[2]` (USER)
4. **Probar Endpoints Securizados**
   - `GET http://localhost:8080/holanoseg`: Libre acceso (`200 OK`).
   - `GET http://localhost:8080/holaseg` con Basic Auth `centro8:1234`: Acceso permitido (`200 OK`, posee `READ`).
   - `GET http://localhost:8080/holaseg` con Basic Auth `seguidor:1234`: Acceso permitido (`200 OK`, posee `READ`).
   - `GET http://localhost:8080/holaseg` sin credenciales: Rechazado (`401 Unauthorized`).
