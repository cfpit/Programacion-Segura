package ar.edu.centro8.ps.proyectobaseseguridad.security.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import static org.springframework.security.config.Customizer.withDefaults;

// import static org.springframework.security.config.withDefaults;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import java.util.Collections;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

// Codigo para usuario y contraseña definidos por el usuario

@Configuration
@EnableWebSecurity
public class SecurityConfig {
        @Value("${SS_USER}")
        private String user;

        @Value("${SS_PASSWORD}")
        private String password;

        // OPCIÓN 1: Formulario por defecto (Bean completo - Descomentar para probar)
        // @Bean
        // public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        // return http
        // .authorizeHttpRequests(auth -> auth
        // .requestMatchers("/holanoseg").permitAll()
        // .anyRequest().authenticated())
        // .formLogin(withDefaults())
        // .logout(logout -> logout
        // .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
        // .permitAll())
        // .build();
        // }

        // OPCIÓN 2: Formulario con redirección personalizada a /holaseg (Bean completo
        // - Descomentar para probar)
        // @Bean
        // public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        // return http
        // .authorizeHttpRequests(auth -> auth
        // .requestMatchers("/holanoseg").permitAll()
        // .anyRequest().authenticated())
        // .formLogin(form -> form
        // .defaultSuccessUrl("/holaseg", true))
        // .logout(logout -> logout
        // .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
        // .permitAll())
        // .build();
        // }

        // OPCIÓN 3: Alternar entre login por defecto y personalizado comentando una
        // sola línea (Descomentar para probar)
        // @Bean
        // public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        // return http
        // .authorizeHttpRequests(auth -> auth
        // .requestMatchers("/holanoseg").permitAll()
        // .anyRequest().authenticated())
        // // Alternativa A: Login por defecto
        // // .formLogin(withDefaults())

        // // Alternativa B: Login con redirección personalizada
        // .formLogin(form -> form.defaultSuccessUrl("/holaseg", true))

        // .logout(logout -> logout
        // .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
        // .permitAll())
        // .build();
        // }

        // OPCIÓN 4: Formulario y Logout 100% en Español con controller Java String HTML
        // (Descomentar para probar)
        // @Bean
        // public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        // return http
        // .authorizeHttpRequests(auth -> auth
        // .requestMatchers("/holanoseg", "/login").permitAll()
        // .anyRequest().authenticated())
        // .formLogin(form -> form
        // .loginPage("/login") // Vista personalizada en español via Controller
        // .defaultSuccessUrl("/holaseg", true)
        // .failureUrl("/login?error=true")
        // .permitAll())
        // .logout(logout -> logout
        // .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
        // .logoutSuccessUrl("/login?logout=true")
        // .permitAll())
        // .build();
        // }

        // OPCIÓN 5: Formulario y Vista Servidos desde Archivos Estáticos en /static
        // (Separación Back/Vista) (Activo)
        @Bean
        public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
                return http
                                // Se desactiva CSRF para permitir peticiones POST desde el formulario HTML
                                // estático sin token dinámico
                                .csrf(csrf -> csrf.disable())
                                .authorizeHttpRequests(auth -> auth
                                                .requestMatchers("/holanoseg", "/login.html", "/css/**", "/js/**",
                                                                "/favicon.ico")
                                                .permitAll()
                                                .anyRequest().authenticated())
                                .formLogin(form -> form
                                                .loginPage("/login.html") // Vista estática en español en
                                                                          // src/main/resources/static/login.html
                                                .loginProcessingUrl("/login") // Endpoint POST donde Spring Security
                                                                              // procesa las credenciales
                                                .defaultSuccessUrl("/holaseg.html", true) // Vista estática protegida en
                                                                                          // src/main/resources/static/holaseg.html
                                                .failureUrl("/login.html?error=true") // Redirección con parámetro de
                                                                                      // error
                                                .permitAll())
                                .logout(logout -> logout
                                                .logoutRequestMatcher(new AntPathRequestMatcher("/logout")) // Acepta
                                                                                                            // peticiones
                                                                                                            // POST o
                                                                                                            // enlaces a
                                                                                                            // /logout
                                                .logoutSuccessUrl("/login.html?logout=true") // Redirección al
                                                                                             // formulario estático tras
                                                                                             // cerrar sesión
                                                .permitAll())
                                .build();
        }

        @Bean
        public UserDetailsService userDetailsService() {
                UserDetails user = User.withUsername(this.user)
                                .password(passwordEncoder().encode(this.password))
                                .roles("USER")
                                .build();

                return new InMemoryUserDetailsManager(Collections.singleton(user));
        }

        @Bean
        public PasswordEncoder passwordEncoder() {
                return new BCryptPasswordEncoder();
        }
}
