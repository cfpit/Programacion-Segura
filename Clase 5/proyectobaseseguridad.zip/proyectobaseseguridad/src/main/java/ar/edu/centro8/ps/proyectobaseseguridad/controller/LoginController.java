package ar.edu.centro8.ps.proyectobaseseguridad.controller;

import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;

// Nota: Este controller genera HTML dinámico en Java (utilizado en la OPCIÓN 4).
// En la OPCIÓN 5, las vistas son servidas desde archivos estáticos HTML en src/main/resources/static/
@RestController
public class LoginController {

    @GetMapping("/login")
    public String loginPage(@RequestParam(value = "error", required = false) String error,
                            @RequestParam(value = "logout", required = false) String logout,
                            HttpServletRequest request) {
        
        // Obtener token CSRF de Spring Security
        CsrfToken csrfToken = (CsrfToken) request.getAttribute(CsrfToken.class.getName());

        StringBuilder html = new StringBuilder();
        html.append("<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Iniciar Sesión</title></head><body>");
        html.append("<h2>Iniciar Sesión</h2>");
        
        if (error != null) {
            html.append("<p style='color:red;'>⚠️ Usuario o contraseña incorrectos. Intente nuevamente.</p>");
        }
        
        if (logout != null) {
            html.append("<p style='color:green;'>✅ Ha cerrado sesión correctamente.</p>");
        }
        
        html.append("<form action='/login' method='post'>");
        
        // Campo oculto con token CSRF para que Spring Security valide la petición POST
        if (csrfToken != null) {
            html.append("  <input type='hidden' name='").append(csrfToken.getParameterName())
                .append("' value='").append(csrfToken.getToken()).append("' />");
        }
        
        html.append("  <div><label>Usuario: </label><input type='text' name='username' required /></div><br/>");
        html.append("  <div><label>Contraseña: </label><input type='password' name='password' required /></div><br/>");
        html.append("  <button type='submit'>Ingresar</button>");
        html.append("</form>");
        html.append("</body></html>");
        
        return html.toString();
    }
}
