# Proyecto Base de Seguridad con Spring Boot - Opción 5

Este proyecto demuestra la implementación de autenticación y autorización utilizando **Spring Security 6**, aplicando la **Opción 5: Separación de Backend y Vista mediante Archivos Estáticos HTML**.

---

## 🚀 ¿Qué es la Opción 5?

En la **Opción 5**, se desacopla la generación de HTML del código Java (`@RestController` o motores de plantillas como Thymeleaf/JSP). 

- **Frontend / Vista:** Archivos HTML5 estáticos con CSS y JavaScript alojados en `src/main/resources/static/` (`login.html` y `holaseg.html`).
- **Backend / Seguridad:** **Spring Security** gestiona las rutas protegidas, la autenticación (`POST /login`), el cierre de sesión (`POST /logout`) y la creación de sesiones HTTP (`JSESSIONID`).

---

## 📐 Diagrama de Flujo de Autenticación

```mermaid
sequenceDiagram
    autonumber
    actor Usuario
    participant Navegador as Navegador (HTML/JS)
    participant SpringSec as Spring Security
    participant StaticFiles as Archivos Estáticos (/static)

    title Flujo Completo de la Opción 5

    Note over Usuario, StaticFiles: 1. Intentar acceder a recurso protegido
    Usuario->>Navegador: Ingresa URL /holaseg.html
    Navegador->>SpringSec: GET /holaseg.html
    SpringSec-->>Navegador: 302 Redirect a /login.html (No Autenticado)
    Navegador->>StaticFiles: GET /login.html
    StaticFiles-->>Navegador: Retorna formulario estático de login

    Note over Usuario, StaticFiles: 2. Envío de Credenciales
    Usuario->>Navegador: Completa Usuario/Contraseña y presiona "Ingresar"
    Navegador->>SpringSec: POST /login (username, password)
    
    alt Autenticación Exitosa
        SpringSec-->>Navegador: Crea Cookie JSESSIONID + 302 Redirect a /holaseg.html
        Navegador->>StaticFiles: GET /holaseg.html (con Cookie JSESSIONID)
        SpringSec-->>StaticFiles: Autoriza Petición
        StaticFiles-->>Navegador: Muestra "Hola Mundo con seguridad"
    else Credenciales Incorrectas
        SpringSec-->>Navegador: 302 Redirect a /login.html?error=true
        Navegador->>StaticFiles: GET /login.html?error=true
        StaticFiles-->>Navegador: Carga login.html
        Note over Navegador: Script JS detecta "?error" y muestra alerta en rojo
    end

    Note over Usuario, StaticFiles: 3. Cierre de Sesión
    Usuario->>Navegador: Presiona botón "Cerrar sesión"
    Navegador->>SpringSec: POST /logout (con Cookie JSESSIONID)
    SpringSec->>SpringSec: Invalida JSESSIONID y destruye sesión
    SpringSec-->>Navegador: 302 Redirect a /login.html?logout=true
    Navegador->>StaticFiles: GET /login.html?logout=true
    StaticFiles-->>Navegador: Carga login.html
    Note over Navegador: Script JS detecta "?logout" y muestra alerta en verde
```

---

## ⚙️ Explicación Detallada del Código

### 1. Configuración de Seguridad (`SecurityConfig.java`)

```java
@Bean
public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
    return http
            // 1. Desactivación de CSRF para formularios HTML estáticos sin motor de plantillas
            .csrf(csrf -> csrf.disable())
            
            // 2. Definición de rutas públicas y protegidas
            .authorizeHttpRequests(auth -> auth
                    .requestMatchers("/holanoseg", "/login.html", "/css/**", "/js/**", "/favicon.ico").permitAll()
                    .anyRequest().authenticated())
            
            // 3. Configuración del Login con archivos estáticos
            .formLogin(form -> form
                    .loginPage("/login.html")                  // Archivo HTML estático en /static/login.html
                    .loginProcessingUrl("/login")               // Endpoint POST implícito de Spring Security
                    .defaultSuccessUrl("/holaseg.html", true)  // Vista estática destino tras autenticación correcta
                    .failureUrl("/login.html?error=true")      // Redirección con parámetro en caso de error
                    .permitAll())
            
            // 4. Configuración del Logout
            .logout(logout -> logout
                    .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
                    .logoutSuccessUrl("/login.html?logout=true") // Redirección tras cerrar sesión
                    .permitAll())
            .build();
}
```

#### Puntos Clave de la Configuración:
* **`csrf.disable()`:** Al ser un archivo HTML estático puro (sin Thymeleaf u otro renderizador), el formulario no cuenta con un token CSRF inyectado dinámicamente. Desactivar CSRF permite que la petición `POST /login` sea procesada sin error `403 Forbidden`.
* **`loginPage("/login.html")`:** Le indica a Spring Security que redirija las peticiones no autenticadas a la vista estática `/login.html` (petición `GET`).
* **`loginProcessingUrl("/login")`:** Define la URL endpoint donde Spring Security intercepta y procesa las credenciales enviadas por el formulario (petición `POST`). No requiere un `@PostMapping` manual en un Controller de Java; Spring Security valida `username` y `password` automáticamente.
* **¿Por qué `localhost:8080` redirige a `login.html`?:** La ruta raíz `/` no forma parte de los `.requestMatchers(...)` públicos, por lo que es protegida por `.anyRequest().authenticated()`. Al no estar autenticado, Spring Security intercepta la petición a `/` y redirige automáticamente a `/login.html`.

---

### 2. Formulario de Login Estático (`src/main/resources/static/login.html`)

El formulario HTML envía los parámetros `username` y `password` mediante `POST` a la ruta `/login`:

```html
<form action="/login" method="post">
    <div class="form-group">
        <label for="username">Usuario:</label>
        <input type="text" id="username" name="username" required placeholder="Ingrese su usuario">
    </div>

    <div class="form-group">
        <label for="password">Contraseña:</label>
        <input type="password" id="password" name="password" required placeholder="Ingrese su contraseña">
    </div>

    <button type="submit">Ingresar</button>
</form>
```

#### Manejo de Alertas con JavaScript:
Como el archivo es 100% estático, utiliza `URLSearchParams` para interpretar los parámetros devueltos por Spring Security:

```javascript
const urlParams = new URLSearchParams(window.location.search);

// Si Spring Security redirige a /login.html?error=true
if (urlParams.has('error')) {
    document.getElementById('alert-error').style.display = 'block';
}

// Si Spring Security redirige a /login.html?logout=true
if (urlParams.has('logout')) {
    document.getElementById('alert-logout').style.display = 'block';
}
```

---

### 3. Vista Protegida Estática (`src/main/resources/static/holaseg.html`)

Muestra el contenido protegido y proporciona un botón para cerrar la sesión mediante un formulario `POST`:

```html
<div class="container">
    <h1>Hola Mundo con seguridad</h1>
    <p>Esta es una vista protegida servida desde un archivo HTML estático en <code>/static</code>.</p>
    
    <!-- Formulario para invocar el logout en Spring Security -->
    <form action="/logout" method="post">
        <button type="submit" class="btn-logout">Cerrar sesión</button>
    </form>
</div>
```

---

## 🧪 Cómo Probar la Opción 5 Paso a Paso

### Paso 1: Configurar Credenciales de Prueba
La aplicación lee las credenciales desde variables de entorno. Puedes configurarlas en tu terminal o pasar los valores al ejecutar:

**En PowerShell (Windows):**
```powershell
$env:SS_USER="admin"
$env:SS_PASSWORD="123"
```

---

### Paso 2: Iniciar la Aplicación
Ejecuta el proyecto con Maven:

```bash
./mvnw spring-boot:run
```

---

### Paso 3: Probar los Escenarios de Seguridad

#### 1. Prueba de Protección (Redirección Automática)
* Abre tu navegador e ingresa a:  
  `http://localhost:8080/holaseg.html` o `http://localhost:8080/`
* **Resultado Esperado:** Al no estar autenticado, Spring Security te redirige automáticamente a `http://localhost:8080/login.html`.

#### 2. Prueba de Credenciales Incorrectas (Error)
* En la pantalla de login, ingresa un usuario o contraseña incorrectos y presiona **Ingresar**.
* **Resultado Esperado:** Redirección a `http://localhost:8080/login.html?error=true`. Aparece el cuadro en rojo:
  > `⚠️ Usuario o contraseña incorrectos. Intente nuevamente.`

#### 3. Prueba de Autenticación Exitosa
* Ingresa las credenciales válidas (ej: usuario `admin` y contraseña `123`).
* Presiona **Ingresar**.
* **Resultado Esperado:** Se otorga la cookie de sesión y serás redirigido exitosamente a `http://localhost:8080/holaseg.html`, mostrando la pantalla protegida **"Hola Mundo con seguridad"**.

#### 4. Prueba de Cierre de Sesión (Logout)
* En la pantalla protegida (`holaseg.html`), haz clic en el botón **Cerrar sesión**.
* **Resultado Esperado:** La sesión se destruye en el servidor y eres redirigido a `http://localhost:8080/login.html?logout=true`, mostrando el mensaje en verde:
  > `✅ Ha cerrado sesión correctamente.`
* Si intentas volver atrás o ingresar manualmente a `http://localhost:8080/holaseg.html`, serás derivado nuevamente al login.

---

## ❓ Preguntas Frecuentes (FAQ)

### ¿Por qué al ingresar a `localhost:8080` se ejecuta `login.html`?

1. **Petición a la ruta raíz (`/`):** Al escribir `localhost:8080` en el navegador, se realiza una petición HTTP a `/`.
2. **Evaluación de reglas en `SecurityConfig`:** La ruta `/` **no** está especificada dentro de los `.requestMatchers(...)` permitidos públicamente. Por ende, es evaluada por la regla `.anyRequest().authenticated()`.
3. **Interceptación de Spring Security:** Como la petición no cuenta con sesión activa, Spring Security invoca el punto de entrada de autenticación (`LoginUrlAuthenticationEntryPoint`), que genera una redirección **HTTP 302** hacia `/login.html` (definido en `.loginPage("/login.html")`).
4. **Servicio del archivo estático:** Al ser `/login.html` una ruta pública (`permitAll()`), Spring Boot busca y sirve la plantilla estática `src/main/resources/static/login.html`.

> **Nota:** Si en el futuro deseas que `localhost:8080` muestre una landing page pública (ej: un `index.html` sin requerir login), simplemente debes agregar `"/"` o `"/index.html"` a la lista de `.requestMatchers(...)` permitidos públicamente en `SecurityConfig.java`.

---

### ¿Qué diferencia hay entre `loginPage("/login.html")` y `loginProcessingUrl("/login")`?

* **`loginPage("/login.html")` (GET):** Especifica la ruta visual a la que se envía al usuario para mostrar el formulario (el HTML estático `login.html`).
* **`loginProcessingUrl("/login")` (POST):** Especifica el endpoint interno al que el formulario envía la información para que Spring Security procese las credenciales.
  * **No requiere Controller Java:** Spring Security intercepta directamente las peticiones `POST` enviadas a `/login`, verifica los campos `username` y `password`, e inicia la sesión o redirige según corresponda.
  * **Conexión con HTML:** En el archivo HTML, el formulario debe definir esa misma URL en su atributo `action`:
    ```html
    <form action="/login" method="POST">
        <input type="text" name="username">
        <input type="password" name="password">
        <button type="submit">Ingresar</button>
    </form>
    ```

