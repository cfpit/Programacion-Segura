# Trabajo Práctico N° 2 - API Calificaciones (Spring Boot + Security)

Aplicación minimalista en Java Spring Boot securizada con **Spring Security 6**.

---

## 📌 Endpoints

1. **`GET /califications`**: Devuelve la lista de las 8 calificaciones del trimestre.
   - Respuesta: `[8, 7, 6, 10, 9, 5, 7, 9]`

2. **`GET /califications/average`**: Devuelve el promedio numérico de las 8 calificaciones.
   - Respuesta: `7.625`

---

## 🔐 Seguridad

- Todos los endpoints están securizados con **Spring Security**.
- **Credenciales Demo:**
  - **Usuario:** `padre`
  - **Contraseña:** `padre123`

### Configuración en `SecurityConfig.java`:
- `.csrf(csrf -> csrf.disable())`: Deshabilita la protección contra **CSRF** (*Cross-Site Request Forgery*).
  - **¿Por qué está deshabilitada en este proyecto?**
    1. **Facilidad en desarrollo y pruebas:** Permite enviar peticiones HTTP mutativas (`POST`, `PUT`, `DELETE`) desde clientes de API (Bruno, Postman, cURL) sin que Spring Security exija incluir un token CSRF (`403 Forbidden`).
    2. **APIs REST y autenticación HTTP Basic:** Al autenticar peticiones directamente en la cabecera HTTP (`Authorization: Basic ...`) o mediante tokens en lugar de cookies de sesión del navegador, el riesgo de CSRF es prácticamente nulo.
  - **Nota:** Si la aplicación utilizara cookies de sesión en el navegador con formularios HTML (ej. Thymeleaf, JSP), la protección CSRF debería permanecer activada.
- `.authorizeHttpRequests(auth -> auth.anyRequest().authenticated())`: Define la regla de autorización global. Especifica que **absolutamente cualquier solicitud HTTP** (`anyRequest()`) enviada a la aplicación requiere que el usuario esté previamente autenticado (`authenticated()`). Si no se envían credenciales válidas, se denegará el acceso con un código `401 Unauthorized` (o se redirigirá al `/login`).
- `.httpBasic(Customizer.withDefaults())`: Habilita **HTTP Basic Authentication**. Esto permite que clientes de API como **Bruno**, **Postman** o **cURL** se autentiquen enviando las credenciales en la cabecera HTTP `Authorization: Basic ...` y reciban la respuesta JSON directamente o un código `401 Unauthorized` si no están autenticados.
- `.formLogin(form -> form.defaultSuccessUrl("/califications", true))`: 
  - **Habilita el formulario de login:** Muestra la pantalla de inicio de sesión de Spring Security en `http://localhost:8080/login`.
  - **Redirección automática (`defaultSuccessUrl`):** Configura que, tras un inicio de sesión exitoso, el navegador sea redirigido automáticamente a `/califications`. El segundo parámetro (`alwaysUse: true`) asegura que la redirección se realice siempre a ese endpoint.

### 🛡️ ¿Qué es CSRF?

**CSRF** significa **Cross-Site Request Forgery** (*Falsificación de solicitudes entre sitios*), y es un tipo de ataque informático que engaña a un usuario autenticado para que ejecute acciones no deseadas en una aplicación web sin su consentimiento.

#### ¿Cómo funciona?
- **Inicio de sesión:** El usuario entra a una página web legítima (por ejemplo, su banco) y mantiene su sesión abierta mediante cookies de autenticación.
- **Engaño:** El usuario visita un sitio web malicioso o hace clic en un enlace preparado por un atacante.
- **Petición oculta:** La página maliciosa envía una solicitud HTTP al sitio web legítimo usando las credenciales guardadas (cookies) del usuario de manera automática.
- **Acción no autorizada:** El servidor del sitio legítimo cree que la petición viene del usuario real y la ejecuta (como cambiar la contraseña, transferir dinero o borrar datos).

#### ¿Cómo se previene?
- **Tokens Anti-CSRF:** Se usan códigos secretos únicos y aleatorios por cada sesión o formulario que el servidor valida antes de aceptar cualquier cambio de estado.
- **Uso de Cookies Seguras:** Configurar los atributos de las cookies con la opción `SameSite` para restringir cómo se envían en solicitudes de otros sitios.

### 💡 ¿Qué es `JSESSIONID`?
- **En el Navegador:** Es el **nombre de la cookie** de sesión HTTP.
- **En el Servidor:** El **valor** de la cookie (ej: `XYZ123`) es el **ID único** con el que el servidor (Tomcat / Spring) localiza en memoria la sesión (`HttpSession`) asociada al usuario autenticado (usado en `.formLogin()`).

#### Flujo de autenticación con `JSESSIONID`:

```text
[ Navegador ]                                       [ Servidor (Spring Boot) ]
     │                                                          │
     │  ─── 1. POST /login (Credenciales correctas) ──────────> │
     │                                                          │ (Crea objeto HttpSession en memoria)
     │                                                          │ (Genera ID único: "XYZ123")
     │  <── 2. Resp: Set-Cookie: JSESSIONID=XYZ123 ──────────── │
     │                                                          │
 (Guarda la cookie JSESSIONID)                                  │
     │                                                          │
     │  ─── 3. GET /califications ────────────────────────────> │
     │         Header: Cookie: JSESSIONID=XYZ123                │ (Busca en memoria la sesión "XYZ123")
     │                                                          │ (Reconoce al usuario autenticado)
     │  <── 4. Resp: 200 OK + [8, 7, 6...] ─────────────────── │
```


---

## 📁 Estructura del Proyecto

```
tpn2/
├── pom.xml
├── bruno/                             <-- Colección Bruno API Client
│   ├── bruno.json
│   ├── environments/
│   │   └── Local.bru
│   ├── Get Califications - Authenticated.bru
│   ├── Get Average - Authenticated.bru
│   ├── Get Califications - Unauthenticated (401).bru
│   └── Get Average - Unauthenticated (401).bru
└── src/
    ├── main/java/com/escuela/tpn2/
    │   ├── Tpn2Application.java       <-- Clase Principal
    │   ├── config/
    │   │   └── SecurityConfig.java    <-- Configuración Spring Security
    │   └── controller/
    │       └── CalificationController.java <-- Controller REST
    └── test/java/com/escuela/tpn2/
        └── CalificationControllerTest.java <-- Pruebas Automatizadas
```

---

## 🧪 Pruebas con Bruno API Client

1. Abrir **Bruno**.
2. Seleccionar **Open Collection** y elegir la carpeta `bruno`.
3. Seleccionar el entorno **`Local`**.
4. Probar las peticiones preconfiguradas:
   - `GET /califications` (Autenticado) -> Devuelve `[8, 7, 6, 10, 9, 5, 7, 9]`
   - `GET /califications/average` (Autenticado) -> Devuelve `7.625`
   - Peticiones sin autenticar -> Devuelven `401 Unauthorized`

---

## 🚀 Ejecución

```bash
# Correr la aplicación
mvn spring-boot:run

# Correr las pruebas unitarias
mvn test
```
