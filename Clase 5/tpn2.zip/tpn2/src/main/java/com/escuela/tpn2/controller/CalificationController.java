package com.escuela.tpn2.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/califications")
public class CalificationController {

    // 8 calificaciones de 8 materias de un alumno (ejemplo del TP: 8, 7, 6, 10, 9,
    // 5, 7, 9)
    private final List<Integer> califications = List.of(8, 7, 6, 10, 9, 5, 7, 9);

    // GET /califications
    @GetMapping
    public List<Integer> getCalifications() {
        return califications;
    }

    // GET /califications/average
    @GetMapping("/average")
    public double getAverage() {
        return califications.stream()
                .mapToDouble(n -> n)
                .average()
                .orElse(0.0);
    }
}
