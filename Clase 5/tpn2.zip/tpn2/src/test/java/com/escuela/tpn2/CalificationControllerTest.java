package com.escuela.tpn2;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
public class CalificationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void unauthenticatedAccessToCalificationsIsDenied() throws Exception {
        mockMvc.perform(get("/califications"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    public void unauthenticatedAccessToAverageIsDenied() throws Exception {
        mockMvc.perform(get("/califications/average"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @WithMockUser(username = "padre", roles = {"PADRE"})
    public void authenticatedAccessToCalificationsReturnsList() throws Exception {
        mockMvc.perform(get("/califications"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$.length()", is(8)))
                .andExpect(jsonPath("$", contains(8, 7, 6, 10, 9, 5, 7, 9)));
    }

    @Test
    @WithMockUser(username = "padre", roles = {"PADRE"})
    public void authenticatedAccessToAverageReturns7625() throws Exception {
        mockMvc.perform(get("/califications/average"))
                .andExpect(status().isOk())
                .andExpect(content().string("7.625"));
    }
}
