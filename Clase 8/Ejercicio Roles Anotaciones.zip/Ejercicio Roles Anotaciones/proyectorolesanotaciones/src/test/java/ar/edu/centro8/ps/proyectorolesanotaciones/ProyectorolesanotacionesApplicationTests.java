package ar.edu.centro8.ps.proyectorolesanotaciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectorolesanotacionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
