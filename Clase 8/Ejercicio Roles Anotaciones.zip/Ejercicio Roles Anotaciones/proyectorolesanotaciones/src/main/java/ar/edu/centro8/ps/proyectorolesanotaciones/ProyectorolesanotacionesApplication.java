package ar.edu.centro8.ps.proyectorolesanotaciones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectorolesanotacionesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectorolesanotacionesApplication.class, args);
	}

}
