# Proyecto Roles y Anotaciones con Spring Security

Este proyecto muestra cómo implementar **seguridad basada en anotaciones a nivel de método** utilizando Spring Security con `@EnableMethodSecurity` y `@PreAuthorize`.

---

## 📌 Configuración de Seguridad

En la clase [`SecurityConfig.java`](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/ps/Clase%208/Ejercicio%20Roles%20Anotaciones/proyectorolesanotaciones/src/main/java/ar/edu/centro8/ps/proyectorolesanotaciones/security/config/SecurityConfig.java), se activa la seguridad a nivel de métodos usando:

```java
@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig { ... }
```

### Usuarios configurados en memoria (`UserDetailsService`):

| Usuario | Contraseña | Roles | Permisos (Authorities) |
| :--- | :--- | :--- | :--- |
| `centro8` | `1234` | `ADMIN` | `CREATE`, `READ`, `UPDATE`, `DELETE` |
| `seguidor` | `1234` | `USER` | `READ` |
| `actualizador` | `1234` | `USER` | `UPDATE` |

---

## 💡 Explicación de Anotaciones `@PreAuthorize` en Controller

En [`HelloWorldController.java`](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/ps/Clase%208/Ejercicio%20Roles%20Anotaciones/proyectorolesanotaciones/src/main/java/ar/edu/centro8/ps/proyectorolesanotaciones/controller/HelloWorldController.java), la seguridad se aplica tanto a nivel de clase (Controller) como a nivel de método:

```java
@RestController
@PreAuthorize("denyAll()")
public class HelloWorldController {

    @GetMapping("/holaseg")
    @PreAuthorize("hasAuthority('READ')")
    public String secHelloWorld() {
        return "Hola Mundo con seguridad";
    }

    @GetMapping("/holanoseg")
    @PreAuthorize("permitAll()")
    public String noSecHelloWorld() {
        return "Hola Mundo sin seguridad";
    }
}
```

### Detalle de las anotaciones utilizadas:

1. **`@PreAuthorize("denyAll()")`** *(A nivel de Clase)*:
   - **Propósito:** Deniega por defecto el acceso a todos los métodos del controlador a menos que un método especifique explícitamente una regla de acceso en su propia anotación.
   - **Estrategia:** Es una práctica de seguridad en capas (*Defense in Depth*). Garantiza que si se agrega un nuevo endpoint sin anotación explícita, no quede expuesto públicamente por accidente.

2. **`@PreAuthorize("hasAuthority('READ')")`** *(En el método `secHelloWorld` / GET `/holaseg`)*:
   - **Propósito:** Requiere que el usuario autenticado posea la autoridad/permiso de lectura (`READ`).
   - **Comportamiento:** 
     - Permite acceso a `centro8` (posee `READ`) -> **`200 OK`** (`Hola Mundo con seguridad`).
     - Permite acceso a `seguidor` (posee `READ`) -> **`200 OK`** (`Hola Mundo con seguridad`).
     - Deniega acceso a `actualizador` (solo posee `UPDATE`, no `READ`) -> **`403 Forbidden`**.
     - Peticiones anónimas/sin autenticar -> **`401 Unauthorized`**.

3. **`@PreAuthorize("permitAll()")`** *(En el método `noSecHelloWorld` / GET `/holanoseg`)*:
   - **Propósito:** Sobrescribe el `denyAll()` de la clase y permite el acceso libre a cualquier cliente (autenticado o anónimo).
   - **Comportamiento:** Retorna `200 OK` (`Hola Mundo sin seguridad`) a cualquiera que consulte el endpoint.

---

## 🧪 Pruebas con Bruno (Carpeta `bruno/`)

Se ha creado la carpeta [`bruno/`](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/ps/Clase%208/Ejercicio%20Roles%20Anotaciones/proyectorolesanotaciones/bruno) con las peticiones HTTP listas para importar y testear en [Bruno](https://www.usebruno.com/).

### Colección de Requests:

1. **`GET holanoseg`** (`holanoseg.bru`):
   - **URL:** `http://localhost:8080/holanoseg`
   - **Auth:** Ninguna (Pública)
   - **Respuesta esperada:** `200 OK`

2. **`GET holaseg (centro8)`** (`holaseg-centro8.bru`):
   - **URL:** `http://localhost:8080/holaseg`
   - **Auth:** Basic Auth (`centro8` / `1234`)
   - **Respuesta esperada:** `200 OK`

3. **`GET holaseg (seguidor)`** (`holaseg-seguidor.bru`):
   - **URL:** `http://localhost:8080/holaseg`
   - **Auth:** Basic Auth (`seguidor` / `1234`)
   - **Respuesta esperada:** `200 OK`

4. **`GET holaseg (actualizador)`** (`holaseg-actualizador.bru`):
   - **URL:** `http://localhost:8080/holaseg`
   - **Auth:** Basic Auth (`actualizador` / `1234`)
   - **Respuesta esperada:** `403 Forbidden` (No tiene el permiso `READ`)

---

## 🚀 Cómo ejecutar el proyecto

1. Ejecutar la aplicación Spring Boot:
   ```bash
   ./mvnw spring-boot:run
   ```
2. Abrir **Bruno**, seleccionar *Open Collection* y abrir la carpeta `bruno/` del proyecto.
