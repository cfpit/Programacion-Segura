package ar.edu.centro8.ps.oauth2github;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Oauth2githubApplicationTests {

	@Test
	void contextLoads() {
	}

}
