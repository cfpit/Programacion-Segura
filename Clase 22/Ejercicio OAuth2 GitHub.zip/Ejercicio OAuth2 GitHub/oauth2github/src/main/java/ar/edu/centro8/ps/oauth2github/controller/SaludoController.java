package ar.edu.centro8.ps.oauth2github.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@PreAuthorize("denyAll()")
public class SaludoController {

    @GetMapping("/decirhola")
    @PreAuthorize("permitAll()")
    public String decirHola(){
        return "Hola! Este endpoint no esta securizado";
    }

    @GetMapping("/decirholasec")
    @PreAuthorize("isAuthenticated()")
    public String decirHolaSec(){
        return "Hola! Este endpoint esta securizado";
    }
}
