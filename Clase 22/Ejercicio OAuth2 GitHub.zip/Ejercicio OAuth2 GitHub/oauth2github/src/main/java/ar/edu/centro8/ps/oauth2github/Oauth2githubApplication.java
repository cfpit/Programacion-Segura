package ar.edu.centro8.ps.oauth2github;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Oauth2githubApplication {

	public static void main(String[] args) {
		SpringApplication.run(Oauth2githubApplication.class, args);
	}

}
