# Colección Bruno - Oauth2GitHub

Esta carpeta contiene la colección de requests para [Bruno](https://www.usebruno.com/) para probar los endpoints de la aplicación Spring Boot.

## 📁 Estructura

- `bruno.json`: Archivo de configuración de la colección de Bruno.
- `environments/Local.bru`: Entorno local con las credenciales:
  - `username`: `user` (o el configurado en tu variable de entorno `SS_USER`)
  - `password`: `password` (o el configurado en tu variable de entorno `SS_PASSWORD`)
- `1-decirhola-publico.bru`: `GET http://localhost:8080/decirhola` (Endpoint público sin autenticación).
- `2-decirholasec-sin-auth.bru`: `GET http://localhost:8080/decirholasec` (Verifica que el endpoint protegido deniegue el acceso si no hay sesión).
- `3-login-form.bru`: `POST http://localhost:8080/login` (Autenticación tradicional por formulario; guarda automáticamente la cookie `JSESSIONID`).
- `4-decirholasec-autenticado.bru`: `GET http://localhost:8080/decirholasec` (Acceso al endpoint protegido con la sesión activa del login).
- `5-oauth2-github.bru`: `GET http://localhost:8080/oauth2/authorization/github` (Inicia el flujo de autorización OAuth2 con GitHub).
- `6-oauth2-google.bru`: `GET http://localhost:8080/oauth2/authorization/google` (Inicia el flujo de autorización OAuth2 con Google).
- `7-logout.bru`: `POST http://localhost:8080/logout` (Cierra la sesión actual).

## 🚀 Cómo usar en Bruno

1. Abre la aplicación **Bruno**.
2. Haz clic en **Open Collection**.
3. Selecciona esta carpeta `bruno` ubicada en la raíz del proyecto.
4. En la esquina superior derecha de Bruno, selecciona el entorno **Local**.
5. Para probar los endpoints protegidos:
   - Primero ejecuta la petición `3 - Login (Formulario)`.
   - Luego ejecuta `4 - Decir Hola Sec (Autenticado)` (Bruno conservará la cookie de sesión automáticamente).
6. Para reiniciar la sesión, ejecuta `7 - Logout`.
