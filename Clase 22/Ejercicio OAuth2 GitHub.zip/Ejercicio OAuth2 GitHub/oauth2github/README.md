# Ejercicio Spring Boot 3 - OAuth2 con GitHub y Google

Este proyecto es una aplicación de ejemplo desarrollada con **Spring Boot 3** y **Spring Security 6**, que implementa autenticación dual: mediante **formulario local (usuario y contraseña)** y mediante **proveedores externos OAuth2 (GitHub y Google)**, protegiendo endpoints REST mediante anotaciones de seguridad por método (`@PreAuthorize`).

---

## 📋 Tabla de Contenidos

- [Tecnologías Utilizadas](#-tecnologías-utilizadas)
- [Estructura del Proyecto](#-estructura-del-proyecto)
- [Endpoints Disponibles](#-endpoints-disponibles)
- [Configuración de Variables de Entorno](#-configuración-de-variables-de-entorno)
- [Registro de la OAuth App en GitHub](#-registro-de-la-oauth-app-en-github)
- [Flujo Detallado de Autenticación OAuth2 con GitHub](#-flujo-detallado-de-autenticación-oauth2-con-github)
- [Gestión de Sesiones, Logout y Comportamiento de SSO](#-gestión-de-sesiones-logout-y-comportamiento-de-sso)
  - [¿Por qué al hacer logout y reingresar con GitHub no pide credenciales?](#por-qué-al-hacer-logout-y-reingresar-con-github-no-pide-credenciales)
  - [Formas de probar la solicitud de credenciales](#formas-de-probar-la-solicitud-de-credenciales)
  - [Diferencia técnica: GitHub (OAuth 2.0) vs Google (OIDC)](#diferencia-técnica-github-oauth-20-vs-google-oidc)
- [Pruebas con la Colección Bruno](#-pruebas-con-la-colección-bruno)

---

## 🛠 Tecnologías Utilizadas

- **Java 21**
- **Spring Boot 3.4.3**
- **Spring Security 6** (Method Security, Form Login y OAuth2 Client)
- **Lombok**
- **Maven**
- **Bruno** (Cliente de APIs y testing)

---

## 📂 Estructura del Proyecto

```text
oauth2github/
├── bruno/                             # Colección Bruno para testear los endpoints
│   ├── environments/Local.bru
│   ├── 1-decirhola-publico.bru
│   ├── 2-decirholasec-sin-auth.bru
│   ├── 3-login-form.bru
│   ├── 4-decirholasec-autenticado.bru
│   ├── 5-oauth2-github.bru
│   ├── 6-oauth2-google.bru
│   ├── 7-logout.bru
│   ├── bruno.json
│   └── README.md
├── src/
│   ├── main/
│   │   ├── java/ar/edu/centro8/ps/oauth2github/
│   │   │   ├── Oauth2githubApplication.java
│   │   │   ├── config/security/
│   │   │   │   └── SecurityConfig.java       # Filtros de seguridad, redirecciones y login
│   │   │   └── controller/
│   │   │       └── SaludoController.java    # Endpoints público y securizado
│   │   └── resources/
│   │       └── application.properties        # Propiedades y mapeo de variables de entorno
└── pom.xml
```

---

## 🌐 Endpoints Disponibles

| Método | Endpoint | Acceso | Descripción |
|---|---|---|---|
| `GET` | `/decirhola` | **Público** (`permitAll()`) | Retorna mensaje sin requerir autenticación. |
| `GET` | `/decirholasec` | **Protegido** (`isAuthenticated()`) | Retorna mensaje securizado solo con sesión activa. |
| `GET` | `/login` | **Público** | Página de inicio de sesión generada por Spring Security. |
| `POST` | `/login` | **Público** | Procesa el inicio de sesión con usuario y contraseña locales. |
| `GET` | `/oauth2/authorization/github` | **Público** | Redirige al inicio de sesión y autorización en GitHub. |
| `GET` | `/oauth2/authorization/google` | **Público** | Redirige al inicio de sesión y autorización en Google. |
| `POST` | `/logout` | **Autenticado** | Invalida la sesión local de Spring Boot (`JSESSIONID`). |

---

## ⚙ Configuración de Variables de Entorno

El archivo `application.properties` requiere las siguientes variables de entorno para funcionar:

```properties
# Usuario en memoria para Form Login
SS_USER=admin
SS_PASSWORD=admin
ROLE=ADMIN

# Credenciales OAuth2 GitHub
GH_CLIENT_ID=tu_github_client_id
GH_CLIENT_SECRET=tu_github_client_secret

# Credenciales OAuth2 Google
GOOGLE_CLIENT_ID=tu_google_client_id
GOOGLE_CLIENT_SECRET=tu_google_client_secret
```

---

## 🐙 Registro de la OAuth App en GitHub

Para que la autenticación con GitHub funcione, debes crear una **OAuth App** en GitHub:

1. Ingresa a tu cuenta de GitHub y ve a **Settings** -> **Developer Settings** -> **OAuth Apps**.
2. Haz clic en **New OAuth App**.
3. Completa los campos:
   - **Application name:** `OAuth2 Spring Boot Demo` (o el nombre que elijas).
   - **Homepage URL:** `http://localhost:8080`
   - **Authorization callback URL (Crucial):** `http://localhost:8080/login/oauth2/code/github`
4. Guarda la aplicación y genera un **Client Secret**.
5. Asigna el `Client ID` a `GH_CLIENT_ID` y el `Client Secret` a `GH_CLIENT_SECRET`.

---

## 🔄 Flujo Detallado de Autenticación OAuth2 con GitHub

El flujo implementado se basa en el **Authorization Code Grant**:

```mermaid
sequenceDiagram
    autonumber
    actor Usuario
    participant Browser as Navegador Web
    participant Spring as Spring Boot (localhost:8080)
    participant GitHub as GitHub (github.com)

    Usuario->>Browser: Intenta ingresar a /decirholasec
    Browser->>Spring: GET /decirholasec (Sin sesión)
    Spring-->>Browser: 302 Redirect a /login
    Browser->>Spring: GET /login
    Spring-->>Browser: Muestra pantalla de login (Formulario + GitHub)
    Usuario->>Browser: Clic en "GitHub"
    Browser->>Spring: GET /oauth2/authorization/github
    Spring-->>Browser: 302 Redirect a GitHub con client_id, redirect_uri y state
    Browser->>GitHub: GET /login/oauth/authorize?...
    Note over Browser,GitHub: Si no hay sesión en GitHub, pide usuario/contraseña.<br/>Si es la primera vez, solicita consent (Authorize App).
    GitHub-->>Browser: 302 Redirect a /login/oauth2/code/github?code=AUTH_CODE&state=...
    Browser->>Spring: GET /login/oauth2/code/github?code=AUTH_CODE
    Note over Spring,GitHub: Comunicación directa Backend-to-Backend
    Spring->>GitHub: POST https://github.com/login/oauth/access_token (code + client_secret)
    GitHub-->>Spring: Devuelve Access Token
    Spring->>GitHub: GET https://api.github.com/user (con Bearer Token)
    GitHub-->>Spring: Devuelve perfil del usuario (id, login, name, etc.)
    Note over Spring: Crea Authentication (OAuth2User) y sesión local en cookie JSESSIONID
    Spring-->>Browser: 302 Redirect a /decirholasec (Set-Cookie: JSESSIONID=...)
    Browser->>Spring: GET /decirholasec (con Cookie JSESSIONID)
    Spring-->>Browser: 200 OK "Hola! Este endpoint esta securizado"
```

---

## 🔒 Gestión de Sesiones, Logout y Comportamiento de SSO

### ¿Por qué al hacer logout y reingresar con GitHub no pide credenciales?

Cuando un usuario interactúa con la aplicación a través de GitHub, coexisten **dos sesiones independientes** y **un consentimiento**:

1. **Sesión Local de la App (`localhost:8080`):** Gestionada por Spring Boot mediante la cookie de sesión `JSESSIONID`.
2. **Sesión Remota de GitHub (`github.com`):** Gestionada por las cookies de sesión que GitHub mantiene en tu navegador.
3. **Consentimiento (OAuth Grant):** La primera vez que iniciaste sesión, autorizaste la aplicación en GitHub. Esta autorización queda registrada en tu cuenta de GitHub de manera permanente.

#### Lo que sucede en el Logout:
* Al invocar `http://localhost:8080/logout`, Spring Security **invalida únicamente la sesión local** (`JSESSIONID`).
* Por aislamiento de dominios y seguridad web, tu aplicación **no puede ni debe cerrar la sesión del usuario en `github.com`**.

#### Lo que sucede al volver a hacer clic en "Log in with GitHub":
1. El navegador es redirigido a `https://github.com/login/oauth/authorize`.
2. GitHub recibe las cookies de sesión activa de `github.com` que ya están en tu navegador y comprueba que ya autorizaste previamente la aplicación.
3. Al estar ya autenticado y autorizado, GitHub no tiene nada que preguntar: genera inmediatamente un nuevo código de autorización y redirige de vuelta a Spring Boot.
4. Spring Boot crea una nueva sesión local y redirige a `/decirholasec`.

Para el usuario esto da la impresión de que "no se cerró la sesión" o "ingresó directo sin pedir usuario y contraseña", pero en realidad el flujo completo de OAuth2 se ejecutó de manera transparente.

---

### Formas de probar la solicitud de credenciales

Si deseas verificar el comportamiento cuando el usuario debe ingresar sus credenciales de GitHub o autorizar la aplicación:

1. **Ventana de Incógnito / Modo Privado (Recomendado):**
   - Abre una nueva ventana de incógnito. Al no compartir las cookies de `github.com` con tu sesión normal, GitHub te pedirá ingresar tu usuario y contraseña.
2. **Cerrar sesión en GitHub:**
   - Abre [github.com](https://github.com) y selecciona **Sign out**. Al volver a tu aplicación e intentar loguearte con GitHub, se te solicitarán las credenciales.
3. **Revocar el consentimiento en GitHub (para ver la pantalla de autorización):**
   - En GitHub, dirígete a **Settings** -> **Applications** -> pestaña **Authorized OAuth Apps**.
   - Ubica tu aplicación y pulsa **Revoke**. La próxima vez que inicies sesión, verás nuevamente la pantalla de aprobación de permisos.

---

### Diferencia técnica: GitHub (OAuth 2.0) vs Google (OIDC)

- **GitHub:** Es un proveedor OAuth 2.0 puro. No implementa la especificación completa de OpenID Connect (OIDC) y **no soporta el parámetro estándar `prompt=login` o `prompt=consent`** para forzar la re-autenticación en su endpoint de autorización.
- **Google:** Implementa OpenID Connect (OIDC). Permite configurar parámetros como `prompt=select_account` o `prompt=consent`, lo que permite forzar a que Google siempre muestre el selector de cuentas o pida credenciales aunque exista una sesión activa.

---

## 🧪 Pruebas con la Colección Bruno

En la carpeta [`bruno/`](./bruno/) se encuentra una colección lista para usar con el cliente [Bruno](https://www.usebruno.com/):

1. Abre **Bruno** y selecciona **Open Collection**.
2. Elige la carpeta `bruno` de este proyecto.
3. En la esquina superior derecha, selecciona el entorno **Local** (`baseUrl: http://localhost:8080`).
4. Peticiones disponibles en orden de ejecución sugerido:
   - `1 - Decir Hola (Público)`: Comprueba que `/decirhola` responde 200 sin autenticación.
   - `2 - Decir Hola Sec (Sin Autenticación)`: Comprueba que `/decirholasec` rechaza el acceso sin sesión.
   - `3 - Login (Formulario)`: Realiza login con usuario y contraseña locales; Bruno almacena automáticamente la cookie `JSESSIONID`.
   - `4 - Decir Hola Sec (Autenticado)`: Consume `/decirholasec` utilizando la sesión autenticada.
   - `5 - OAuth2 Login GitHub (Redirect)`: Verifica el endpoint de redirección hacia GitHub.
   - `6 - OAuth2 Login Google (Redirect)`: Verifica el endpoint de redirección hacia Google.
   - `7 - Logout`: Invalida la sesión local.
