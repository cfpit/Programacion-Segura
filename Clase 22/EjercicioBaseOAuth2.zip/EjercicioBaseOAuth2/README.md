# Proyecto Base: Autenticación con OAuth2 y Spring Security

Este proyecto implementa la **Parte 1 (Introducción)** del módulo de **Autenticación OAuth2 con Spring Security**, según las especificaciones de la guía académica adjunta.

---

## 📌 Tabla de Contenidos

1. [Descripción General](#-descripción-general)
2. [Fundamentos Teóricos de OAuth2](#-fundamentos-teóricos-de-oauth2)
   - [¿Qué es OAuth2?](#qué-es-oauth2)
   - [Roles en OAuth2](#roles-en-oauth2)
   - [Flujos de Autorización](#flujos-de-autorización)
   - [Flujo de Autenticación con GitHub (OAuth 2.0 vs. OIDC)](#flujo-de-autenticación-con-github-en-spring-security-oauth-20-vs-openid-connect)
     - [¿Por qué Spring Boot debe hacer dos peticiones a GitHub?](#por-qué-spring-boot-debe-hacer-dos-peticiones-a-github)
     - [¿Al cliente (navegador) le llega algún token o JWT?](#al-cliente-navegador-le-llega-algún-token-o-jwt)
   - [Ventajas de OAuth2](#ventajas-de-oauth2)
   - [¿Por qué utilizar OAuth2 con Spring Security?](#por-qué-utilizar-oauth2-con-spring-security)
3. [Tecnologías y Versiones](#-tecnologías-y-versiones)
4. [Estructura del Proyecto](#-estructura-del-proyecto)
5. [Análisis Detallado del Código](#-análisis-detallado-del-código)
   - [Controlador: `SaludoController`](#controlador-saludocontroller)
   - [Seguridad: `SecurityConfig`](#seguridad-securityconfig)
   - [Configuración: `application.properties`](#configuración-applicationproperties)
6. [Variables de Entorno](#-variables-de-entorno)
7. [Cómo Ejecutar el Proyecto](#-cómo-ejecutar-el-proyecto)
8. [Colección de Pruebas con Bruno](#-colección-de-pruebas-con-bruno)
   - [Requisito: URLs fijas en `http://localhost:8080`](#requisito-urls-fijas-en-httplocalhost8080)
   - [Paso a Paso de las Peticiones](#paso-a-paso-de-las-peticiones)
9. [Próximos Pasos (Partes 2 y 3)](#-próximos-pasos-partes-2-y-3)

---

## 📖 Descripción General

El objetivo de esta primera lección es sentar las bases conceptuales y arquitectónicas para la integración de **OAuth 2.0** en una aplicación web moderna construida con **Spring Boot 3** y **Spring Security 6**.

Se configuran dos mecanismos de autenticación simultáneos:

1. **Autenticación Tradicional basada en Formularios (`formLogin`)**: Utilizando un usuario en memoria configurado mediante propiedades y variables de entorno.
2. **Autenticación Delegada OAuth 2.0 (`oauth2Login`)**: Habilitando el pipeline de Spring Security para delegar la autenticación a proveedores de identidad externos (como GitHub o Google).

Adicionalmente, se implementa la seguridad a nivel de métodos (`@EnableMethodSecurity` y `@PreAuthorize`) siguiendo las mejores prácticas de defensa en profundidad.

---

## 📚 Fundamentos Teóricos de OAuth2

### ¿Qué es OAuth2?

**OAuth2** es un protocolo estándar de **autorización** ampliamente utilizado en la industria para permitir que un usuario autorice a una aplicación o servicio de terceros a acceder a sus recursos protegidos alojados en un servidor, **sin tener que compartir sus credenciales (usuario y contraseña)** con dicha aplicación.

En lugar de contraseñas, OAuth2 se basa en la emisión y uso de **tokens de acceso** (_access tokens_) con alcance (_scope_) y tiempo de vida delimitados.

---

### Roles en OAuth2

El estándar OAuth2 define cuatro entidades fundamentales:

```
+------------------+         (A) Autorización        +-------------------------------+
|  Resource Owner  | <-----------------------------> |            Client             |
|    (Usuario)     |                                 | (Nuestra aplicación Spring)   |
+------------------+                                 +-------------------------------+
                                                                 |     ^
                                             (B) Código / Token  |     | (C) Access Token
                                                                 v     |
+------------------------------+                     +-------------------------------+
|       Resource Server        | <------------------ |     Authorization Server      |
| (API protegida de GitHub/etc)|     (D) Request     |    (Servidor Auth GitHub)     |
+------------------------------+     con Token       +-------------------------------+
```

1. **Propietario de los Recursos (_Resource Owner_)**: Es el usuario final que posee los datos personales o recursos protegidos (ej. perfil, fotos, repositorios).
2. **Cliente (_Client_)**: Es la aplicación que solicita acceso a los recursos en nombre del propietario (en este caso, nuestra aplicación Spring Boot).
3. **Servidor de Autorización (_Authorization Server_)**: Es el servidor encargado de autenticar al propietario, solicitar su consentimiento y emitir tokens de acceso al cliente (ej. el servidor OAuth de GitHub o Google).
4. **Servidor de Recursos (_Resource Server_)**: Es el servidor que almacena y protege los datos del usuario. Valida los tokens de acceso entrantes y autoriza o deniega las peticiones.

---

### Flujos de Autorización

OAuth2 contempla distintos flujos adaptados a diferentes tipos de aplicaciones:

- **Authorization Code Flow**: Es el flujo estándar y más seguro para aplicaciones que se ejecutan en servidores (como Spring Boot), donde el _Client Secret_ se mantiene confidencial.
- **PKCE (Proof Key for Code Exchange)**: Extensión recomendada del Authorization Code Flow para clientes públicos (SPA, apps móviles).
- **Client Credentials Flow**: Utilizado para comunicación directa entre servicios (machine-to-machine) sin la presencia de un usuario final.
- **Implicit Flow** y **Resource Owner Password Credentials Flow**: Flujos considerados en desuso (_deprecated_) por motivos de seguridad en OAuth 2.1.

---

### Flujo de Autenticación con GitHub en Spring Security (OAuth 2.0 vs. OpenID Connect)

A diferencia de proveedores como Google (que implementan OpenID Connect y entregan un ID Token en formato JWT), GitHub opera como un proveedor OAuth 2.0 puro. Debido a esto, GitHub no devuelve un ID Token, sino un Access Token, lo que añade un paso específico para resolver la identidad del usuario.

El flujo detallado de autenticación con GitHub a través de Spring Security funciona de la siguiente manera:

1. **Intercepción del acceso**: Cuando un usuario no autenticado intenta ingresar a una ruta protegida de la aplicación, Spring Security intercepta la solicitud.
2. **Selección del proveedor**: Si la aplicación tiene configurado el cliente de GitHub, se presenta el acceso (por ejemplo, en la página autogenerada en `/login`).
3. **Redirección a GitHub**: Al seleccionar GitHub, el usuario es redirigido a los servidores de GitHub para identificarse y otorgar los permisos solicitados por la aplicación.
4. **Retorno a la aplicación con código de autorización**: Tras autorizar el acceso, GitHub redirige al usuario de vuelta a la aplicación a la URL de redirección (específicamente `/login/oauth2/code/github`) enviando un código de autorización.
5. **Intercambio por el Access Token**: Spring Security toma el código de autorización y lo intercambia directamente con GitHub para obtener el Access Token.
6. **Consulta a la API de usuario (`/user`)**: Al no recibir un ID Token con los datos de identidad, Spring Security utiliza de manera automática el Access Token recién obtenido para realizar una segunda petición a la API de GitHub en el endpoint `/user`, recuperando así los datos del perfil del usuario.
7. **Creación de la sesión**: Con la información del perfil obtenida, Spring Security genera un objeto `OAuth2AuthenticationToken` y lo almacena dentro del `SecurityContext`, dejando al usuario formalmente autenticado con una sesión activa en la aplicación.

#### ¿Por qué Spring Boot debe hacer dos peticiones a GitHub?

En el flujo anterior (pasos 5 y 6), tras recibir el código de autorización, Spring Boot realiza **dos peticiones servidor a servidor (_back-channel_)** a GitHub:

1. `POST https://github.com/login/oauth/access_token` (Intercambio de `code` + `client_secret` → `access_token`).
2. `GET https://api.github.com/user` (Consulta del perfil con `Authorization: Bearer <access_token>`).

Esto se debe a dos motivos fundamentales:

1. **GitHub es un proveedor OAuth 2.0 puro, NO OpenID Connect (OIDC)**:
   - **En proveedores OIDC (como Google o Azure AD)**: Al intercambiar el código, el servidor devuelve tanto el `access_token` como un `id_token` (un JWT firmado criptográficamente que ya contiene los datos del usuario: `sub`, `email`, `name`, etc.). En ese escenario, Spring Security ya conoce la identidad sin necesidad de peticiones adicionales.
   - **En GitHub (OAuth 2.0)**: El estándar OAuth 2.0 fue diseñado estrictamente para **autorización** (otorgar permisos de acceso a recursos), no para autenticación. La respuesta de GitHub contiene únicamente:
     ```json
     {
       "access_token": "gho_16C7eBAR2DhAlFT...",
       "scope": "read:user,user:email",
       "token_type": "bearer"
     }
     ```
     No contiene datos del perfil (nombre, ID, avatar, etc.). Spring Boot solo recibe una "llave de acceso", por lo que **está obligado a realizar una segunda petición** a la API de GitHub (`/user`) usando dicha llave para recuperar los datos reales del usuario y construir el `OAuth2User`.

2. **Separación de roles y seguridad (_Authorization Code Grant_)**:
   - **Servidor de Autorización vs. Servidor de Recursos**: En la arquitectura OAuth 2.0, el servidor que emite tokens (`github.com/login/oauth/...`) está separado de la API que sirve los datos protegidos (`api.github.com/user`).
   - **Seguridad del canal directo backend-to-backend**: El intercambio del código y la consulta del perfil se realizan directamente entre Spring Boot y GitHub. Ni el `client_secret` ni el `access_token` se exponen en el navegador del usuario.

| Proveedor  |       Estándar        | Respuesta al intercambiar el código             | ¿Requiere consulta a API de usuario?                  |
| :--------- | :-------------------: | :---------------------------------------------- | :---------------------------------------------------- |
| **Google** | OpenID Connect (OIDC) | `access_token` + `id_token` (JWT con identidad) | **Opcional** (la identidad ya está en el `id_token`). |
| **GitHub** |    OAuth 2.0 puro     | Únicamente `access_token` (llave opaca)         | **Obligatoria** (`GET /user` para saber quién es).    |

---

#### ¿Al cliente (navegador) le llega algún token o JWT?

**No por defecto.** Al navegador **no le llega ningún JWT ni tampoco el token de acceso de GitHub**.

Lo que el cliente recibe por defecto es una **cookie de sesión tradicional (`JSESSIONID`)**:

1. **El Access Token de GitHub no sale del servidor**:
   - Spring Security almacena el token de GitHub en memoria o base de datos dentro del componente `OAuth2AuthorizedClientService`.
   - **Nunca se envía al navegador** para evitar que código malicioso o vulnerabilidades XSS en el frontend comprometan la cuenta del usuario en GitHub.

2. **Gestión de la sesión en el navegador**:
   - Una vez autenticado, Spring Security genera una sesión HTTP en el servidor (`HttpSession`) y responde al navegador con la cabecera:
     ```http
     Set-Cookie: JSESSIONID=7A8B9C0D1E2F...; Path=/; HttpOnly; SameSite=Lax
     ```
   - En las peticiones posteriores, el navegador simplemente adjunta la cookie `JSESSIONID`. Spring Boot identifica la sesión existente en el `SecurityContext` y autoriza la petición de manera tradicional (_stateful_).

3. **Diferencia con arquitecturas basadas en JWT (SPAs / Móviles)**:

| Enfoque                       | Flujo por Defecto (Monolito / Spring MVC)                | Flujo API REST + Frontend desacoplado (React/Angular/Móvil)                                                             |
| :---------------------------- | :------------------------------------------------------- | :---------------------------------------------------------------------------------------------------------------------- |
| **Manejo de vista**           | Renderizado del lado del servidor (SSR, Thymeleaf, JSP). | Frontend desacoplado (Single Page Application, App móvil).                                                              |
| **Identificador del cliente** | Cookie de sesión **`JSESSIONID`** (_stateful_).          | **JWT de la aplicación** (_stateless_).                                                                                 |
| **Configuración en Spring**   | Invocación estándar de `.oauth2Login()`.                 | Requiere un `AuthenticationSuccessHandler` personalizado que genere y entregue un JWT firmado por la propia aplicación. |

> **Nota para arquitecturas desacopladas**: Si se desea que el cliente consuma una API mediante tokens JWT (por ejemplo, con `Authorization: Bearer <jwt>`), se debe configurar un `successHandler` en `.oauth2Login()` para que, una vez finalizado el flujo con GitHub, Spring Boot emita su propio JWT firmado y se lo entregue al frontend (vía redirección con parámetro o cookie segura `HttpOnly`).

---

### Ventajas de OAuth2

1. **Seguridad Mejorada**: Evita la exposición y almacenamiento de credenciales maestras de usuario en servidores de terceros.
2. **Control Granular de Acceso (_Scopes_)**: Permite solicitar permisos específicos (ej. sólo lectura del perfil público) sin conceder acceso total.
3. **Escalabilidad**: Al desacoplar la autenticación/autorización de la lógica del negocio, permite escalar servicios y microservicios mediante tokens criptográficos (ej. JWT).
4. **Interoperabilidad**: Al ser un estándar RFC abierto (RFC 6749 y RFC 6750), es adoptado universalmente por los principales proveedores (Google, GitHub, Microsoft, Meta, etc.).
5. **Experiencia de Usuario (UX)**: Permite flujos tipo Single Sign-On (SSO) rápidos, sin necesidad de crear contraseñas adicionales.

---

### ¿Por qué utilizar OAuth2 con Spring Security?

Spring Security proporciona una integración madura y altamente desacoplada con OAuth2:

- **Integración Nativa**: Soporte embebido a través del módulo `spring-boot-starter-oauth2-client`.
- **Configuración Simplificada**: Con tan solo invocar `.oauth2Login(Customizer.withDefaults())`, Spring Security autoconfigura los filtros de captura, endpoints de redirección y procesadores de tokens.
- **Comunidad Activa y Ecosistema**: Actualizaciones continuas, alineadas a los últimos estándares de seguridad de OWASP y el consorcio OAuth.

---

## 🛠 Tecnologías y Versiones

| Componente                  | Versión      | Descripción                                                                       |
| :-------------------------- | :----------- | :-------------------------------------------------------------------------------- |
| **Java JDK**                | **21 (LTS)** | Soporte nativo para virtual threads, modern switch expressions y record patterns. |
| **Spring Boot**             | **3.4.3**    | Última versión estable de la rama Spring Boot 3.4.                                |
| **Spring Web (Spring MVC)** | **6.2.3**    | Módulo web RESTful de Spring Framework.                                           |
| **Spring Security**         | **6.4.3**    | Módulo de seguridad, control de acceso y OAuth2 Client.                           |
| **Lombok**                  | **1.18.36**  | Última versión compatible con Java 21 para reducción de boilerplate.              |
| **Maven**                   | **3.9+**     | Gestor de dependencias y empaquetado del proyecto.                                |
| **Bruno**                   | **v1.x+**    | Cliente de pruebas API liviano y basado en archivos locales.                      |

---

## 📂 Estructura del Proyecto

```text
EjercicioBaseOAuth2/
├── pom.xml                                    # Descriptor de dependencias Maven
├── mvnw                                       # Script Maven Wrapper para Unix/Linux/macOS
├── mvnw.cmd                                   # Script Maven Wrapper para Windows
├── .gitignore                                 # Exclusiones de Git (target, IDEs, etc.)
├── README.md                                  # Documentación detallada del proyecto
├── .mvn/
│   └── wrapper/
│       └── maven-wrapper.properties           # Configuración del Maven Wrapper
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── ar/edu/centro8/ps/oauth2/
│   │   │       ├── Oauth2Application.java     # Clase principal (punto de entrada Spring Boot)
│   │   │       ├── config/
│   │   │       │   └── security/
│   │   │       │       └── SecurityConfig.java # Configuración de Spring Security Filter Chain
│   │   │       └── controller/
│   │   │           └── SaludoController.java  # Controlador con endpoints de prueba
│   │   └── resources/
│   │       └── application.properties         # Configuración y mapeo de variables de entorno
│   └── test/
│       └── java/
│           └── ar/edu/centro8/ps/oauth2/
│               └── Oauth2ApplicationTests.java # Prueba de carga de contexto
└── bruno/                                     # Colección de pruebas de Bruno
    ├── bruno.json                             # Metadatos de la colección
    ├── 01 - Decir Hola (Publico).bru          # GET http://localhost:8080/decirhola
    ├── 02 - Decir Hola Securizado (Sin Auth).bru # GET http://localhost:8080/decirholasec
    ├── 03 - Login Formulario (centro8).bru    # POST http://localhost:8080/login
    ├── 04 - Decir Hola Securizado (Autenticado).bru # GET http://localhost:8080/decirholasec (con sesión)
    ├── 05 - Pagina Login Spring Security.bru  # GET http://localhost:8080/login
    ├── 06 - Redireccion OAuth2 GitHub.bru     # GET http://localhost:8080/oauth2/authorization/github
    └── 07 - Logout (Cerrar Sesion).bru        # POST http://localhost:8080/logout
```

---

## 🔍 Análisis Detallado del Código

### Controlador: `SaludoController`

Ubicación: `src/main/java/ar/edu/centro8/ps/oauth2/controller/SaludoController.java`

```java
@RestController
@PreAuthorize("denyAll()")
public class SaludoController {

    @GetMapping("/")
    @PreAuthorize("permitAll()")
    public String inicio() {
        return "Bienvenido a la aplicación de autenticación OAuth2";
    }

    @GetMapping(value = "/login", params = "logout")
    @PreAuthorize("permitAll()")
    public void loginLogoutRedirect(HttpServletResponse response) throws IOException {
        response.sendRedirect("/login");
    }

    @GetMapping("/decirhola")
    @PreAuthorize("permitAll()")
    public String decirHola() {
        return "Hola! Este endpoint no esta securizado";
    }

    @GetMapping("/decirholasec")
    @PreAuthorize("isAuthenticated()")
    public String decirHolaSec() {
        return "Hola! Este endpoint esta securizado";
    }
}
```

- **`@PreAuthorize("denyAll()")` en la clase**: Implementa el principio de **Defensa en Profundidad**. Por defecto, si se crea un nuevo endpoint y el desarrollador olvida agregar una anotación de seguridad, el acceso será denegado a todos.
- **`@GetMapping("/")` con `@PreAuthorize("permitAll()")`**: Endpoint raíz de bienvenida. Permite que al completar el flujo de inicio de sesión por formulario (`formLogin`), la redirección por defecto a `/` responda con `200 OK` en clientes HTTP que siguen redirecciones (como Bruno o navegadores).
- **`@GetMapping(value = "/login", params = "logout")`**:
  - **Mapeo por parámetro de consulta (_Query Params_)**: La condición `params = "logout"` hace que este método solo se ejecute si la petición HTTP `GET` a `/login` contiene el parámetro `logout` en la URL (ej. `GET http://localhost:8080/login?logout`).
  - **Limpieza de URL tras Logout**: Cuando el usuario cierra sesión (`POST /logout`), Spring Security invalida la sesión y redirige por defecto a `/login?logout` (para mostrar el mensaje _"You have been logged out"_). Este método intercepta esa petición específica y ejecuta `response.sendRedirect("/login")`, limpiando la barra de direcciones del navegador para dejar la URL en `/login` limpio.
  - **Acceso público con `@PreAuthorize("permitAll()")`**: Al estar la clase protegida globalmente con `denyAll()`, esta anotación asegura que un usuario anónimo recién deslogueado pueda ser redirigido sin recibir un error `403 Forbidden`.
- **`@PreAuthorize("permitAll()")` en `/decirhola`**: Sobrescribe la regla de clase permitiendo el acceso público e irrestricto, sin requerir credenciales ni token.
- **`@PreAuthorize("isAuthenticated()")` en `/decirholasec`**: Exige que la petición provenga de un usuario autenticado (bien sea por sesión de formulario o mediante OAuth2).

---

### Seguridad: `SecurityConfig`

Ubicación: `src/main/java/ar/edu/centro8/ps/oauth2/config/security/SecurityConfig.java`

```java
@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
        return httpSecurity
                .csrf(csrf -> csrf.disable())
                .formLogin(Customizer.withDefaults())
                .oauth2Login(Customizer.withDefaults())
                .logout(logout -> logout
                        .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
                        .logoutSuccessUrl("/login")
                        .invalidateHttpSession(true)
                        .clearAuthentication(true)
                        .deleteCookies("JSESSIONID")
                )
                .build();
    }
}
```

- **`@EnableWebSecurity`**: Activa la infraestructura de seguridad web de Spring Security.
- **`@EnableMethodSecurity`**: Habilita el procesamiento de las anotaciones `@PreAuthorize`, `@PostAuthorize` y `@Secured` en los controladores y servicios.
- **`.csrf(csrf -> csrf.disable())`**: Deshabilita la protección Cross-Site Request Forgery para facilitar las pruebas directas mediante clientes HTTP (como Bruno, Postman o cURL).
- **`.formLogin(Customizer.withDefaults())`**: Habilita la autenticación por formulario clásica:
  - Genera la ruta `/login` con un formulario HTML por defecto.
  - Procesa peticiones `POST /login` con campos `username` y `password`.
  - Establece una sesión HTTP con cookie `JSESSIONID`.
- **`.oauth2Login(Customizer.withDefaults())`**: Habilita el soporte para inicio de sesión con proveedores OAuth 2.0:
  - Expone los endpoints de inicio de autorización (ej. `/oauth2/authorization/{registrationId}`).
  - Habilita el filtro `OAuth2LoginAuthenticationFilter` para interceptar la respuesta con el código de autorización (_authorization code_) y realizar el intercambio por el token de acceso.
- **`.logout(...)`**: Configura el cierre de sesión explícito:
  - Expone la ruta `/logout` (admitiendo tanto `POST` como `GET` mediante `AntPathRequestMatcher`).
  - Invalida la sesión (`invalidateHttpSession(true)`).
  - Limpia el contexto de autenticación (`clearAuthentication(true)`).
  - Elimina la cookie `JSESSIONID` del cliente (`deleteCookies("JSESSIONID")`).
  - Redirige directamente a `/login` tras el cierre exitoso para mostrar el formulario de acceso.

---

### Configuración: `application.properties`

Ubicación: `src/main/resources/application.properties`

```properties
spring.application.name=oauth2

# Configuraciones de seguridad
spring.security.user.name=${SS_USER:centro8}
spring.security.user.password=${SS_PASSWORD:1234}
spring.security.user.roles=${ROLE:ADMIN}

# Configuración base de OAuth2 Client
spring.security.oauth2.client.registration.github.client-id=${GITHUB_CLIENT_ID:dummy-github-client-id}
spring.security.oauth2.client.registration.github.client-secret=${GITHUB_CLIENT_SECRET:dummy-github-client-secret}
```

#### ¿Por qué la sintaxis `${VARIABLE:valor_por_defecto}`?

El PDF solicita configurar las variables de entorno `SS_USER`, `SS_PASSWORD` y `ROLE` con los valores `centro8`, `1234` y `ADMIN`. Utilizando la sintaxis `${VAR:default}`:

1. Si defines las variables en tu sistema o IDE, Spring Boot toma el valor inyectado.
2. Si ejecutas la aplicación de forma directa, no fallará con `Could not resolve placeholder`, sino que adoptará automáticamente los datos de prueba indicados en el PDF.
3. Para `oauth2Login()`, Spring Boot requiere que exista al menos un cliente registrado (`ClientRegistrationRepository`). Los valores por defecto de GitHub permiten que la aplicación arranque de inmediato en esta **Parte 1 (Introducción)**, dejándola lista para colocar las credenciales reales en la **Parte 2**.

---

## 🔑 Variables de Entorno

Para configurar manualmente las variables en tu entorno según el PDF:

| Variable      | Valor de Prueba (PDF) | Descripción                                   |
| :------------ | :-------------------- | :-------------------------------------------- |
| `SS_USER`     | `centro8`             | Nombre de usuario para el formulario de login |
| `SS_PASSWORD` | `1234`                | Contraseña para el formulario de login        |
| `ROLE`        | `ADMIN`               | Rol asignado al usuario                       |

### Configuración en Windows (PowerShell):

```powershell
$env:SS_USER="centro8"
$env:SS_PASSWORD="1234"
$env:ROLE="ADMIN"
mvn spring-boot:run
```

### Configuración en Windows (CMD):

```cmd
set SS_USER=centro8
set SS_PASSWORD=1234
set ROLE=ADMIN
mvn spring-boot:run
```

### Configuración en IDE (IntelliJ IDEA / Eclipse / VS Code):

En la configuración de ejecución (_Run/Debug Configurations_) de `Oauth2Application`:

- **Environment variables**: `SS_USER=centro8;SS_PASSWORD=1234;ROLE=ADMIN`

---

## 🚀 Cómo Ejecutar el Proyecto

1. **Verificar versión de Java**:

   ```bash
   java -version
   ```

   _Debe ser Java 21._

2. **Compilar el proyecto**:

   ```bash
   mvn clean compile
   ```

   _(O mediante el wrapper: `./mvnw clean compile` o `mvnw.cmd clean compile`)_

3. **Iniciar la aplicación Spring Boot**:
   ```bash
   mvn spring-boot:run
   ```

La aplicación quedará escuchando en `http://localhost:8080`.

---

## 🧪 Colección de Pruebas con Bruno

Todas las peticiones de prueba se encuentran en la carpeta `bruno/`.

### Requisito: URLs fijas en `http://localhost:8080`

> [!IMPORTANT]
> Cumpliendo con la instrucción solicitada, **ninguna petición utiliza variables de entorno como `baseUrl` o `{{baseUrl}}`**. Todas las solicitudes tienen configurada de manera explícita la URL fija `http://localhost:8080/...`.

### Paso a Paso de las Peticiones

Para probar el ciclo completo de autenticación y autorización:

```
[ 01: GET /decirhola ] ------> 200 OK (Público)

[ 02: GET /decirholasec ] ---> 302 Redirige a /login (No autenticado)

[ 03: POST /login ] ---------> 302 / 200 Establece JSESSIONID (centro8 / 1234)

[ 04: GET /decirholasec ] ---> 200 OK con mensaje securizado (Autenticado con cookie)

[ 05: GET /login ] ----------> 200 OK Devuelve HTML con formulario y enlace OAuth2

[ 06: GET /oauth2/authorization/github ] -> 302 Redirige a GitHub OAuth
```

#### Detalle de cada archivo `.bru`:

1. **`01 - Decir Hola (Publico).bru`**:
   - **Método**: `GET`
   - **URL**: `http://localhost:8080/decirhola`
   - **Autenticación**: Ninguna
   - **Resultado esperado**: Código `200 OK`.
   - **Cuerpo de respuesta**: `"Hola! Este endpoint no esta securizado"`

2. **`02 - Decir Hola Securizado (Sin Auth).bru`**:
   - **Método**: `GET`
   - **URL**: `http://localhost:8080/decirholasec`
   - **Autenticación**: Ninguna
   - **Resultado esperado**:
     - **Con redirecciones automáticas activas (por defecto en Bruno)**: Devuelve **`200 OK`** con el **código HTML de la página de inicio de sesión de Spring Security** (`<title>Please sign in</title>`). Esto confirma que el endpoint bloqueó el acceso no autenticado y redirigió a `/login`.
     - **Con redirecciones desactivadas (_Settings -> Follow Redirects_ desactivado)**: Devuelve **`302 Found`** con la cabecera `Location: http://localhost:8080/login`.

> [!NOTE]
> **¿Por qué devuelve `200 OK` con código HTML al probar sin sesión o tras hacer Logout?**
>
> 1. **Sin sesión activa**: Al no haber iniciado sesión (o tras ejecutar `07 - Logout`), no existe ninguna sesión ni cookie activa.
> 2. **El endpoint bloquea el acceso**: Al intentar acceder a `/decirholasec`, `@PreAuthorize("isAuthenticated()")` detecta que el usuario no está autenticado y le deniega el acceso.
> 3. **Redirección al Login (`302 Found`)**: Como no estás autenticado, Spring Security responde con un `302 Found` indicando la redirección: `Location: http://localhost:8080/login`.
> 4. **Bruno sigue la redirección**: Bruno tiene activada la opción de seguir redirecciones (_Follow Redirects_), por lo que va automáticamente a `http://localhost:8080/login`.
> 5. **Resultado final**: La página `/login` carga exitosamente y devuelve **`200 OK`** con el HTML del formulario de login de Spring Security para que el usuario ingrese sus datos.
>
> | Estado del usuario                       | Petición a `/decirholasec` | Respuesta final en Bruno                                                           |
> | :--------------------------------------- | :------------------------- | :--------------------------------------------------------------------------------- |
> | **Autenticado** (tras ejecutar 03)       | Tiene sesión activa        | `200 OK`: `"Hola! Este endpoint esta securizado"`                                  |
> | **Sin autenticar** (sin login o tras 07) | No tiene sesión            | `200 OK`: Devuelve el HTML de la página de Login (`<title>Please sign in</title>`) |

3. **`03 - Login Formulario (centro8).bru`**:
   - **Método**: `POST`
   - **URL**: `http://localhost:8080/login`
   - **Tipo de cuerpo**: `x-www-form-urlencoded`
   - **Campos**:
     - `username`: `centro8`
     - `password`: `1234`
   - **Resultado esperado**: Spring Security autentica las credenciales y devuelve una cookie de sesión `Set-Cookie: JSESSIONID=...`.
     - Si Bruno sigue las redirecciones (por defecto), llegará al endpoint raíz `/` y responderá **`200 OK`**: `"Bienvenido a la aplicación de autenticación OAuth2"`.
     - Si se desactivan las redirecciones en _Settings_, responderá **`302 Found`** hacia `http://localhost:8080/` con la cookie de sesión.

4. **`04 - Decir Hola Securizado (Autenticado).bru`**:
   - **Método**: `GET`
   - **URL**: `http://localhost:8080/decirholasec`
   - **Condición**: Ejecutar después de haber ejecutado la petición 03.
   - **Resultado esperado**: Código `200 OK`.
   - **Cuerpo de respuesta**: `"Hola! Este endpoint esta securizado"`

5. **`05 - Pagina Login Spring Security.bru`**:
   - **Método**: `GET`
   - **URL**: `http://localhost:8080/login`
   - **Resultado esperado**: Código `200 OK` con el HTML de la página de login por defecto de Spring Security, mostrando tanto los campos de usuario/contraseña (`formLogin`) como el enlace hacia el proveedor externo (`oauth2Login`).

6. **`06 - Redireccion OAuth2 GitHub.bru`**:
   - **Método**: `GET`
   - **URL**: `http://localhost:8080/oauth2/authorization/github`
   - **Resultado esperado**: Código `302 Found` con la cabecera `Location` apuntando a `https://github.com/login/oauth/authorize?response_type=code&client_id=...&scope=read:user&state=...`, iniciando el flujo de autorización OAuth2.

7. **`07 - Logout (Cerrar Sesion).bru`**:
   - **Método**: `POST` (o `GET`)
   - **URL**: `http://localhost:8080/logout`
   - **Resultado esperado**: Invalida la sesión actual, limpia el contexto de seguridad, elimina la cookie `JSESSIONID` y redirige a `http://localhost:8080/login`. En Bruno responderá `200 OK` cargando la página de login de Spring Security. Permite volver a ejecutar la petición `02 - Decir Hola Securizado (Sin Auth)` para verificar que deniega el acceso al no contar con sesión activa.

---

## 🔮 Próximos Pasos (Partes 2 y 3)

Tal como se menciona en el documento introductorio:

- **Parte 2 (Autenticación vía GitHub)**:
  - Crear una _OAuth App_ en la consola de desarrollador de GitHub (`Settings -> Developer Settings -> OAuth Apps`).
  - Obtener el `Client ID` y generar un nuevo `Client Secret`.
  - Configurar la URL de callback: `http://localhost:8080/login/oauth2/code/github`.
  - Reemplazar las variables `GITHUB_CLIENT_ID` y `GITHUB_CLIENT_SECRET`.
- **Parte 3 (Autenticación vía Google)**:
  - Crear un proyecto en _Google Cloud Console_.
  - Configurar la pantalla de consentimiento OAuth y crear credenciales de tipo _ID de cliente de OAuth 2.0_.
  - Agregar la URL de redirección autorizada: `http://localhost:8080/login/oauth2/code/google`.
  - Añadir las propiedades correspondientes a Google en `application.properties`.
