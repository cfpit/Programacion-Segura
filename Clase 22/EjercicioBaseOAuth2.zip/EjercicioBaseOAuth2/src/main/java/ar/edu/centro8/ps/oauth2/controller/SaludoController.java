package ar.edu.centro8.ps.oauth2.controller;

import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@PreAuthorize("denyAll()")
public class SaludoController {

    @GetMapping("/")
    @PreAuthorize("permitAll()")
    public String inicio() {
        return "Bienvenido a la aplicación de autenticación OAuth2";
    }

    @GetMapping(value = "/login", params = "logout")
    @PreAuthorize("permitAll()")
    public void loginLogoutRedirect(HttpServletResponse response) throws IOException {
        response.sendRedirect("/login");
    }

    @GetMapping("/decirhola")
    @PreAuthorize("permitAll()")
    public String decirHola() {
        return "Hola! Este endpoint no esta securizado";
    }

    @GetMapping("/decirholasec")
    @PreAuthorize("isAuthenticated()")
    public String decirHolaSec() {
        return "Hola! Este endpoint esta securizado";
    }
}
