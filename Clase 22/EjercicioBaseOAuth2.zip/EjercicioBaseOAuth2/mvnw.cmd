@REM ----------------------------------------------------------------------------
@REM Maven Start Up Batch script
@REM ----------------------------------------------------------------------------

@IF "%__MVNW_ARG0_NAME__%"=="" (SET __MVNW_ARG0_NAME__=%~nx0)
@SET __EXEC_DIR__=%~dp0
@SET __EXEC_DIR__=%__EXEC_DIR:~0,-1%

@REM Provide a "clean" bash environment
@SET SHELL=

@REM Initialize %WRAPPER_JAR%
@SET WRAPPER_JAR="%__EXEC_DIR__%\.mvn\wrapper\maven-wrapper.jar"

@IF NOT EXIST "%WRAPPER_JAR%" (
  @REM Fallback to maven if wrapper jar not found
  mvn %*
) ELSE (
  @REM Execute wrapper jar
  java -jar "%WRAPPER_JAR%" %*
)
