# Proyecto de Autenticación y Encriptación con Spring Security

Proyecto desarrollado en Spring Boot enfocado en la gestión de permisos, roles, usuarios y la **encriptación segura de contraseñas** usando `BCryptPasswordEncoder` en conjunto con Spring Security.

---

## 🔐 ¿Cómo Funciona la Encriptación de Contraseñas?

### 1. Algoritmo Utilizado: BCrypt
Spring Security provee e implementa la interfaz `PasswordEncoder` mediante **BCryptPasswordEncoder**:
- **Función Hash Criptográfica Unidireccional**: No es reversible (no existe un método para "desencriptar" el texto original a partir del hash).
- **Salt Aleatorio Automático (Salting)**: En cada cifrado, genera un valor aleatorio ("sal") que se incorpora al hash final. Esto garantiza que dos usuarios con la misma contraseña (`123456`) tengan hashes almacenados totalmente distintos, protegiendo la base de datos de ataques con tablas arcoíris (*rainbow tables*).
- **Factor de Trabajo (Cost Factor)**: Por defecto usa una fuerza o costo de 10 rondas de hashing ($2^{10} = 1024$ iteraciones), haciendo que los ataques de fuerza bruta sean computacionalmente costosos y lentos.

### 2. Estructura del Hash BCrypt
Un hash generado por BCrypt tiene 60 caracteres y sigue el formato:
```text
$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy
│  │   └────────────┬───────────┘└─────────────┬─────────────┘
│  │                │                          └─ Hash cifrado (31 caracteres)
│  │                └─ Salt aleatorio (22 caracteres)
│  └─ Costo computacional (10 rondas)
└─ Versión del algoritmo ($2a$, $2b$ o $2y$)
```

### 3. Flujo en el Código

#### A. Cifrado al Crear el Usuario
Al registrar un usuario a través del controlador [`UserController.createUser()`](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/ps/Clase%2015/Ejercicio%20Encriptado/encriptado/src/main/java/ar/edu/centro8/ps/encriptado/controller/UserController.java#L40-L64), se invoca [`UserService.encriptPassword()`](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/ps/Clase%2015/Ejercicio%20Encriptado/encriptado/src/main/java/ar/edu/centro8/ps/encriptado/service/UserService.java#L44-L46):

```java
// UserService.java
@Override
public String encriptPassword(String password) {
    return new BCryptPasswordEncoder().encode(password);
}
```
El valor en texto plano nunca se guarda en la base de datos; únicamente se almacena la cadena hasheada resultante.

#### B. Verificación Durante la Autenticación (Login / Basic Auth)
Cuando un cliente hace una petición HTTP con cabecera `Authorization: Basic <credentials>`:
1. Spring Security intercepta las credenciales recibidas en texto plano (`username` y `password`).
2. Mediante [`UserDetailsServiceImp`](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/ps/Clase%2015/Ejercicio%20Encriptado/encriptado/src/main/java/ar/edu/centro8/ps/encriptado/service/UserDetailsServiceImp.java), busca el usuario en la BD por su nombre de usuario y obtiene el hash guardado.
3. El componente [`DaoAuthenticationProvider`](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/ps/Clase%2015/Ejercicio%20Encriptado/encriptado/src/main/java/ar/edu/centro8/ps/encriptado/security/config/SecurityConfig.java#L49-L57) utiliza el `PasswordEncoder` configurado:
   ```java
   passwordEncoder.matches(rawPassword, encodedPasswordFromDatabase);
   ```
4. `matches()` extrae el *salt* almacenado en el hash de la BD, aplica el mismo algoritmo a la contraseña ingresada por el usuario y compara ambos hashes. Si coinciden, la autenticación es exitosa.

---

## 🗄️ Configuración de la Base de Datos

En [`application.properties`](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/ps/Clase%2015/Ejercicio%20Encriptado/encriptado/src/main/resources/application.properties):
```properties
spring.jpa.hibernate.ddl-auto=update
spring.datasource.url=jdbc:mysql://localhost:3306/security?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=
```
> El parámetro `createDatabaseIfNotExist=true` permite a MySQL crear la base de datos `security` automáticamente en caso de no existir al iniciar la aplicación.

---

## 🚀 Pruebas con Bruno

En la carpeta [`bruno/`](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/ps/Clase%2015/Ejercicio%20Encriptado/encriptado/bruno) se incluye una colección completa lista para importar en [Bruno API Client](https://www.usebruno.com/):

### Orden sugerido para probar el flujo:
1. **`01-Crear Permiso READ`** (`POST /api/permissions`): Crea el permiso de lectura.
2. **`02-Crear Rol ADMIN`** (`POST /api/roles`): Crea el rol `ADMIN` asociando el permiso ID 1.
3. **`03-Crear Usuario (Cifrado)`** (`POST /api/users`):
   - Envía contraseña en texto claro (ej: `"miPassword123"`).
   - Verifica en la respuesta que el campo `password` devuelto sea un hash que empieza con `$2a$10$...`.
4. **`04-Listar Usuarios`** (`GET /api/users`): Confirma cómo persiste el hash en la base de datos.
5. **`05-Endpoint Sin Seguridad`** (`GET /holanoseg`): Accesible libremente (`200 OK`).
6. **`06-Endpoint Con Seguridad - Auth OK`** (`GET /holaseg`):
   - Autenticación HTTP Basic con usuario `martin` y contraseña `miPassword123`.
   - Verifica que el usuario se autentica correctamente contra el hash y que tiene la autoridad `READ` (`200 OK: Hola Mundo con seguridad`).
7. **`07-Endpoint Con Seguridad - Auth Fallida`** (`GET /holaseg`):
   - Prueba con credenciales incorrectas para verificar el rechazo (`401 Unauthorized`).

