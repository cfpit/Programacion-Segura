package ar.edu.centro8.ps.encriptado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EncriptadoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EncriptadoApplication.class, args);
	}

}
