package ar.edu.centro8.ps.encriptado.repository;
import ar.edu.centro8.ps.encriptado.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IRoleRepository extends JpaRepository<Role, Long> {
}
