package ar.edu.centro8.ps.ejemplojjwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjemplojjwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
