# Proyecto JPA - Relación 1 a 1 (Auto y Motor)

Este proyecto es una aplicación desarrollada con **Spring Boot**, **Spring Data JPA** y **MySQL**, orientada a ejemplificar el modelado, persistencia y consumo vía API REST de una relación **Uno a Uno (`@OneToOne`)** entre dos entidades: `Auto` y `Motor`.

---

## 📌 Tabla de Contenidos
1. [Descripción General](#-descripción-general)
2. [Explicación Detallada de la Relación 1 a 1 (@OneToOne)](#-explicación-detallada-de-la-relación-1-a-1-onetoone)
   - [¿Qué es una relación 1 a 1?](#qué-es-una-relación-1-a-1)
   - [Unidireccional vs Bidireccional](#unidireccional-vs-bidireccional)
   - [Entidad Propietaria (Owner) y Clave Foránea (FK)](#entidad-propietaria-owner-y-clave-foránea-fk)
   - [Estrategia con @JoinColumn](#estrategia-con-joincolumn)
   - [Tipo de Carga (FetchType.EAGER vs LAZY)](#tipo-de-carga-fetchtypeeager-vs-lazy)
   - [Efectos en la Base de Datos](#efectos-en-la-base-de-datos)
3. [Estructura del Proyecto y Capas](#-estructura-del-proyecto-y-capas)
4. [Endpoints de la API REST](#-endpoints-de-la-api-rest)
5. [Colección Bruno para Pruebas](#-colección-bruno-para-pruebas)
6. [Cómo Ejecutar el Proyecto](#-cómo-ejecutar-el-proyecto)

---

## 📖 Descripción General

El sistema modela un parque automotor simple donde:
- Cada **Auto** tiene asignado exactamente un **Motor**.
- Cada **Motor** posee características técnicas propias (como su cilindrada en cc).
- En este caso de uso, se implementa una relación **unidireccional**, donde `Auto` conoce a su `Motor`, pero `Motor` es independiente y no necesita mantener una referencia hacia `Auto`.

---

## 🔍 Explicación Detallada de la Relación 1 a 1 (@OneToOne)

### ¿Qué es una relación 1 a 1?
Una relación de cardinalidad **1:1** indica que una instancia de una entidad $A$ está asociada exclusivamente con una sola instancia de una entidad $B$, y viceversa. En nuestro dominio:
- Un registro en la tabla `auto` se vincula con un único registro en la tabla `motores`.

### Unidireccional vs Bidireccional
- **Unidireccional (Adoptada en este proyecto)**:
  Solo una de las clases Java (`Auto`) tiene el atributo del tipo de la otra (`Motor`). La clase `Motor` no tiene ningún atributo `Auto`.
  - **Ventaja**: Evita problemas de dependencias circulares, referencias cíclicas al serializar en JSON y mantiene el modelo más simple.
- **Bidireccional**:
  Ambas entidades se conocen mutuamente (`Auto` tiene `Motor` y `Motor` tiene `Auto`). Requiere el uso de `mappedBy` en el lado inverso y cuidado especial en los serializadores (usando `@JsonManagedReference` / `@JsonBackReference` o `@JsonIgnore`) para no provocar `StackOverflowError`.

---

### Entidad Propietaria (Owner) y Clave Foránea (FK)

En JPA, la **entidad propietaria** de la relación es aquella que contiene la columna de clave foránea (`FOREIGN KEY`) en la base de datos física.

En este proyecto, `Auto` es la entidad propietaria:

```java
@Entity
@Table(name = "auto")
@Getter
@Setter
@NoArgsConstructor
public class Auto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idAuto;

    @Column(name = "marca", nullable = false)
    private String marca;

    @Column(name = "precio", nullable = false)
    private BigDecimal precio;

    // RELACIÓN UNIDIRECCIONAL 1 A 1
    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id_motor", referencedColumnName = "idMotor")
    private Motor motor;

    public Auto(String marca, BigDecimal precio, Motor motor) {
        this.marca = marca;
        this.precio = precio;
        this.motor = motor;
    }
}
```

Y la entidad `Motor` es autónoma:

```java
@Entity
@Table(name = "motores")
@Getter
@Setter
@NoArgsConstructor
public class Motor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idMotor;

    @Column(name = "cilindrada", nullable = false)
    private Integer cilindrada;

    public Motor(Integer cilindrada) {
        this.cilindrada = cilindrada;
    }
}
```

---

### Estrategia con `@JoinColumn`

La anotación `@JoinColumn` define cómo se mapea la columna en la base de datos que actuará de nexo:

- `name = "id_motor"`: Es el nombre físico de la columna que JPA/Hibernate creará dentro de la tabla `auto`.
- `referencedColumnName = "idMotor"`: Es la columna de la tabla `motores` a la cual apunta esta clave foránea (por defecto, la clave primaria de `Motor`).

---

### Tipo de Carga (`FetchType.EAGER` vs `FetchType.LAZY`)

En `@OneToOne`, el valor por defecto de JPA es `FetchType.EAGER`:
- **`FetchType.EAGER` (Ansiosa/Temprana)**:
  Al consultar un `Auto`, Hibernate realiza automáticamente una consulta con `JOIN` (o una consulta secundaria inmediata) para traer también la información de su `Motor`. Resulta ideal cuando siempre que consultas un auto necesitas mostrar los datos del motor.
- **`FetchType.LAZY` (Perezosa)**:
  Los datos del motor solo se consultan a la base de datos cuando se invoca explícitamente `auto.getMotor()`. En relaciones 1 a 1 unidireccionales con `@JoinColumn` también es soportado, pero requiere que la sesión de Hibernate permanezca abierta (por ejemplo mediante `@Transactional`).

---

### Efectos en la Base de Datos

Hibernate genera un esquema relacional equivalente al siguiente DDL:

```sql
CREATE TABLE motores (
    id_motor BIGINT AUTO_INCREMENT PRIMARY KEY,
    cilindrada INT NOT NULL
);

CREATE TABLE auto (
    id_auto BIGINT AUTO_INCREMENT PRIMARY KEY,
    marca VARCHAR(255) NOT NULL,
    precio DECIMAL(38,2) NOT NULL,
    id_motor BIGINT UNIQUE,
    CONSTRAINT fk_auto_motor FOREIGN KEY (id_motor) REFERENCES motores(id_motor)
);
```

> **Nota:** La restricción `UNIQUE` en la columna `id_motor` garantiza a nivel de base de datos que ningún motor pueda pertenecer a más de un automóvil simultáneamente, asegurando la integridad estricta de la relación 1 a 1.

---

## 🏛 Estructura del Proyecto y Capas

El proyecto sigue una arquitectura en capas desacoplada:

```
src/main/java/ar/edu/centro8/desarrollo/proyectojpa1a1/
├── controllers/          # Capa Web/REST (AutoController, MotorController)
├── models/               # Entidades JPA (Auto, Motor)
├── repositories/         # Interfaces Spring Data JPA (IAutoRepository, IMotorRepository)
├── services/             # Capa de Lógica de Negocio (AutoService, MotorService)
└── Proyectojpa1a1Application.java
```

- **Capa de Servicios**: Implementada mediante clases de servicio (`AutoService` y `MotorService`) anotadas con `@Service` y `@Transactional`, sin interfaces intermedias, simplificando el flujo de desarrollo.
- **Capa de Controladores**: Exponen endpoints REST con soporte de CORS (`@CrossOrigin`) para integrarse con clientes web o herramientas de prueba.

---

## 🚀 Endpoints de la API REST

### 1. Motores (`/api/motores`)

| Método | Endpoint | Descripción | Body (JSON) |
|---|---|---|---|
| `GET` | `/api/motores` | Obtener listado de todos los motores | Ninguno |
| `GET` | `/api/motores/{id}` | Obtener un motor por su ID | Ninguno |
| `POST` | `/api/motores` | Crear un nuevo motor | `{"cilindrada": 1600}` |
| `PUT` | `/api/motores/{id}` | Actualizar un motor existente | `{"idMotor": 1, "cilindrada": 2000}` |
| `DELETE` | `/api/motores/{id}` | Eliminar un motor por su ID | Ninguno |

### 2. Autos (`/api/autos`)

| Método | Endpoint | Descripción | Body (JSON) |
|---|---|---|---|
| `GET` | `/api/autos` | Obtener listado de todos los autos (incluye su motor) | Ninguno |
| `GET` | `/api/autos/{id}` | Obtener un auto por su ID | Ninguno |
| `POST` | `/api/autos` | Crear un auto vinculándolo a un motor existente | `{"marca": "Toyota Corolla", "precio": 25000.00, "motor": {"idMotor": 1}}` |
| `PUT` | `/api/autos/{id}` | Actualizar datos del auto | `{"idAuto": 1, "marca": "Toyota Corolla GR", "precio": 32000.00}` |
| `DELETE` | `/api/autos/{id}` | Eliminar un auto por su ID | Ninguno |

---

## 🧪 Colección Bruno para Pruebas

El proyecto incluye una carpeta [`bruno/`](./bruno) lista para ser abierta con [Bruno API Client](https://www.usebruno.com/):

```
bruno/
├── Autos/
│   ├── Obtener todos los autos.bru
│   ├── Obtener auto por ID.bru
│   ├── Crear auto.bru
│   ├── Actualizar auto.bru
│   └── Eliminar auto.bru
├── Motores/
│   ├── Obtener todos los motores.bru
│   ├── Obtener motor por ID.bru
│   ├── Crear motor.bru
│   ├── Actualizar motor.bru
│   └── Eliminar motor.bru
├── environments/
│   └── local.bru (baseUrl: http://localhost:8080)
├── bruno.json
└── collection.bru
```

---

## ⚙️ Cómo Ejecutar el Proyecto

### Requisitos Previos
- **Java 17** o superior instalado.
- Servidor **MySQL** activo en el puerto `3306` (configurado en `application.properties` con usuario `root` y contraseña `1234`).

### Pasos
1. Clonar o abrir la carpeta del proyecto en la terminal.
2. Compilar el proyecto:
   ```bash
   .\mvnw.cmd compile
   ```
3. Ejecutar la aplicación:
   ```bash
   .\mvnw.cmd spring-boot:run
   ```
4. La aplicación iniciará en `http://localhost:8080`.
