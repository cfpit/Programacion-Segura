package ar.edu.centro8.desarrollo.proyectojpa1a1.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ar.edu.centro8.desarrollo.proyectojpa1a1.models.Motor;
import ar.edu.centro8.desarrollo.proyectojpa1a1.repositories.IMotorRepository;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class MotorService {
    @Autowired
    private IMotorRepository motorRepo;
    
    public List<Motor> obtenerMotores() {
        return motorRepo.findAll();
    }

    
    public Motor guardarMotor(Motor motor) {
        return motorRepo.save(motor);
    }

    public boolean eliminarMotor(Long idMotor) {
        try {
            motorRepo.deleteById(idMotor);
            return true; // El motor se eliminó con éxito
        } catch (Exception e) {
            return false; // No se pudo eliminar el motor
        }
    }

    public Motor traerMotor(Long idMotor) {
        return motorRepo.findById(idMotor).orElse(null);
    }

    public Motor editarMotor(Long idOriginal, Long idNueva, Integer nuevaCilindrada) {
        // Busco el objeto original
        Motor motor = this.traerMotor(idOriginal);
        
        // Proceso de modificación a nivel lógico
        motor.setIdMotor(idNueva);
        motor.setCilindrada(nuevaCilindrada);
        
        // Guardar los cambios
        this.guardarMotor(motor);

        return motor;
    }
}
