package ar.edu.centro8.ps.ejemplobase2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejemplobase2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
