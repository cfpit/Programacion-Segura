package ar.edu.centro8.ps.ejemplobase2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplobase2Application {

	public static void main(String[] args) {
		SpringApplication.run(Ejemplobase2Application.class, args);
	}

}
