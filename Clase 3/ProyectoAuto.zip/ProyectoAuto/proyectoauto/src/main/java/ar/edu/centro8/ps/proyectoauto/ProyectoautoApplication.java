package ar.edu.centro8.ps.proyectoauto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoautoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoautoApplication.class, args);
	}

}
