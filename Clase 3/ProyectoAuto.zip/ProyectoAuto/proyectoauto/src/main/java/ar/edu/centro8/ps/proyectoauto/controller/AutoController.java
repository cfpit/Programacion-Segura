package ar.edu.centro8.ps.proyectoauto.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import ar.edu.centro8.ps.proyectoauto.model.Auto;
import ar.edu.centro8.ps.proyectoauto.repository.AutoRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*", methods = {RequestMethod.GET,RequestMethod.POST,RequestMethod.PUT,RequestMethod.DELETE})
public class AutoController {
    @Autowired
    private AutoRepository autoRepo;

    @GetMapping("/auto/traer")
    public List<Auto> traerAutos() {
        return autoRepo.findAll() ;
    }

    @PostMapping("/auto/crear")
    public void crearAuto(@RequestBody Auto a) {
        autoRepo.save(a);
    }
}
