package ar.edu.centro8.ps.proyectoauto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoautoApplicationTests {

	@Test
	void contextLoads() {
	}

}
