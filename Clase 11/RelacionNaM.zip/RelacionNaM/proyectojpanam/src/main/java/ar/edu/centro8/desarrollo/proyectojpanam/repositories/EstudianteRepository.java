package ar.edu.centro8.desarrollo.proyectojpanam.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import ar.edu.centro8.desarrollo.proyectojpanam.models.Estudiante;

public interface EstudianteRepository extends JpaRepository<Estudiante,Long> {

}
