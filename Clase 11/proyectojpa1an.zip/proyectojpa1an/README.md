# Proyecto JPA: Relación 1 a N (One-to-Many Bidireccional)

Aplicación desarrollada con **Spring Boot**, **Spring Data JPA**, **Hibernate** y **MySQL** que ejemplifica el modelado, persistencia y exposición vía API REST de una relación **1 a N (Uno a Muchos)** bidireccional entre las entidades **Concesionaria** y **Auto**.

---

## 📌 Tabla de Contenidos
1. [Descripción General](#descripción-general)
2. [Arquitectura y Tecnologías](#arquitectura-y-tecnologías)
3. [Estructura del Proyecto](#estructura-del-proyecto)
4. [Explicación a Fondo: Relación 1 a N](#explicación-a-fondo-relación-1-a-n)
   - [Lado Padre: Entidad Concesionaria](#lado-padre-entidad-concesionaria)
   - [Lado Hijo: Entidad Auto](#lado-hijo-entidad-auto)
   - [Evitar Recursión Infinita en JSON](#evitar-recursión-infinita-en-json)
   - [Métodos de Conveniencia (Sincronización Bidireccional)](#métodos-de-conveniencia-sincronización-bidireccional)
5. [Configuración de Base de Datos](#configuración-de-base-de-datos)
6. [Endpoints de la API](#endpoints-de-la-api)
7. [Pruebas con Colección Bruno](#pruebas-con-colección-bruno)

---

## 📖 Descripción General

El dominio modela el caso típico donde:
- **Una Concesionaria** puede tener asociados **muchos Autos** ($1 \rightarrow N$).
- **Un Auto** pertenece obligatoriamente o contextualmente a **una única Concesionaria** ($N \rightarrow 1$).
- La relación es **bidireccional**: desde una concesionaria podemos consultar su lista de autos, y desde un auto podemos saber a qué concesionaria está asignado.

---

## 🛠 Arquitectura y Tecnologías

- **Java 17+**
- **Spring Boot 3.x**:
  - `spring-boot-starter-web` (API REST)
  - `spring-boot-starter-data-jpa` (Persistencia ORM con Hibernate)
- **Lombok**: Generación de getters, setters y constructores.
- **MySQL**: Motor de base de datos relacional.
- **Bruno**: Cliente API ligero para testing de endpoints.

---

## 📂 Estructura del Proyecto

```text
proyectojpa1an/
├── bruno/                             # Peticiones HTTP listas para probar
│   ├── Autos/                         # Endpoints CRUD de Autos
│   └── Concesionarias/                # Endpoints CRUD de Concesionarias y asignación
├── src/main/java/ar/edu/centro8/desarrollo/proyectojpa1an/
│   ├── controllers/                   # Controladores REST (@RestController)
│   │   ├── AutoController.java
│   │   └── ConcesionariaController.java
│   ├── models/                        # Entidades JPA (@Entity)
│   │   ├── Auto.java                  # Lado propietario (fk: id_concesionaria)
│   │   └── Concesionaria.java         # Lado inverso (@OneToMany)
│   ├── repositories/                  # Repositorios JPA (JpaRepository)
│   │   ├── AutoRepository.java
│   │   └── ConcesionariaRepository.java
│   └── services/                      # Lógica de negocio (@Service)
│       ├── AutoService.java
│       └── ConcesionariaService.java
└── src/main/resources/
    └── application.properties         # Conexión MySQL y parámetros Hibernate
```

---

## 🔬 Explicación a Fondo: Relación 1 a N

En JPA/Hibernate, las relaciones bidireccionales 1 a N se componen de dos partes:
1. **Lado Inverso (Padre / Concesionaria)**: define el `@OneToMany`.
2. **Lado Propietario (Hijo / Auto)**: define el `@ManyToOne` y tiene la clave foránea real en la base de datos (`id_concesionaria`).

### Lado Padre: Entidad `Concesionaria`

```java
@OneToMany(mappedBy = "concesionaria", cascade = CascadeType.ALL, orphanRemoval = true)
@JsonManagedReference
private List<Auto> autos;
```

#### Desglose de cada elemento sintáctico:

1. **`@OneToMany`**:
   - Indica que una instancia de `Concesionaria` se asocia con múltiples instancias de `Auto`.

2. **`mappedBy = "concesionaria"`**:
   - **¿Qué hace?**: Indica que esta entidad **no es la dueña de la relación** en la base de datos.
   - **¿A qué apunta?**: Al nombre del **atributo en la clase `Auto`** (el campo privado `private Concesionaria concesionaria;`).
   - **¿Por qué es fundamental?**: Si omites `mappedBy`, Hibernate asumirá que no existe una columna foránea y creará por defecto una tabla intermedia innecesaria (ej. `concesionaria_autos`). Con `mappedBy`, Hibernate sabe que debe utilizar la columna foránea ya declarada en la tabla `auto`.

3. **`cascade = CascadeType.ALL`**:
   - **¿Qué hace?**: Propaga todas las operaciones de persistencia (`PERSIST`, `MERGE`, `REMOVE`, `REFRESH`, `DETACH`) desde el padre hacia los hijos.
   - **Efecto práctico**: Al guardar una `Concesionaria` (`concesionariaRepository.save(concesionaria)`), todos los autos contenidos en su lista `autos` son persistidos o actualizados automáticamente sin necesidad de llamar a `autoRepository.save()` por separado para cada uno. De igual manera, al eliminar una concesionaria, se eliminan todos sus autos asociados.

4. **`orphanRemoval = true`**:
   - **¿Qué hace?**: Activa el borrado de "hijos huérfanos".
   - **Diferencia con cascade delete**: Si remueves un auto de la colección en memoria (`concesionaria.getAutos().remove(auto)`), al guardar la concesionaria, Hibernate detecta que ese auto ya no pertenece a la colección y ejecuta automáticamente una sentencia `DELETE FROM auto WHERE id_auto = ?`.

---

### Lado Hijo: Entidad `Auto`

```java
@ManyToOne
@JoinColumn(name = "id_concesionaria")
@JsonBackReference
private Concesionaria concesionaria;
```

#### Desglose de cada elemento sintáctico:

1. **`@ManyToOne`**:
   - Indica que múltiples filas de la tabla `auto` pueden apuntar a una misma `Concesionaria`.
   - Por defecto, el fetch type en `@ManyToOne` es `EAGER` (ansioso).

2. **`@JoinColumn(name = "id_concesionaria")`**:
   - **¿Qué hace?**: Declara explícitamente cuál es la columna de **clave foránea (Foreign Key)** en la tabla física `auto`.
   - Representa el lado propietario de la relación, ya que almacena físicamente el valor del ID del padre.

---

### 🔄 Evitar Recursión Infinita en JSON (Jackson)

Cuando serializamos entidades bidireccionales a JSON:
- `Concesionaria` serializa su lista de `Auto`.
- Cada `Auto` a su vez serializa su `Concesionaria`.
- Esa `Concesionaria` vuelve a serializar sus `Auto`, generando un bucle infinito (`StackOverflowError`).

Para resolverlo se utilizan:
- **`@JsonManagedReference`** (en `Concesionaria.autos`):
  - Marca la parte "hacia adelante" de la referencia. Este campo sí se incluye normalmente en la respuesta JSON.
- **`@JsonBackReference`** (en `Auto.concesionaria`):
  - Marca la parte "hacia atrás". Jackson omite este campo durante la serialización para cortar el ciclo.

---

### 🤝 Métodos de Conveniencia (Sincronización Bidireccional)

Para mantener sincronizado el estado tanto en memoria (Java) como en la base de datos (JPA), en `Concesionaria` se implementa un método de conveniencia:

```java
public Auto agregarAuto(Auto auto) {
    this.autos.add(auto);
    auto.setConcesionaria(this); // Sincroniza ambos extremos
    return auto;
}
```

Al utilizar este método, aseguramos que el objeto `Auto` conoce a su `Concesionaria` y la lista de la `Concesionaria` incluye al `Auto`, evitando desincronizaciones antes de persistir.

---

## ⚙ Configuración de Base de Datos

En `src/main/resources/application.properties`:

```properties
spring.application.name=proyectojpa1an
spring.jpa.hibernate.ddl-auto=update
spring.datasource.url=jdbc:mysql://localhost:3306/jpa_relaciones2?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=1234
logging.level.root=INFO
```

- **`createDatabaseIfNotExist=true`**: Crea automáticamente la base de datos `jpa_relaciones2` si aún no existe en MySQL.
- **`spring.jpa.hibernate.ddl-auto=update`**: Hibernate sincroniza automáticamente las tablas y claves foráneas a partir de las entidades `@Entity`.

---

## 🌐 Endpoints de la API

La API se ejecuta por defecto en `http://localhost:8080`.

### 🏢 Concesionarias (`/api/concesionarias`)

| Método | Endpoint | Descripción | Body Ejemplo |
| :--- | :--- | :--- | :--- |
| **GET** | `/api/concesionarias` | Lista todas las concesionarias con sus autos | N/A |
| **GET** | `/api/concesionarias/{id}` | Obtiene una concesionaria por ID | N/A |
| **POST** | `/api/concesionarias` | Crea una nueva concesionaria | `{"nombre": "Concesionaria Norte"}` |
| **PUT** | `/api/concesionarias/{id}` | Edita el nombre de una concesionaria | `{"id": 1, "nombre": "Nuevo Nombre"}` |
| **DELETE** | `/api/concesionarias/{id}` | Elimina una concesionaria (y sus autos por cascada) | N/A |
| **POST** | `/api/concesionarias/autos` | Crea un auto asignándolo a una concesionaria existente | Ver abajo |

#### Payload para asociar Auto a Concesionaria:
```json
POST /api/concesionarias/autos
{
  "marca": "Toyota Corolla",
  "precio": 25000.0,
  "concesionaria": {
    "id": 1
  }
}
```

---

### 🚗 Autos (`/api/autos`)

| Método | Endpoint | Descripción | Body Ejemplo |
| :--- | :--- | :--- | :--- |
| **GET** | `/api/autos` | Lista todos los autos | N/A |
| **GET** | `/api/autos/{id}` | Obtiene un auto por ID | N/A |
| **POST** | `/api/autos` | Crea un auto individual | `{"marca": "Ford Focus", "precio": 18000.0}` |
| **PUT** | `/api/autos/{id}` | Actualiza marca o precio de un auto | `{"idAuto": 1, "marca": "Ford Focus ST", "precio": 22000.0}` |
| **DELETE** | `/api/autos/{id}` | Elimina un auto por ID | N/A |

---

## 🧪 Pruebas con Colección Bruno

El proyecto incluye la carpeta `bruno/` lista para abrir directamente en el cliente [Bruno](https://www.usebruno.com/):

1. Abre **Bruno**.
2. Selecciona **Open Collection** y elige la carpeta `bruno` del proyecto.
3. Todas las peticiones apuntan directamente a `http://localhost:8080`, sin requerir configuraciones adicionales.
