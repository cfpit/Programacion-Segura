package ar.edu.centro8.desarrollo.proyectojpa1a1.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import ar.edu.centro8.desarrollo.proyectojpa1a1.models.Motor;
import ar.edu.centro8.desarrollo.proyectojpa1a1.services.MotorService;

import java.util.List;

@RestController
@RequestMapping("/api/motores")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class MotorController {
    @Autowired
    private MotorService motorService;

    @GetMapping
    public List<Motor> getAllMotors() {
        List<Motor> motores = motorService.obtenerMotores();
        return motores;
    }

    @GetMapping("/{id}")
    public Motor getMotorById(@PathVariable Long id) {
        return motorService.traerMotor(id);
    }

    @PostMapping
    public void createMotor(@RequestBody Motor motor) {
        motorService.guardarMotor(motor);
    }

    @PutMapping("/{id}")
    public void updateMotor(@PathVariable Long id, @RequestBody Motor motor) {
         motorService.editarMotor(id,motor.getIdMotor(),motor.getCilindrada());
    }

    @DeleteMapping("/{id}")
    public void deleteMotor(@PathVariable Long id) {
        motorService.eliminarMotor(id);
    }
}
