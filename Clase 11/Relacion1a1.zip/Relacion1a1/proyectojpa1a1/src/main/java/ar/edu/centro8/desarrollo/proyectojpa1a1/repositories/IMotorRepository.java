package ar.edu.centro8.desarrollo.proyectojpa1a1.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import ar.edu.centro8.desarrollo.proyectojpa1a1.models.Motor;

@Repository
public interface IMotorRepository extends JpaRepository<Motor, Long> {

}
