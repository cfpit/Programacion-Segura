SELECT * FROM jpa_relaciones.auto;	

SELECT * FROM jpa_relaciones.motor;	

-- relacion 
select *
from auto a
inner join motor m on m.id_motor = a.id_motor;

-- relacion bidireccional FK-PK y PK Compartida
-- Se debe eliminar primero el auto y luego el motor
delete from auto where id_motor = 1;
delete from motor where id_motor = 1;

