SELECT * FROM jpa_relaciones2.concesionaria;

SELECT * FROM jpa_relaciones2.auto;

-- relacion 
select *
from auto a
inner join concesionaria c on c.id_concesionaria = a.id_concesionaria;