package ar.edu.centro8.desarrollo.proyectojpa1an.controllers;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ar.edu.centro8.desarrollo.proyectojpa1an.models.Auto;
import ar.edu.centro8.desarrollo.proyectojpa1an.models.Concesionaria;
import ar.edu.centro8.desarrollo.proyectojpa1an.services.ConcesionariaService;


@RestController
@RequestMapping("/api/concesionarias")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class ConcesionariaController {

    @Autowired
    private  ConcesionariaService concesionariaService;

    @GetMapping
    public List<Concesionaria> getAllConcesionaria() {
        return concesionariaService.obtenerConcesionarias();
    }

    @GetMapping("/{id}")
    public Concesionaria getConcesionariaById(@PathVariable Long id) {
        return concesionariaService.traerConcesionaria(id);
    }

    @PostMapping
    public void createConcesionaria(@RequestBody Concesionaria concesionaria) {
        concesionariaService.guardarConcesionaria(concesionaria);
    }

    @PutMapping("/{id}")
    public void updateConcesionaria(@PathVariable Long id, @RequestBody Concesionaria concesionaria) {
         concesionariaService.editarConcesionaria(id,concesionaria.getId(),concesionaria.getNombre());
    }

    @DeleteMapping("/{id}")
    public void deleteConcesionaria(@PathVariable Long id) {
        concesionariaService.eliminarConcesionaria(id);
    }

    
    //AGREGADO
//     @PostMapping("/{id}/autos")
// public ResponseEntity<?> createAutoForConcesionaria(
//     @PathVariable Long id,
//     @RequestBody Auto auto
// ) {
//     Concesionaria concesionaria = concesionariaService.traerConcesionaria(id);
//     if (concesionaria == null) {
//         return ResponseEntity.notFound().build();
//     }
    
//     auto.setConcesionaria(concesionaria);
//     concesionariaService.guardarAuto(auto);
    
//     return ResponseEntity.ok("Auto creado exitosamente");
// }

@PostMapping("/autos")
public ResponseEntity<?> createAutoForConcesionaria(@RequestBody Auto auto) {
    if (auto.getConcesionaria() == null || auto.getConcesionaria().getId() == null) {
        return ResponseEntity.badRequest().body("El JSON debe incluir el ID de la concesionaria.");
    }

    Long concesionariaId = auto.getConcesionaria().getId();
    Concesionaria concesionaria = concesionariaService.traerConcesionaria(concesionariaId);
    if (concesionaria == null) {
        return ResponseEntity.notFound().build();
    }

    // Asignar la concesionaria al auto
    auto.setConcesionaria(concesionaria);

    // Agregar el auto a la lista de autos de la concesionaria
    concesionaria.agregarAuto(auto);

    // Guardar el auto en la base de datos
    concesionariaService.guardarConcesionaria(concesionaria);

    return ResponseEntity.ok("Auto creado exitosamente en la concesionaria con ID: " + concesionariaId);
}

    
}
