package ar.edu.centro8.desarrollo.proyectojpa1an.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import ar.edu.centro8.desarrollo.proyectojpa1an.models.Auto;

public interface AutoRepository extends JpaRepository<Auto, Long>{

}
