// CascadeType.ALL significa que todas las operaciones (crear, actualizar, eliminar) se propagarán a todos los elementos relacionados.

// orphanRemoval = true
// Esta opción activa la eliminación de huérfanos. Cuando una entidad padre (Concesionaria) es eliminada, sus hijos (Autos) serán automáticamente eliminados de la base de datos.

// @JsonManagedReference
// Evita bucles infinitos al serializar objetos relacionados.
// Permite una serialización más eficiente de relaciones complejas.

package ar.edu.centro8.desarrollo.proyectojpa1an.models;

import java.util.HashSet;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@NoArgsConstructor
@Getter @Setter
public class Concesionaria {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_concesionaria", nullable = false)
    private Long id;

    @Column(name = "nombre", nullable = false)
    private String nombre;

    @OneToMany(mappedBy = "concesionaria", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    // private HashSet<Auto> autos;
    private List<Auto> autos;

    // public Concesionaria(String nombre, HashSet<Auto> autos) {
        public Concesionaria(String nombre, List<Auto> autos) {
        this.nombre = nombre;
        this.autos = autos;
    }

    //AGREGADO
    public Auto agregarAuto(Auto auto) {
        this.autos.add(auto);
        return auto;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());
        result = prime * result + ((autos == null) ? 0 : autos.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Concesionaria other = (Concesionaria) obj;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        if (nombre == null) {
            if (other.nombre != null)
                return false;
        } else if (!nombre.equals(other.nombre))
            return false;
        if (autos == null) {
            if (other.autos != null)
                return false;
        } else if (!autos.equals(other.autos))
            return false;
        return true;
    }

    

}
