PROGRAMACIÓN SEGURA
TRABAJO PRÁCTICO 6
Encriptado de Contraseñas


-- Comprobaciones de Endpoints en Postman --


1 - Alta de Permisos

POST - localhost:8080/api/permissions
{
    "permissionsName":"READ"
}

POST - localhost:8080/api/permissions
{
    "permissionName":"CREATE"
}


2 - Alta de Roles

POST - localhost:8080/api/roles
{
  "role": "ADMIN",
  "permissionsList": [
    {
      "id": 1
    },
    {
      "id": 2
    }
  ]
}

POST - localhost:8080/api/roles
{
  "role": "USER",
  "permissionsList": [
    {
      "id": 1
    }
  ]
}


3 - Alta de Usuarios
POST - localhost:8080/api/users
{
  "username": "centro8",
  "password": "1234",
  "enabled": true,
  "accountNotExpired": true,
  "accountNotLocked": true,
  "credentialNotExpired": true,
  "rolesList": [
    {
      "id": 1
    }
  ]
}

POST - localhost:8080/api/users
{
  "username": "seguidor",
  "password": "1234",
  "enabled": true,
  "accountNotExpired": true,
  "accountNotLocked": true,
  "credentialNotExpired": true,
  "rolesList": [
    {
      "id": 2
    }
  ]
}


4 - Comprobación de Decodificación de Contraseñas
GET - localhost:8080/holaseg
Basic Auth - Username: centro8 - Password: 1234
Salida --> '¡Hola con Seguridad!'

GET - localhost:8080/holaseg
Basic Auth - Username: otroUsuario - Password: 1234
Salida --> 401 Unauthorized

GET - localhost:8080/holaseg
Basic Auth - Username: centro8 - Password: 12345
Salida --> 401 Unauthorized