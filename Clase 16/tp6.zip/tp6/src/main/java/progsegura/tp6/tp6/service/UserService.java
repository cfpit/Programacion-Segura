package progsegura.tp6.tp6.service;

import progsegura.tp6.tp6.model.UserSec;
import progsegura.tp6.tp6.repository.IUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

// Llamado a UserService para que la capa Service, se encargue de encriptar la contraseña
// que reciba el endpoint de forma plana.

@Service

public class UserService implements IUserService {
    @Autowired
    private IUserRepository userRepository;

    @Override
    public List<UserSec> findAll() {
        return userRepository.findAll();
    }

    @Override
    public Optional<UserSec> findById(Long id) {
        return userRepository.findById(id);
    }

/// Se modifica la implementación para encriptar la contraseña antes de guardar el usuario.
// Esto evita almacenar contraseñas en texto plano, mejorando la seguridad del sistema.
// Solo se aplica la encriptación si la contraseña no es nula ni vacía.
    @Override
public UserSec save(UserSec userSec) {
    if (userSec.getPassword() != null && !userSec.getPassword().isEmpty()) {
        userSec.setPassword(encriptPassword(userSec.getPassword()));
    }
    return userRepository.save(userSec);
}

    // @Override
    // public UserSec save(UserSec userSec) {
    //     return userRepository.save(userSec);
    // }

    @Override
    public void deleteById(Long id) {
        userRepository.deleteById(id);
    }

    @Override
    public void update(UserSec userSec) {
        save(userSec);
    }

    @Override
    public String encriptPassword(String password) {
        return new BCryptPasswordEncoder().encode(password);
    }
}