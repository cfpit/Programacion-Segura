package progsegura.tp6.tp6.service;

import progsegura.tp6.tp6.model.UserSec;
import progsegura.tp6.tp6.model.Role;
import progsegura.tp6.tp6.model.Permission;
import progsegura.tp6.tp6.repository.IUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserDetailsServiceImp implements UserDetailsService {

    @Autowired
    private IUserRepository userRepo;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        // Traer el Usuario, desde la Base de Datos
        UserSec userSec = userRepo.findUserEntityByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("El usuario " + username + " no fue encontrado"));

        // Lista de autoridades (Roles y Permisos)
        List<SimpleGrantedAuthority> authorityList = new ArrayList<>();

        // Agregado de los Roles como Autoridades (prefijados con "ROLE_")
        userSec.getRolesList().forEach(role ->
            authorityList.add(new SimpleGrantedAuthority("ROLE_" + role.getRole()))
        );

        // Agregado de los Permisos, para cada Role
        userSec.getRolesList().stream()
                .flatMap(role -> role.getPermissionsList().stream())
                .forEach(permission ->
                    authorityList.add(new SimpleGrantedAuthority(permission.getPermissionName()))
                );

        // Retorno del Uusario en formato Spring Security.
        return new User(
                userSec.getUsername(),
                userSec.getPassword(),
                userSec.isEnabled(),
                userSec.isAccountNotExpired(),
                userSec.isCredentialNotExpired(),
                userSec.isAccountNotLocked(),
                authorityList
        );
    }
}