package progsegura.tp6.tp6.service;

import progsegura.tp6.tp6.model.Role;
import java.util.List;
import java.util.Optional;

public interface IRoleService {
    List<Role> findAll();
    Optional<Role> findById(Long id);
    Role save(Role role);
    void deleteById(Long id);
    Role update(Role role);
}