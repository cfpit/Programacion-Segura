# TP6 - Programación Segura: Encriptado de Contraseñas con BCrypt

Proyecto de Spring Boot enfocado en la seguridad de autenticación mediante el **hasheo y salteo de contraseñas con BCrypt**, control de acceso basado en roles y permisos (RBAC) con **Spring Security**, persistencia con **Spring Data JPA** y base de datos relacional **MySQL**.

---

## 🚀 Novedades y Actualizaciones

- **Upgrade a Java (JDK) 21 LTS**: Actualización de la versión objetivo en el archivo `pom.xml` (`<java.version>21</java.version>`). Totalmente verificado y compilado bajo Java 21.
- **Colección de Pruebas en Bruno**: Se incorporó el directorio `/bruno` con una suite organizada y parametrizada con environment `Local` para probar todos los endpoints y verificar la encriptación BCrypt y los estados HTTP esperados.
- **Limpieza de dependencias obsoletas**: Eliminación de imports en desuso (`NoOpPasswordEncoder`) para cumplir con las mejores prácticas de Spring Security.

---

## 🛠️ Stack Tecnológico

- **Java**: 21 (LTS)
- **Framework**: Spring Boot 3.5.0
- **Seguridad**: Spring Security 6 (HTTP Basic, BCryptPasswordEncoder, Stateless)
- **ORM / Persistencia**: Spring Data JPA / Hibernate 6
- **Base de Datos**: MySQL 8.x / 8.4
- **Herramientas de Testing API**: Bruno API Client
- **Gestor de Construcción**: Apache Maven (con Maven Wrapper `mvnw`)

---

## 🔐 ¿Cómo Funciona la Encriptación con BCrypt en este TP?

### 1. El Algoritmo BCrypt y Salteo Automático
BCrypt es una función de derivación de claves basada en el cifrado Blowfish, diseñada específicamente para el almacenamiento seguro de contraseñas.
- **Salteo (Salt) criptográfico**: Genera un salt aleatorio de 128 bits para cada contraseña. Esto garantiza que dos usuarios con la misma contraseña en texto plano (ej: `"1234"`) tendrán hashes completamente diferentes en la base de datos, evitando ataques mediante tablas arcoíris (*Rainbow Tables*).
- **Factor de Trabajo (Work Factor / Cost)**: Utiliza un costo de procesamiento configurable (por defecto `10`, es decir $2^{10} = 1024$ rondas de hashing), lo que ralentiza intencionalmente los ataques de fuerza bruta por diccionario.
- **Estructura del Hash**:
  ```text
  $2a$10$661PFAapzDAjmzpwq34U6uoC25jGZRsV.jX/997dPVI9ggG1pxifu
  ├── ── ────────────────────── ──────────────────────────────
   │   │            │                          │
   │   │            │                          └─ Hash generado (184 bits / 31 chars)
   │   │            └─ Salt aleatorio (128 bits / 22 chars)
   │   └─ Factor de costo (10 rondas = 2^10)
   └─ Identificador del algoritmo BCrypt (versión 2a)
  ```

### 2. Capa de Servicio: Hasheo antes de la Persistencia
En `UserService.java`:
- Cuando el controlador recibe la petición `POST /api/users` con la contraseña en texto plano (`userSec.getPassword()`), la capa de servicio intercepta la entidad antes de llamar al repositorio:
```java
@Override
public UserSec save(UserSec userSec) {
    if (userSec.getPassword() != null && !userSec.getPassword().isEmpty()) {
        userSec.setPassword(encriptPassword(userSec.getPassword()));
    }
    return userRepository.save(userSec);
}

@Override
public String encriptPassword(String password) {
    return new BCryptPasswordEncoder().encode(password);
}
```
Esto asegura que **ninguna contraseña quede almacenada en texto claro** en la base de datos MySQL.

### 3. Capa de Autenticación: Verificación Segura
En `SecurityConfig.java` y `UserDetailsServiceImp.java`:
- `SecurityConfig` registra el bean `PasswordEncoder` como `new BCryptPasswordEncoder()`.
- En `UserDetailsServiceImp`, el método `loadUserByUsername(String username)` busca el usuario en la BD y construye el objeto `UserDetails` de Spring Security con las autoridades correspondientes (Roles y Permisos).
- Al autenticarse mediante **HTTP Basic Auth**, el `DaoAuthenticationProvider` toma la contraseña provista por el cliente y ejecuta:
  ```java
  passwordEncoder.matches(rawPassword, encodedPassword)
  ```
  Esto extrae el salt del hash almacenado, hashea la contraseña recibida con ese mismo salt y compara ambos hashes en tiempo constante para evitar ataques de temporización (*Timing Attacks*).

---

## 📂 Estructura del Proyecto

```text
tp6/
├── bruno/                             # Colección de pruebas para Bruno API Client
│   ├── bruno.json                     # Metadata de la colección Bruno
│   ├── collection.bru                 # Configuración raíz de la colección
│   ├── 01-Permisos/                   # CRUD y verificación de Permisos
│   │   ├── 01-Crear Permiso READ.bru
│   │   ├── 02-Crear Permiso CREATE.bru
│   │   ├── 03-Listar Permisos.bru
│   │   └── 04-Obtener Permiso por ID.bru
│   ├── 02-Roles/                      # Creación y vinculación de Roles con Permisos
│   │   ├── 01-Crear Rol ADMIN.bru
│   │   ├── 02-Crear Rol USER.bru
│   │   ├── 03-Listar Roles.bru
│   │   └── 04-Obtener Rol por ID.bru
│   ├── 03-Usuarios/                   # Alta y consulta de Usuarios (Verificación de Hash)
│   │   ├── 01-Crear Usuario ADMIN.bru
│   │   ├── 02-Crear Usuario USER.bru
│   │   ├── 03-Listar Usuarios.bru
│   │   └── 04-Obtener Usuario por ID.bru
│   └── 04-Pruebas de Seguridad/       # Endpoints públicos y protegidos
│       ├── 01-GET Hola Sin Seguridad.bru
│       ├── 02-GET Hola Con Seguridad - ADMIN centro8.bru
│       ├── 03-GET Hola Con Seguridad - USER seguidor.bru
│       ├── 04-GET Hola Con Seguridad - Password Incorrecta.bru
│       ├── 05-GET Hola Con Seguridad - Usuario Inexistente.bru
│       └── 06-GET Hola Con Seguridad - Sin Credenciales.bru
├── src/
│   ├── main/
│   │   ├── java/progsegura/tp6/tp6/
│   │   │   ├── controller/            # Controladores REST (Users, Roles, Permissions, Hello)
│   │   │   ├── model/                 # Entidades JPA (UserSec, Role, Permission)
│   │   │   ├── repository/            # Repositorios Spring Data JPA
│   │   │   ├── security/config/       # Configuración de Spring Security (SecurityConfig)
│   │   │   └── service/               # Servicios de negocio y UserDetailsServiceImp
│   │   └── resources/
│   │       └── application.properties # Parámetros de conexión a BD y configuración
│   └── test/                          # Pruebas automatizadas JUnit / Spring Boot Test
├── pom.xml                            # Configuración de Maven (Java 21, Spring Boot 3.5.0)
└── README.md                          # Documentación completa del proyecto
```

---

## ⚙️ Configuración y Requisitos Previos

### 1. Requisitos
- **JDK 21** o superior instalado y configurado en la variable de entorno `JAVA_HOME`.
- **MySQL Server 8.x** en ejecución en el puerto `3306`.
- **Bruno** (u otra herramienta como Postman o cURL).

### 2. Base de Datos
Asegurarse de que el servicio MySQL esté corriendo y que exista la base de datos `security`:
```sql
CREATE DATABASE IF NOT EXISTS security;
```

Las credenciales de acceso se definen en `src/main/resources/application.properties`:
```properties
spring.application.name=tp6
spring.jpa.hibernate.ddl-auto=update
spring.datasource.url=jdbc:mysql://localhost:3306/security?createDatabaseIfNotExists=true&useSSL=false&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=1234
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
```
*(Si su usuario o contraseña de MySQL difieren, ajústelos en este archivo)*.

---

## 🏃 Instrucciones de Ejecución

### Compilar el proyecto con Maven Wrapper:
```bash
./mvnw clean compile
```

### Ejecutar las pruebas unitarias:
```bash
./mvnw test
```

### Iniciar la aplicación Spring Boot:
```bash
./mvnw spring-boot:run
```
La aplicación iniciará en `http://localhost:8080`.

---

## 🧪 Pruebas con la Colección de Bruno

Para utilizar la colección en **Bruno**:
1. Abrir **Bruno**.
2. Seleccionar **Open Collection** y elegir la carpeta `bruno` situada en la raíz de este proyecto.
3. Todas las peticiones apuntan directamente a `http://localhost:8080`, listas para ejecutar sin requerir configuración adicional de entornos.
4. Ejecutar las peticiones en el orden descripto a continuación:

### Paso 1: Alta de Permisos (`01-Permisos`)
- **`01 - Crear Permiso READ`** (`POST /api/permissions`)
  ```json
  {
    "permissionName": "READ"
  }
  ```
  *Respuesta:* `200 OK` con ID `1`.
- **`02 - Crear Permiso CREATE`** (`POST /api/permissions`)
  ```json
  {
    "permissionName": "CREATE"
  }
  ```
  *Respuesta:* `200 OK` con ID `2`.
- **`03 - Listar Permisos`** (`GET /api/permissions`): Verifica que ambos permisos están registrados.

---

### Paso 2: Alta de Roles (`02-Roles`)
- **`01 - Crear Rol ADMIN`** (`POST /api/roles`)
  ```json
  {
    "role": "ADMIN",
    "permissionsList": [
      { "id": 1 },
      { "id": 2 }
    ]
  }
  ```
  *Respuesta:* `200 OK` con ID `1` y permisos `READ` y `CREATE`.
- **`02 - Crear Rol USER`** (`POST /api/roles`)
  ```json
  {
    "role": "USER",
    "permissionsList": [
      { "id": 1 }
    ]
  }
  ```
  *Respuesta:* `200 OK` con ID `2` y permiso `READ`.

---

### Paso 3: Alta de Usuarios y Verificación de BCrypt (`03-Usuarios`)
- **`01 - Crear Usuario ADMIN (centro8)`** (`POST /api/users`)
  ```json
  {
    "username": "centro8",
    "password": "1234",
    "enabled": true,
    "accountNotExpired": true,
    "accountNotLocked": true,
    "credentialNotExpired": true,
    "rolesList": [
      { "id": 1 }
    ]
  }
  ```
  *Respuesta Esperada:* `200 OK`. Observe que el campo `password` devuelto **ya no es `1234`**, sino un hash BCrypt de la forma:
  `$2a$10$661PFAapzDAjmzpwq34U6uoC25jGZRsV.jX/997dPVI9ggG1pxifu`

- **`02 - Crear Usuario USER (seguidor)`** (`POST /api/users`)
  ```json
  {
    "username": "seguidor",
    "password": "1234",
    "enabled": true,
    "accountNotExpired": true,
    "accountNotLocked": true,
    "credentialNotExpired": true,
    "rolesList": [
      { "id": 2 }
    ]
  }
  ```
  *Respuesta Esperada:* `200 OK`. Nótese que aunque la contraseña en texto claro enviada es la misma (`"1234"`), el hash BCrypt resultante es completamente diferente debido al salteo aleatorio individual.

- **`03 - Listar Usuarios (Verificar Hash BCrypt)`** (`GET /api/users`): Devuelve la lista de usuarios confirmando que las contraseñas persisten hasheadas.

---

### Paso 4: Pruebas de Seguridad y Autorización (`04-Pruebas de Seguridad`)
Este grupo comprueba el comportamiento del filtro de seguridad, la autenticación con contraseñas encriptadas y la autorización basada en Roles y Permisos con `@PreAuthorize`:

| Petición | Método y URL | Autenticación | Resultado Esperado | Justificación |
|---|---|---|---|---|
| `01 - GET Hola Sin Seguridad` | `GET /holanoseg` | Ninguna | `200 OK` (`¡Hola SIN Seguridad!`) | Definido como `permitAll()` en `SecurityConfig`. |
| `02 - GET Hola Con Seguridad (ADMIN)` | `GET /holaseg` | Basic Auth (`centro8` / `1234`) | `200 OK` (`¡Hola con Seguridad!`) | Usuario con rol `ADMIN` habilitado por `@PreAuthorize("hasRole('ADMIN')")`. |
| `03 - GET Hola Con Seguridad (USER)` | `GET /holaseg` | Basic Auth (`seguidor` / `1234`) | `403 Forbidden` | Denegado: el usuario tiene rol `USER` y el endpoint exige `ADMIN`. |
| `04 - Password Incorrecta` | `GET /holaseg` | Basic Auth (`centro8` / `wrongpassword123`) | `401 Unauthorized` | BCrypt detecta discordancia con el hash almacenado. |
| `05 - Usuario Inexistente` | `GET /holaseg` | Basic Auth (`noExisteUser` / `1234`) | `401 Unauthorized` | `UserDetailsServiceImp` lanza `UsernameNotFoundException`. |
| `06 - Sin Credenciales` | `GET /holaseg` | Ninguna | `401 Unauthorized` | El recurso requiere autenticación y no se suministraron credenciales. |
| `07 - PATCH Modificar Rol (USER)` | `PATCH /api/roles/1` | Basic Auth (`seguidor` / `1234`) | `403 Forbidden` | Solo usuarios con rol `ADMIN` pueden modificar permisos con PATCH. |
| `08 - POST Crear Permiso (USER)` | `POST /api/permissions` | Basic Auth (`seguidor` / `1234`) | `403 Forbidden` | El alta de registros exige rol `ADMIN` y permiso `CREATE`. |

---

## 🛡️ Conclusión de Seguridad
El proyecto demuestra fehacientemente cómo desacoplar la recepción de credenciales del almacenamiento y gestionar el control de acceso:
1. **Encriptación BCrypt**: Las contraseñas en tránsito recibidas por los controladores son inmediatamente procesadas en la capa de servicio con `BCryptPasswordEncoder`, asegurando que en MySQL solo se almacenen hashes con salt único por usuario.
2. **Control de Acceso Basado en Roles (RBAC) y Permisos**: Mediante `@PreAuthorize` se protege cada operación crítica:
   - Operaciones de lectura (`GET`): permitidas a usuarios con rol `ADMIN` o `USER`.
   - Modificación de roles (`PATCH`): restringida exclusivamente a usuarios con rol `ADMIN`.
   - Altas de nuevos registros (`POST`): reservadas únicamente a administradores que posean explícitamente el permiso `CREATE`.

---

## 📋 Resumen Final de Cumplimiento y Configuración del TP6

1. **Upgrade a JDK 21**: Realizado en `pom.xml`, compilado y probado con Maven Wrapper (`./mvnw clean test` $\rightarrow$ `BUILD SUCCESS`).
2. **Colección de Bruno**: Disponible en `bruno/` con sintaxis oficial y URLs directas a `http://localhost:8080` (sin errores de parseo).
3. **Ejecución desde VS Code**: Configuración corregida en `application.properties` y `.vscode/launch.json` para ejecutar directamente con botón derecho *"Run Java"* sobre `Tp6Application.java`.
4. **Seguridad y Encriptación BCrypt**: 
   - Hasheo en servicio con `BCryptPasswordEncoder`.
   - Control de acceso por roles y permisos con `@PreAuthorize` en todos los controladores.
   - Endpoint `PATCH /api/roles/{id}` implementado.
5. **Documentación Completa**: `README.md` detallando el funcionamiento de BCrypt, arquitectura de seguridad, endpoints y pasos de prueba.

---

## 🔧 Resolución de Problemas: Diagnóstico del Error 401 Unauthorized y Auto-Seeding

### ¿Por qué se producía un error 401 al crear permisos?
1. **Protección con `@PreAuthorize`**: El endpoint `POST /api/permissions` está protegido para requerir rol `ADMIN` y autoridad `CREATE` (`@PreAuthorize("hasRole('ADMIN') and hasAuthority('CREATE')")`).
2. **Base de Datos inicial sin registros**: Al enviar credenciales con Basic Auth (`centro8` / `1234`), Spring Security consulta a MySQL a través de `UserDetailsServiceImp`. Si la base de datos está vacía, no encuentra al usuario `centro8`, lanzando `UsernameNotFoundException`, lo que resulta en un código de respuesta HTTP `401 Unauthorized`.

### Solución Implementada:
1. **Auto-inicialización de datos (`CommandLineRunner`)**: Se agregó un bean en `Tp6Application.java` que detecta si la base de datos está vacía al iniciar la aplicación e inserta automáticamente:
   - **Permisos**: `READ` y `CREATE`.
   - **Roles**: `ADMIN` (con `READ` y `CREATE`) y `USER` (con `READ`).
   - **Usuarios**: `centro8` (contraseña `1234` hasheada con BCrypt, rol `ADMIN`) y `seguidor` (contraseña `1234` hasheada con BCrypt, rol `USER`).
2. **Peticiones en Bruno actualizadas**: Todas las requests que requieren autenticación en la carpeta `bruno/` incluyen la configuración `auth: basic` con usuario `centro8` y contraseña `1234`.


