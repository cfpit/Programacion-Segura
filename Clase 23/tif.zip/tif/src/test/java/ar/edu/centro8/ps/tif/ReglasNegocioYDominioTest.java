package ar.edu.centro8.ps.tif;

import ar.edu.centro8.ps.tif.dto.request.TurnoRequestDTO;
import ar.edu.centro8.ps.tif.dto.response.FichaMedicaResponseDTO;
import ar.edu.centro8.ps.tif.dto.response.PacienteResponseDTO;
import ar.edu.centro8.ps.tif.exception.BusinessException;
import ar.edu.centro8.ps.tif.exception.DomainException;
import ar.edu.centro8.ps.tif.model.FichaMedica;
import ar.edu.centro8.ps.tif.model.Medico;
import ar.edu.centro8.ps.tif.model.Paciente;
import ar.edu.centro8.ps.tif.model.Turno;
import ar.edu.centro8.ps.tif.model.enums.EstadoTurno;
import ar.edu.centro8.ps.tif.repository.MedicoRepository;
import ar.edu.centro8.ps.tif.repository.PacienteRepository;
import ar.edu.centro8.ps.tif.repository.TurnoRepository;
import ar.edu.centro8.ps.tif.service.impl.TurnoServiceImpl;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.TemporalAdjusters;
import java.time.DayOfWeek;
import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ReglasNegocioYDominioTest {

    private Validator validator;

    @Mock
    private TurnoRepository turnoRepository;

    @Mock
    private MedicoRepository medicoRepository;

    @Mock
    private PacienteRepository pacienteRepository;

    @InjectMocks
    private TurnoServiceImpl turnoService;

    @BeforeEach
    void setUp() {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
    }

    // =========================================================================
    // 1. TEST: REGLA DE NEGOCIO EN EL REQUEST DTO
    // =========================================================================
    @Test
    @DisplayName("1.1 RequestDTO: Permite turno en día de semana y horario laboral (08:00 a 20:00)")
    void testReglaNegocioRequestDTO_HorarioValido() {
        // Próximo miércoles a las 10:00 hs
        LocalDateTime proximoMiercoles = LocalDateTime.now()
                .with(TemporalAdjusters.next(DayOfWeek.WEDNESDAY))
                .withHour(10).withMinute(0).withSecond(0).withNano(0);

        TurnoRequestDTO dto = TurnoRequestDTO.builder()
                .pacienteId(1L)
                .medicoId(1L)
                .fechaHora(proximoMiercoles)
                .motivoConsulta("Chequeo general de rutina")
                .build();

        Set<ConstraintViolation<TurnoRequestDTO>> violations = validator.validate(dto);
        assertTrue(violations.isEmpty(), "No debería haber violaciones para un horario válido en día de semana");
    }

    @Test
    @DisplayName("1.2 RequestDTO: Rechaza turno solicitado en fin de semana (Sábado)")
    void testReglaNegocioRequestDTO_FinDeSemanaRechazado() {
        // Próximo sábado a las 11:00 hs
        LocalDateTime proximoSabado = LocalDateTime.now()
                .with(TemporalAdjusters.next(DayOfWeek.SATURDAY))
                .withHour(11).withMinute(0).withSecond(0).withNano(0);

        TurnoRequestDTO dto = TurnoRequestDTO.builder()
                .pacienteId(1L)
                .medicoId(1L)
                .fechaHora(proximoSabado)
                .motivoConsulta("Consulta de urgencia")
                .build();

        Set<ConstraintViolation<TurnoRequestDTO>> violations = validator.validate(dto);
        assertFalse(violations.isEmpty(), "Debe fallar la validación al solicitar turno en día sábado");
        assertTrue(violations.stream().anyMatch(v -> v.getMessage().contains("horario de atención del consultorio")));
    }

    @Test
    @DisplayName("1.3 RequestDTO: Rechaza turno fuera del horario de atención (22:00 hs)")
    void testReglaNegocioRequestDTO_FueraDeHorarioRechazado() {
        // Próximo martes a las 22:30 hs
        LocalDateTime proximoMartes = LocalDateTime.now()
                .with(TemporalAdjusters.next(DayOfWeek.TUESDAY))
                .withHour(22).withMinute(30).withSecond(0).withNano(0);

        TurnoRequestDTO dto = TurnoRequestDTO.builder()
                .pacienteId(1L)
                .medicoId(1L)
                .fechaHora(proximoMartes)
                .motivoConsulta("Control nocturno")
                .build();

        Set<ConstraintViolation<TurnoRequestDTO>> violations = validator.validate(dto);
        assertFalse(violations.isEmpty(), "Debe fallar la validación al solicitar turno fuera de las 20:00 hs");
        assertTrue(violations.stream().anyMatch(v -> v.getMessage().contains("horario de atención del consultorio")));
    }

    // =========================================================================
    // 2. TEST: REGLA DE NEGOCIO EN EL RESPONSE DTO
    // =========================================================================
    @Test
    @DisplayName("2.1 ResponseDTO: Calcula IMC, diagnóstico nutricional y alerta en FichaMedica")
    void testReglaNegocioResponseDTO_CalculoIMCYAlerta() {
        Paciente paciente = Paciente.builder()
                .id(1L)
                .nombre("Juan")
                .apellido("Pérez")
                .dni("30111222")
                .fechaNacimiento(LocalDate.of(1990, 5, 10))
                .build();

        // Caso: Peso 70 kg, Altura 1.75 m -> IMC = 70 / (1.75^2) = 22.86 (Peso normal)
        FichaMedica ficha = FichaMedica.builder()
                .id(1L)
                .paciente(paciente)
                .grupoSanguineo("O+")
                .alergias("Ninguna")
                .peso(70.0)
                .altura(1.75)
                .fechaCreacion(LocalDateTime.now())
                .build();

        FichaMedicaResponseDTO responseDTO = FichaMedicaResponseDTO.fromEntity(ficha);

        assertNotNull(responseDTO.getImc());
        assertEquals(22.86, responseDTO.getImc(), 0.01);
        assertEquals("Peso normal (Eutrófico)", responseDTO.getDiagnosticoNutricional());
        assertTrue(responseDTO.getAlertaClinica().contains("parámetros saludables"));
    }

    @Test
    @DisplayName("2.2 ResponseDTO: Diagnóstico de Obesidad y Alerta Crítica ante IMC >= 30")
    void testReglaNegocioResponseDTO_ObesidadConAlertaCritica() {
        Paciente paciente = Paciente.builder()
                .id(2L)
                .nombre("María")
                .apellido("Gómez")
                .dni("28999888")
                .build();

        // Caso: Peso 95 kg, Altura 1.60 m -> IMC = 95 / 2.56 = 37.11 (Obesidad)
        FichaMedica ficha = FichaMedica.builder()
                .id(2L)
                .paciente(paciente)
                .grupoSanguineo("A+")
                .alergias("Penicilina")
                .peso(95.0)
                .altura(1.60)
                .fechaCreacion(LocalDateTime.now())
                .build();

        FichaMedicaResponseDTO responseDTO = FichaMedicaResponseDTO.fromEntity(ficha);

        assertEquals(37.11, responseDTO.getImc(), 0.01);
        assertEquals("Obesidad", responseDTO.getDiagnosticoNutricional());
        assertTrue(responseDTO.getAlertaClinica().contains("Alerta Crítica"));
        assertTrue(responseDTO.getAlertaClinica().contains("Penicilina"));
    }

    @Test
    @DisplayName("2.3 ResponseDTO: Cálculo de edad y grupo etario en PacienteResponseDTO")
    void testReglaNegocioResponseDTO_PacienteEdadYCategoria() {
        Paciente paciente = Paciente.builder()
                .id(3L)
                .nombre("Mateo")
                .apellido("López")
                .dni("55123456")
                .fechaNacimiento(LocalDate.now().minusYears(8))
                .build();

        PacienteResponseDTO response = PacienteResponseDTO.fromEntity(paciente);
        assertEquals(8, response.getEdad());
        assertEquals("Pediátrico", response.getCategoriaEtaria());
    }

    // =========================================================================
    // 3. TEST: REGLA DE DOMINIO EN LA ENTIDAD DEL MODELO
    // =========================================================================
    @Test
    @DisplayName("3.1 Regla Dominio Modelo: Cancelación exitosa de un turno pendiente")
    void testReglaDominioModelo_CancelarTurnoExitoso() {
        Turno turno = Turno.builder()
                .id(1L)
                .estado(EstadoTurno.PENDIENTE)
                .build();

        turno.cancelar("Paciente con síntomas de gripe, se reprograma");

        assertEquals(EstadoTurno.CANCELADO, turno.getEstado());
        assertEquals("Paciente con síntomas de gripe, se reprograma", turno.getMotivoCancelacion());
    }

    @Test
    @DisplayName("3.2 Regla Dominio Modelo: Lanza DomainException al cancelar turno ya cancelado")
    void testReglaDominioModelo_CancelarTurnoYaCancelado() {
        Turno turno = Turno.builder()
                .id(1L)
                .estado(EstadoTurno.CANCELADO)
                .motivoCancelacion("Cancelado previamente")
                .build();

        DomainException ex = assertThrows(DomainException.class, () -> turno.cancelar("Otro motivo"));
        assertTrue(ex.getMessage().contains("El turno ya se encuentra en estado CANCELADO"));
    }

    @Test
    @DisplayName("3.3 Regla Dominio Modelo: Lanza DomainException al cancelar turno ya atendido")
    void testReglaDominioModelo_CancelarTurnoAtendido() {
        Turno turno = Turno.builder()
                .id(1L)
                .estado(EstadoTurno.ATENDIDO)
                .build();

        DomainException ex = assertThrows(DomainException.class, () -> turno.cancelar("Cancelación tardía"));
        assertTrue(ex.getMessage().contains("No es posible cancelar un turno que ya ha sido ATENDIDO"));
    }

    @Test
    @DisplayName("3.4 Regla Dominio Modelo: Lanza DomainException si el motivo está vacío")
    void testReglaDominioModelo_CancelarTurnoSinMotivo() {
        Turno turno = Turno.builder()
                .id(1L)
                .estado(EstadoTurno.PENDIENTE)
                .build();

        DomainException ex = assertThrows(DomainException.class, () -> turno.cancelar("   "));
        assertTrue(ex.getMessage().contains("Debe proporcionarse obligatoriamente un motivo"));
    }

    // =========================================================================
    // 4. TEST: ÚNICA REGLA DE NEGOCIO EN LA CAPA SERVICE
    // =========================================================================
    @Test
    @DisplayName("4.1 Regla Negocio Service: Rechaza creación de turno si el médico ya tiene turno en esa fecha y hora")
    void testReglaNegocioService_SolapamientoMedicoLanzaBusinessException() {
        Long medicoId = 1L;
        Long pacienteId = 2L;
        LocalDateTime fechaHora = LocalDateTime.now().with(TemporalAdjusters.next(DayOfWeek.MONDAY)).withHour(9).withMinute(0);

        Medico medico = Medico.builder().id(medicoId).nombre("Carlos").apellido("Ruiz").activo(true).build();
        Paciente paciente = Paciente.builder().id(pacienteId).nombre("Ana").apellido("Sosa").build();

        when(pacienteRepository.findById(pacienteId)).thenReturn(Optional.of(paciente));
        when(medicoRepository.findById(medicoId)).thenReturn(Optional.of(medico));
        // Simulamos que el médico ya tiene un turno activo en ese horario
        when(turnoRepository.existsByMedicoIdAndFechaHoraAndEstadoNot(eq(medicoId), eq(fechaHora), eq(EstadoTurno.CANCELADO)))
                .thenReturn(true);

        TurnoRequestDTO dto = TurnoRequestDTO.builder()
                .medicoId(medicoId)
                .pacienteId(pacienteId)
                .fechaHora(fechaHora)
                .motivoConsulta("Control oftalmológico")
                .build();

        BusinessException ex = assertThrows(BusinessException.class, () -> turnoService.crear(dto));
        assertTrue(ex.getMessage().contains("Regla de Negocio (Service): El profesional médico ya tiene un turno agendado"));
    }
}
