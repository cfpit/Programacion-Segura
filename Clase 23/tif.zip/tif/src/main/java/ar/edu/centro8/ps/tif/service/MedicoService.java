package ar.edu.centro8.ps.tif.service;

import ar.edu.centro8.ps.tif.dto.request.MedicoRequestDTO;
import ar.edu.centro8.ps.tif.dto.response.MedicoResponseDTO;

import java.util.List;

public interface MedicoService {
    MedicoResponseDTO crear(MedicoRequestDTO dto);
    List<MedicoResponseDTO> obtenerTodos();
    MedicoResponseDTO obtenerPorId(Long id);
    MedicoResponseDTO actualizar(Long id, MedicoRequestDTO dto);
    void eliminar(Long id);
}
