package ar.edu.centro8.ps.tif.repository;

import ar.edu.centro8.ps.tif.model.FichaMedica;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface FichaMedicaRepository extends JpaRepository<FichaMedica, Long> {

    Optional<FichaMedica> findByPacienteId(Long pacienteId);

    boolean existsByPacienteId(Long pacienteId);

    /*
     * ¿Existe otra ficha médica para este paciente que no sea esta misma
     * (excluyendo el id actual)?
     */
    boolean existsByPacienteIdAndIdNot(Long pacienteId, Long id);
}
