package ar.edu.centro8.ps.tif.repository;

import ar.edu.centro8.ps.tif.model.Paciente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PacienteRepository extends JpaRepository<Paciente, Long> {

    boolean existsByDni(String dni);

    boolean existsByDniAndIdNot(String dni, Long id);

    Optional<Paciente> findByDni(String dni);

    List<Paciente> findByApellidoContainingIgnoreCase(String apellido);
}
