package ar.edu.centro8.ps.tif.config;

import ar.edu.centro8.ps.tif.model.FichaMedica;
import ar.edu.centro8.ps.tif.model.Medico;
import ar.edu.centro8.ps.tif.model.Paciente;
import ar.edu.centro8.ps.tif.model.Turno;
import ar.edu.centro8.ps.tif.model.enums.EstadoTurno;
import ar.edu.centro8.ps.tif.repository.FichaMedicaRepository;
import ar.edu.centro8.ps.tif.repository.MedicoRepository;
import ar.edu.centro8.ps.tif.repository.PacienteRepository;
import ar.edu.centro8.ps.tif.repository.TurnoRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Componente de inicialización de datos (Data Loader / Seeder).
 * Implementa CommandLineRunner para ejecutarse automáticamente al arrancar
 * la aplicación Spring Boot.
 * Verifica si las tablas están vacías antes de insertar registros de prueba
 * para evitar duplicados en sucesivos reinicios.
 */
@Component
@RequiredArgsConstructor
public class DataLoader implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataLoader.class);

    private final MedicoRepository medicoRepository;
    private final PacienteRepository pacienteRepository;
    private final FichaMedicaRepository fichaMedicaRepository;
    private final TurnoRepository turnoRepository;

    @Override
    public void run(String... args) throws Exception {
        if (medicoRepository.count() > 0) {
            log.info("DataLoader: La base de datos ya contiene registros. Omitiendo precarga inicial.");
            return;
        }

        log.info("DataLoader: Base de datos vacía detectada. Iniciando precarga de datos de prueba...");

        // =====================================================================
        // 1. Precarga de Médicos
        // =====================================================================
        Medico m1 = Medico.builder()
                .nombre("Gonzalo")
                .apellido("Martínez")
                .dni("32145678")
                .matricula("MN-45920")
                .especialidad("Cardiología")
                .telefono("1155667788")
                .email("gonzalo.martinez@clinica.com")
                .activo(true)
                .build();

        Medico m2 = Medico.builder()
                .nombre("Valeria")
                .apellido("Rossi")
                .dni("29876543")
                .matricula("MN-52110")
                .especialidad("Pediatría")
                .telefono("1144332299")
                .email("valeria.rossi@clinica.com")
                .activo(true)
                .build();

        Medico m3 = Medico.builder()
                .nombre("Martín")
                .apellido("Benítez")
                .dni("34567890")
                .matricula("MN-38400")
                .especialidad("Traumatología")
                .telefono("1133221155")
                .email("martin.benitez@clinica.com")
                .activo(true)
                .build();

        medicoRepository.save(m1);
        medicoRepository.save(m2);
        medicoRepository.save(m3);
        log.info("DataLoader: 3 médicos guardados exitosamente.");

        // =====================================================================
        // 2. Precarga de Pacientes
        // =====================================================================
        Paciente p1 = Paciente.builder()
                .nombre("Florencia")
                .apellido("Alvarez")
                .dni("35890123")
                .fechaNacimiento(LocalDate.of(1992, 8, 15))
                .telefono("1144332211")
                .email("florencia.alvarez@gmail.com")
                .obraSocial("OSDE")
                .build();

        Paciente p2 = Paciente.builder()
                .nombre("Esteban")
                .apellido("Ríos")
                .dni("31999888")
                .fechaNacimiento(LocalDate.of(1988, 3, 20))
                .telefono("1199887766")
                .email("esteban.rios@gmail.com")
                .obraSocial("IOMA")
                .build();

        Paciente p3 = Paciente.builder()
                .nombre("Mateo")
                .apellido("López")
                .dni("55123456")
                .fechaNacimiento(LocalDate.of(2018, 11, 10))
                .telefono("1166778899")
                .email("padres.mateo@gmail.com")
                .obraSocial("Swiss Medical")
                .build();

        pacienteRepository.save(p1);
        pacienteRepository.save(p2);
        pacienteRepository.save(p3);
        log.info("DataLoader: 3 pacientes guardados exitosamente.");

        // =====================================================================
        // 3. Precarga de Fichas Médicas (con datos biométricos para regla ResponseDTO)
        // =====================================================================
        // Ficha 1: Peso normal (IMC ~ 23.95)
        FichaMedica f1 = FichaMedica.builder()
                .paciente(p1)
                .grupoSanguineo("A+")
                .alergias("Penicilina, Ibuprofeno")
                .antecedentes("Hipertensión arterial familiar")
                .peso(72.5)
                .altura(1.74)
                .observaciones("Paciente normopeso con factores de riesgo hereditarios.")
                .fechaCreacion(LocalDateTime.now())
                .build();

        // Ficha 2: Obesidad con Alerta Crítica (IMC ~ 36.33)
        FichaMedica f2 = FichaMedica.builder()
                .paciente(p2)
                .grupoSanguineo("O+")
                .alergias("Dipirona")
                .antecedentes("Diabetes Tipo II")
                .peso(105.0)
                .altura(1.70)
                .observaciones("Paciente con sobrepeso severo/obesidad, requiere monitoreo nutricional.")
                .fechaCreacion(LocalDateTime.now())
                .build();

        // Ficha 3: Paciente pediátrico (IMC ~ 16.57)
        FichaMedica f3 = FichaMedica.builder()
                .paciente(p3)
                .grupoSanguineo("B+")
                .alergias("Ninguna")
                .antecedentes("Sin antecedentes relevantes")
                .peso(28.0)
                .altura(1.30)
                .observaciones("Control pediátrico de desarrollo y crecimiento.")
                .fechaCreacion(LocalDateTime.now())
                .build();

        fichaMedicaRepository.save(f1);
        fichaMedicaRepository.save(f2);
        fichaMedicaRepository.save(f3);
        log.info("DataLoader: 3 fichas médicas guardadas exitosamente.");

        // =====================================================================
        // 4. Precarga de Turnos (en diferentes estados y fechas hábiles)
        // =====================================================================
        Turno t1 = Turno.builder()
                .paciente(p1)
                .medico(m1)
                .fechaHora(LocalDateTime.now().plusDays(5).withHour(10).withMinute(0).withSecond(0).withNano(0))
                .motivoConsulta("Control cardiológico semestral")
                .estado(EstadoTurno.CONFIRMADO)
                .fechaCreacion(LocalDateTime.now())
                .build();

        Turno t2 = Turno.builder()
                .paciente(p2)
                .medico(m3)
                .fechaHora(LocalDateTime.now().plusDays(6).withHour(15).withMinute(30).withSecond(0).withNano(0))
                .motivoConsulta("Dolor agudo en rodilla derecha tras actividad física")
                .estado(EstadoTurno.PENDIENTE)
                .fechaCreacion(LocalDateTime.now())
                .build();

        Turno t3 = Turno.builder()
                .paciente(p3)
                .medico(m2)
                .fechaHora(LocalDateTime.now().minusDays(2).withHour(11).withMinute(0).withSecond(0).withNano(0))
                .motivoConsulta("Control pediátrico anual de rutina")
                .estado(EstadoTurno.ATENDIDO)
                .fechaCreacion(LocalDateTime.now().minusDays(5))
                .build();

        Turno t4 = Turno.builder()
                .paciente(p1)
                .medico(m2)
                .fechaHora(LocalDateTime.now().minusDays(1).withHour(16).withMinute(0).withSecond(0).withNano(0))
                .motivoConsulta("Consulta preventiva")
                .estado(EstadoTurno.CANCELADO)
                .motivoCancelacion("Cancelado por el paciente por motivos laborales")
                .fechaCreacion(LocalDateTime.now().minusDays(3))
                .build();

        turnoRepository.save(t1);
        turnoRepository.save(t2);
        turnoRepository.save(t3);
        turnoRepository.save(t4);
        log.info("DataLoader: 4 turnos guardados exitosamente (CONFIRMADO, PENDIENTE, ATENDIDO, CANCELADO).");

        log.info("DataLoader: ¡Precarga inicial de datos completada con éxito!");
    }
}
