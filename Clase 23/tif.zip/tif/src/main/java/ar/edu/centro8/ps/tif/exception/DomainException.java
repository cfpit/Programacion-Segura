package ar.edu.centro8.ps.tif.exception;

public class DomainException extends RuntimeException {
    public DomainException(String message) {
        super(message);
    }
}
