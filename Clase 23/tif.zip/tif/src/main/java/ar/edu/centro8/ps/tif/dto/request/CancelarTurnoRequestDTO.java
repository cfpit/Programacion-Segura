package ar.edu.centro8.ps.tif.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CancelarTurnoRequestDTO {

    @NotBlank(message = "El motivo de cancelación es obligatorio")
    @Size(min = 5, max = 255, message = "El motivo de cancelación debe tener entre 5 y 255 caracteres")
    private String motivo;
}
