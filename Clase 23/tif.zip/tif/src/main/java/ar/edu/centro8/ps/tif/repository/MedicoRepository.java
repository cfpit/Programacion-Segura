package ar.edu.centro8.ps.tif.repository;

import ar.edu.centro8.ps.tif.model.Medico;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface MedicoRepository extends JpaRepository<Medico, Long> {

    boolean existsByDni(String dni);

    boolean existsByMatricula(String matricula);

    boolean existsByDniAndIdNot(String dni, Long id);

    boolean existsByMatriculaAndIdNot(String matricula, Long id);

    Optional<Medico> findByDni(String dni);

    Optional<Medico> findByMatricula(String matricula);

    List<Medico> findByActivoTrue();

    List<Medico> findByEspecialidadIgnoreCase(String especialidad);
}
