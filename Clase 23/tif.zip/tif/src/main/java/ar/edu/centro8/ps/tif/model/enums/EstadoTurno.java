package ar.edu.centro8.ps.tif.model.enums;

public enum EstadoTurno {
    PENDIENTE,
    CONFIRMADO,
    ATENDIDO,
    CANCELADO
}
