package ar.edu.centro8.ps.tif.controller;

import ar.edu.centro8.ps.tif.dto.request.CancelarTurnoRequestDTO;
import ar.edu.centro8.ps.tif.dto.request.TurnoRequestDTO;
import ar.edu.centro8.ps.tif.dto.response.TurnoResponseDTO;
import ar.edu.centro8.ps.tif.model.enums.EstadoTurno;
import ar.edu.centro8.ps.tif.service.TurnoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/turnos")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class TurnoController {

    private final TurnoService turnoService;

    @PostMapping
    public ResponseEntity<TurnoResponseDTO> crear(@Valid @RequestBody TurnoRequestDTO dto) {
        TurnoResponseDTO creado = turnoService.crear(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(creado);
    }

    @GetMapping
    public ResponseEntity<List<TurnoResponseDTO>> obtenerTodos() {
        return ResponseEntity.ok(turnoService.obtenerTodos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<TurnoResponseDTO> obtenerPorId(@PathVariable Long id) {
        return ResponseEntity.ok(turnoService.obtenerPorId(id));
    }

    @GetMapping("/paciente/{pacienteId}")
    public ResponseEntity<List<TurnoResponseDTO>> obtenerPorPaciente(@PathVariable Long pacienteId) {
        return ResponseEntity.ok(turnoService.obtenerPorPaciente(pacienteId));
    }

    @GetMapping("/medico/{medicoId}")
    public ResponseEntity<List<TurnoResponseDTO>> obtenerPorMedico(@PathVariable Long medicoId) {
        return ResponseEntity.ok(turnoService.obtenerPorMedico(medicoId));
    }

    @GetMapping("/estado/{estado}")
    public ResponseEntity<List<TurnoResponseDTO>> obtenerPorEstado(@PathVariable EstadoTurno estado) {
        return ResponseEntity.ok(turnoService.obtenerPorEstado(estado));
    }

    @PutMapping("/{id}")
    public ResponseEntity<TurnoResponseDTO> actualizar(
            @PathVariable Long id,
            @Valid @RequestBody TurnoRequestDTO dto) {
        return ResponseEntity.ok(turnoService.actualizar(id, dto));
    }

    @PutMapping("/{id}/cancelar")
    public ResponseEntity<TurnoResponseDTO> cancelar(
            @PathVariable Long id,
            @Valid @RequestBody CancelarTurnoRequestDTO dto) {
        return ResponseEntity.ok(turnoService.cancelar(id, dto));
    }

    @PutMapping("/{id}/atender")
    public ResponseEntity<TurnoResponseDTO> atender(@PathVariable Long id) {
        return ResponseEntity.ok(turnoService.atender(id));
    }

    @PutMapping("/{id}/confirmar")
    public ResponseEntity<TurnoResponseDTO> confirmar(@PathVariable Long id) {
        return ResponseEntity.ok(turnoService.confirmar(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        turnoService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
