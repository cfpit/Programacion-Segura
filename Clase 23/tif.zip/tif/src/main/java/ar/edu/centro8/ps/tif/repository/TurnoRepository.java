package ar.edu.centro8.ps.tif.repository;

import ar.edu.centro8.ps.tif.model.Turno;
import ar.edu.centro8.ps.tif.model.enums.EstadoTurno;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface TurnoRepository extends JpaRepository<Turno, Long> {

    List<Turno> findByPacienteId(Long pacienteId);

    List<Turno> findByMedicoId(Long medicoId);

    List<Turno> findByEstado(EstadoTurno estado);

    // =========================================================================
    // QUERY METHODS UTILIZADOS POR LA REGLA DE NEGOCIO EN SERVICE
    // =========================================================================
    boolean existsByMedicoIdAndFechaHoraAndEstadoNot(Long medicoId, LocalDateTime fechaHora, EstadoTurno estado);

    boolean existsByMedicoIdAndFechaHoraAndEstadoNotAndIdNot(Long medicoId, LocalDateTime fechaHora, EstadoTurno estado, Long id);

    boolean existsByPacienteIdAndFechaHoraAndEstadoNot(Long pacienteId, LocalDateTime fechaHora, EstadoTurno estado);

    boolean existsByPacienteIdAndFechaHoraAndEstadoNotAndIdNot(Long pacienteId, LocalDateTime fechaHora, EstadoTurno estado, Long id);
}
