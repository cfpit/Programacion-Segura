package ar.edu.centro8.ps.tif.service.impl;

import ar.edu.centro8.ps.tif.dto.request.MedicoRequestDTO;
import ar.edu.centro8.ps.tif.dto.response.MedicoResponseDTO;
import ar.edu.centro8.ps.tif.exception.ResourceNotFoundException;
import ar.edu.centro8.ps.tif.model.Medico;
import ar.edu.centro8.ps.tif.repository.MedicoRepository;
import ar.edu.centro8.ps.tif.service.MedicoService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class MedicoServiceImpl implements MedicoService {

    private final MedicoRepository medicoRepository;

    @Override
    @Transactional
    public MedicoResponseDTO crear(MedicoRequestDTO dto) {
        if (medicoRepository.existsByDni(dto.getDni())) {
            throw new IllegalArgumentException("Ya existe un médico registrado con el DNI: " + dto.getDni());
        }
        if (medicoRepository.existsByMatricula(dto.getMatricula())) {
            throw new IllegalArgumentException("Ya existe un médico registrado con la matrícula: " + dto.getMatricula());
        }

        Medico medico = Medico.builder()
                .nombre(dto.getNombre())
                .apellido(dto.getApellido())
                .dni(dto.getDni())
                .matricula(dto.getMatricula())
                .especialidad(dto.getEspecialidad())
                .telefono(dto.getTelefono())
                .email(dto.getEmail())
                .activo(dto.getActivo() != null ? dto.getActivo() : true)
                .build();

        Medico guardado = medicoRepository.save(medico);
        return MedicoResponseDTO.fromEntity(guardado);
    }

    @Override
    @Transactional(readOnly = true)
    public List<MedicoResponseDTO> obtenerTodos() {
        return medicoRepository.findAll().stream()
                .map(MedicoResponseDTO::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public MedicoResponseDTO obtenerPorId(Long id) {
        Medico medico = medicoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Médico no encontrado con ID: " + id));
        return MedicoResponseDTO.fromEntity(medico);
    }

    @Override
    @Transactional
    public MedicoResponseDTO actualizar(Long id, MedicoRequestDTO dto) {
        Medico medico = medicoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Médico no encontrado con ID: " + id));

        if (medicoRepository.existsByDniAndIdNot(dto.getDni(), id)) {
            throw new IllegalArgumentException("Ya existe otro médico registrado con el DNI: " + dto.getDni());
        }
        if (medicoRepository.existsByMatriculaAndIdNot(dto.getMatricula(), id)) {
            throw new IllegalArgumentException("Ya existe otro médico registrado con la matrícula: " + dto.getMatricula());
        }

        medico.setNombre(dto.getNombre());
        medico.setApellido(dto.getApellido());
        medico.setDni(dto.getDni());
        medico.setMatricula(dto.getMatricula());
        medico.setEspecialidad(dto.getEspecialidad());
        medico.setTelefono(dto.getTelefono());
        medico.setEmail(dto.getEmail());
        if (dto.getActivo() != null) {
            medico.setActivo(dto.getActivo());
        }

        Medico actualizado = medicoRepository.save(medico);
        return MedicoResponseDTO.fromEntity(actualizado);
    }

    @Override
    @Transactional
    public void eliminar(Long id) {
        Medico medico = medicoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Médico no encontrado con ID: " + id));
        medicoRepository.delete(medico);
    }
}
