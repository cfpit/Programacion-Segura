package ar.edu.centro8.ps.tif.dto.request;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FichaMedicaRequestDTO {

    @NotNull(message = "El ID del paciente es obligatorio")
    private Long pacienteId;

    @Size(max = 10, message = "El grupo sanguíneo no puede exceder los 10 caracteres")
    private String grupoSanguineo;

    @Size(max = 255, message = "Las alergias no pueden exceder los 255 caracteres")
    private String alergias;

    @Size(max = 500, message = "Los antecedentes no pueden exceder los 500 caracteres")
    private String antecedentes;

    @NotNull(message = "El peso es obligatorio")
    @Positive(message = "El peso debe ser mayor a 0")
    private Double peso; // en kg

    @NotNull(message = "La altura es obligatoria")
    @Positive(message = "La altura debe ser mayor a 0 (ej: 1.75)")
    private Double altura; // en metros

    private String observaciones;
}
