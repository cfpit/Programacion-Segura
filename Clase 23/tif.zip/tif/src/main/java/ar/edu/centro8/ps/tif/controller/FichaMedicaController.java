package ar.edu.centro8.ps.tif.controller;

import ar.edu.centro8.ps.tif.dto.request.FichaMedicaRequestDTO;
import ar.edu.centro8.ps.tif.dto.response.FichaMedicaResponseDTO;
import ar.edu.centro8.ps.tif.service.FichaMedicaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/fichas-medicas")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class FichaMedicaController {

    private final FichaMedicaService fichaMedicaService;

    @PostMapping
    public ResponseEntity<FichaMedicaResponseDTO> crear(@Valid @RequestBody FichaMedicaRequestDTO dto) {
        FichaMedicaResponseDTO creada = fichaMedicaService.crear(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(creada);
    }

    @GetMapping
    public ResponseEntity<List<FichaMedicaResponseDTO>> obtenerTodas() {
        return ResponseEntity.ok(fichaMedicaService.obtenerTodas());
    }

    @GetMapping("/{id}")
    public ResponseEntity<FichaMedicaResponseDTO> obtenerPorId(@PathVariable Long id) {
        return ResponseEntity.ok(fichaMedicaService.obtenerPorId(id));
    }

    @GetMapping("/paciente/{pacienteId}")
    public ResponseEntity<FichaMedicaResponseDTO> obtenerPorPacienteId(@PathVariable Long pacienteId) {
        return ResponseEntity.ok(fichaMedicaService.obtenerPorPacienteId(pacienteId));
    }

    @PutMapping("/{id}")
    public ResponseEntity<FichaMedicaResponseDTO> actualizar(
            @PathVariable Long id,
            @Valid @RequestBody FichaMedicaRequestDTO dto) {
        return ResponseEntity.ok(fichaMedicaService.actualizar(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        fichaMedicaService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
