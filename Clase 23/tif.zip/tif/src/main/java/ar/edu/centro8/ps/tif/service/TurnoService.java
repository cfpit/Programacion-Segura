package ar.edu.centro8.ps.tif.service;

import ar.edu.centro8.ps.tif.dto.request.CancelarTurnoRequestDTO;
import ar.edu.centro8.ps.tif.dto.request.TurnoRequestDTO;
import ar.edu.centro8.ps.tif.dto.response.TurnoResponseDTO;
import ar.edu.centro8.ps.tif.model.enums.EstadoTurno;

import java.util.List;

public interface TurnoService {
    TurnoResponseDTO crear(TurnoRequestDTO dto);
    List<TurnoResponseDTO> obtenerTodos();
    TurnoResponseDTO obtenerPorId(Long id);
    List<TurnoResponseDTO> obtenerPorPaciente(Long pacienteId);
    List<TurnoResponseDTO> obtenerPorMedico(Long medicoId);
    List<TurnoResponseDTO> obtenerPorEstado(EstadoTurno estado);
    TurnoResponseDTO actualizar(Long id, TurnoRequestDTO dto);
    TurnoResponseDTO cancelar(Long id, CancelarTurnoRequestDTO dto);
    TurnoResponseDTO atender(Long id);
    TurnoResponseDTO confirmar(Long id);
    void eliminar(Long id);
}
