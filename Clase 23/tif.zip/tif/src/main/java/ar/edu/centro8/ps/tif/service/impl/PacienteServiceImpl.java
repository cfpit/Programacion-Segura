package ar.edu.centro8.ps.tif.service.impl;

import ar.edu.centro8.ps.tif.dto.request.PacienteRequestDTO;
import ar.edu.centro8.ps.tif.dto.response.PacienteResponseDTO;
import ar.edu.centro8.ps.tif.exception.ResourceNotFoundException;
import ar.edu.centro8.ps.tif.model.Paciente;
import ar.edu.centro8.ps.tif.repository.PacienteRepository;
import ar.edu.centro8.ps.tif.service.PacienteService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PacienteServiceImpl implements PacienteService {

    private final PacienteRepository pacienteRepository;

    @Override
    @Transactional
    public PacienteResponseDTO crear(PacienteRequestDTO dto) {
        if (pacienteRepository.existsByDni(dto.getDni())) {
            throw new IllegalArgumentException("Ya existe un paciente registrado con el DNI: " + dto.getDni());
        }

        Paciente paciente = Paciente.builder()
                .nombre(dto.getNombre())
                .apellido(dto.getApellido())
                .dni(dto.getDni())
                .fechaNacimiento(dto.getFechaNacimiento())
                .telefono(dto.getTelefono())
                .email(dto.getEmail())
                .obraSocial(dto.getObraSocial())
                .build();

        Paciente guardado = pacienteRepository.save(paciente);
        return PacienteResponseDTO.fromEntity(guardado);
    }

    @Override
    @Transactional(readOnly = true)
    public List<PacienteResponseDTO> obtenerTodos() {
        return pacienteRepository.findAll().stream()
                .map(PacienteResponseDTO::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public PacienteResponseDTO obtenerPorId(Long id) {
        Paciente paciente = pacienteRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Paciente no encontrado con ID: " + id));
        return PacienteResponseDTO.fromEntity(paciente);
    }

    @Override
    @Transactional
    public PacienteResponseDTO actualizar(Long id, PacienteRequestDTO dto) {
        Paciente paciente = pacienteRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Paciente no encontrado con ID: " + id));

        if (pacienteRepository.existsByDniAndIdNot(dto.getDni(), id)) {
            throw new IllegalArgumentException("Ya existe otro paciente registrado con el DNI: " + dto.getDni());
        }

        paciente.setNombre(dto.getNombre());
        paciente.setApellido(dto.getApellido());
        paciente.setDni(dto.getDni());
        paciente.setFechaNacimiento(dto.getFechaNacimiento());
        paciente.setTelefono(dto.getTelefono());
        paciente.setEmail(dto.getEmail());
        paciente.setObraSocial(dto.getObraSocial());

        Paciente actualizado = pacienteRepository.save(paciente);
        return PacienteResponseDTO.fromEntity(actualizado);
    }

    @Override
    @Transactional
    public void eliminar(Long id) {
        Paciente paciente = pacienteRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Paciente no encontrado con ID: " + id));
        pacienteRepository.delete(paciente);
    }
}
