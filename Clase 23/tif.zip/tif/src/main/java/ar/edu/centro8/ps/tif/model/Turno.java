package ar.edu.centro8.ps.tif.model;

import ar.edu.centro8.ps.tif.exception.DomainException;
import ar.edu.centro8.ps.tif.model.enums.EstadoTurno;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "turnos")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Turno {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "paciente_id", nullable = false)
    private Paciente paciente;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "medico_id", nullable = false)
    private Medico medico;

    @Column(name = "fecha_hora", nullable = false)
    private LocalDateTime fechaHora;

    @Column(name = "motivo_consulta", nullable = false, length = 255)
    private String motivoConsulta;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    @Builder.Default
    private EstadoTurno estado = EstadoTurno.PENDIENTE;

    @Column(name = "motivo_cancelacion", length = 255)
    private String motivoCancelacion;

    @Column(name = "fecha_creacion", nullable = false)
    private LocalDateTime fechaCreacion;

    @PrePersist
    protected void onCreate() {
        if (this.estado == null) {
            this.estado = EstadoTurno.PENDIENTE;
        }
        if (this.fechaCreacion == null) {
            this.fechaCreacion = LocalDateTime.now();
        }
    }

    // =========================================================================
    // REGLA DE DOMINIO EN EL MODELO (ENTIDAD)
    // =========================================================================
    /**
     * Regla de dominio: Controla las transiciones válidas del ciclo de vida del turno.
     * Un turno solo puede cancelarse si está en estado PENDIENTE o CONFIRMADO.
     * Si ya fue ATENDIDO o previamente CANCELADO, la entidad rechaza la operación protegiendo
     * la consistencia e invariantes del modelo de dominio.
     */
    public void cancelar(String motivo) {
        if (this.estado == EstadoTurno.CANCELADO) {
            throw new DomainException("Regla de Dominio: El turno ya se encuentra en estado CANCELADO.");
        }
        if (this.estado == EstadoTurno.ATENDIDO) {
            throw new DomainException("Regla de Dominio: No es posible cancelar un turno que ya ha sido ATENDIDO.");
        }
        if (motivo == null || motivo.trim().isEmpty()) {
            throw new DomainException("Regla de Dominio: Debe proporcionarse obligatoriamente un motivo para cancelar el turno.");
        }
        this.estado = EstadoTurno.CANCELADO;
        this.motivoCancelacion = motivo.trim();
    }

    /**
     * Regla de dominio para registrar la atención del turno médico.
     */
    public void marcarAtendido() {
        if (this.estado == EstadoTurno.CANCELADO) {
            throw new DomainException("Regla de Dominio: No se puede atender un turno que está en estado CANCELADO.");
        }
        if (this.estado == EstadoTurno.ATENDIDO) {
            throw new DomainException("Regla de Dominio: El turno ya fue marcado como ATENDIDO con anterioridad.");
        }
        this.estado = EstadoTurno.ATENDIDO;
    }

    /**
     * Regla de dominio para confirmar un turno pendiente.
     */
    public void confirmar() {
        if (this.estado == EstadoTurno.CANCELADO) {
            throw new DomainException("Regla de Dominio: No se puede confirmar un turno CANCELADO.");
        }
        if (this.estado == EstadoTurno.ATENDIDO) {
            throw new DomainException("Regla de Dominio: El turno ya fue atendido, no puede cambiarse a CONFIRMADO.");
        }
        this.estado = EstadoTurno.CONFIRMADO;
    }
}
