package ar.edu.centro8.ps.tif.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "fichas_medicas")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FichaMedica {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "paciente_id", unique = true, nullable = false)
    private Paciente paciente;

    @Column(name = "grupo_sanguineo", length = 10)
    private String grupoSanguineo;

    @Column(length = 255)
    private String alergias;

    @Column(length = 500)
    private String antecedentes;

    @Column
    private Double peso; // en kilogramos (ej: 72.5)

    @Column
    private Double altura; // en metros (ej: 1.75)

    @Column(columnDefinition = "TEXT")
    private String observaciones;

    @Column(name = "fecha_creacion", nullable = false)
    private LocalDateTime fechaCreacion;

    @PrePersist
    protected void onCreate() {
        if (this.fechaCreacion == null) {
            this.fechaCreacion = LocalDateTime.now();
        }
    }
}
