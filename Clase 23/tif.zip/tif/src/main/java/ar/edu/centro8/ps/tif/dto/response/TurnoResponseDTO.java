package ar.edu.centro8.ps.tif.dto.response;

import ar.edu.centro8.ps.tif.model.Turno;
import ar.edu.centro8.ps.tif.model.enums.EstadoTurno;
import lombok.*;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TurnoResponseDTO {
    private Long id;
    private Long pacienteId;
    private String pacienteNombre;
    private String pacienteDni;
    private Long medicoId;
    private String medicoNombre;
    private String medicoEspecialidad;
    private LocalDateTime fechaHora;
    private String motivoConsulta;
    private EstadoTurno estado;
    private String motivoCancelacion;
    private LocalDateTime fechaCreacion;

    public static TurnoResponseDTO fromEntity(Turno turno) {
        if (turno == null) return null;
        return TurnoResponseDTO.builder()
                .id(turno.getId())
                .pacienteId(turno.getPaciente() != null ? turno.getPaciente().getId() : null)
                .pacienteNombre(turno.getPaciente() != null ? turno.getPaciente().getApellido() + ", " + turno.getPaciente().getNombre() : null)
                .pacienteDni(turno.getPaciente() != null ? turno.getPaciente().getDni() : null)
                .medicoId(turno.getMedico() != null ? turno.getMedico().getId() : null)
                .medicoNombre(turno.getMedico() != null ? "Dr(a). " + turno.getMedico().getApellido() + ", " + turno.getMedico().getNombre() : null)
                .medicoEspecialidad(turno.getMedico() != null ? turno.getMedico().getEspecialidad() : null)
                .fechaHora(turno.getFechaHora())
                .motivoConsulta(turno.getMotivoConsulta())
                .estado(turno.getEstado())
                .motivoCancelacion(turno.getMotivoCancelacion())
                .fechaCreacion(turno.getFechaCreacion())
                .build();
    }
}
