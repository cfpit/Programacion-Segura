package ar.edu.centro8.ps.tif.dto.response;

import ar.edu.centro8.ps.tif.model.Medico;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MedicoResponseDTO {
    private Long id;
    private String nombre;
    private String apellido;
    private String nombreCompleto;
    private String dni;
    private String matricula;
    private String especialidad;
    private String telefono;
    private String email;
    private Boolean activo;

    public static MedicoResponseDTO fromEntity(Medico medico) {
        if (medico == null) return null;
        return MedicoResponseDTO.builder()
                .id(medico.getId())
                .nombre(medico.getNombre())
                .apellido(medico.getApellido())
                .nombreCompleto("Dr(a). " + medico.getApellido() + ", " + medico.getNombre())
                .dni(medico.getDni())
                .matricula(medico.getMatricula())
                .especialidad(medico.getEspecialidad())
                .telefono(medico.getTelefono())
                .email(medico.getEmail())
                .activo(medico.getActivo())
                .build();
    }
}
