package ar.edu.centro8.ps.tif.service;

import ar.edu.centro8.ps.tif.dto.request.FichaMedicaRequestDTO;
import ar.edu.centro8.ps.tif.dto.response.FichaMedicaResponseDTO;

import java.util.List;

public interface FichaMedicaService {
    FichaMedicaResponseDTO crear(FichaMedicaRequestDTO dto);
    List<FichaMedicaResponseDTO> obtenerTodas();
    FichaMedicaResponseDTO obtenerPorId(Long id);
    FichaMedicaResponseDTO obtenerPorPacienteId(Long pacienteId);
    FichaMedicaResponseDTO actualizar(Long id, FichaMedicaRequestDTO dto);
    void eliminar(Long id);
}
