package ar.edu.centro8.ps.tif.service.impl;

import ar.edu.centro8.ps.tif.dto.request.FichaMedicaRequestDTO;
import ar.edu.centro8.ps.tif.dto.response.FichaMedicaResponseDTO;
import ar.edu.centro8.ps.tif.exception.ResourceNotFoundException;
import ar.edu.centro8.ps.tif.model.FichaMedica;
import ar.edu.centro8.ps.tif.model.Paciente;
import ar.edu.centro8.ps.tif.repository.FichaMedicaRepository;
import ar.edu.centro8.ps.tif.repository.PacienteRepository;
import ar.edu.centro8.ps.tif.service.FichaMedicaService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class FichaMedicaServiceImpl implements FichaMedicaService {

    private final FichaMedicaRepository fichaMedicaRepository;
    private final PacienteRepository pacienteRepository;

    @Override
    @Transactional
    public FichaMedicaResponseDTO crear(FichaMedicaRequestDTO dto) {
        Paciente paciente = pacienteRepository.findById(dto.getPacienteId())
                .orElseThrow(() -> new ResourceNotFoundException("Paciente no encontrado con ID: " + dto.getPacienteId()));

        if (fichaMedicaRepository.existsByPacienteId(dto.getPacienteId())) {
            throw new IllegalArgumentException("El paciente con ID " + dto.getPacienteId() + " ya posee una ficha médica registrada.");
        }

        FichaMedica ficha = FichaMedica.builder()
                .paciente(paciente)
                .grupoSanguineo(dto.getGrupoSanguineo())
                .alergias(dto.getAlergias())
                .antecedentes(dto.getAntecedentes())
                .peso(dto.getPeso())
                .altura(dto.getAltura())
                .observaciones(dto.getObservaciones())
                .fechaCreacion(LocalDateTime.now())
                .build();

        FichaMedica guardada = fichaMedicaRepository.save(ficha);
        return FichaMedicaResponseDTO.fromEntity(guardada);
    }

    @Override
    @Transactional(readOnly = true)
    public List<FichaMedicaResponseDTO> obtenerTodas() {
        return fichaMedicaRepository.findAll().stream()
                .map(FichaMedicaResponseDTO::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public FichaMedicaResponseDTO obtenerPorId(Long id) {
        FichaMedica ficha = fichaMedicaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Ficha médica no encontrada con ID: " + id));
        return FichaMedicaResponseDTO.fromEntity(ficha);
    }

    @Override
    @Transactional(readOnly = true)
    public FichaMedicaResponseDTO obtenerPorPacienteId(Long pacienteId) {
        FichaMedica ficha = fichaMedicaRepository.findByPacienteId(pacienteId)
                .orElseThrow(() -> new ResourceNotFoundException("No se encontró ficha médica para el paciente con ID: " + pacienteId));
        return FichaMedicaResponseDTO.fromEntity(ficha);
    }

    @Override
    @Transactional
    public FichaMedicaResponseDTO actualizar(Long id, FichaMedicaRequestDTO dto) {
        FichaMedica ficha = fichaMedicaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Ficha médica no encontrada con ID: " + id));

        if (dto.getPacienteId() != null && !dto.getPacienteId().equals(ficha.getPaciente().getId())) {
            Paciente nuevoPaciente = pacienteRepository.findById(dto.getPacienteId())
                    .orElseThrow(() -> new ResourceNotFoundException("Paciente no encontrado con ID: " + dto.getPacienteId()));
            if (fichaMedicaRepository.existsByPacienteIdAndIdNot(dto.getPacienteId(), id)) {
                throw new IllegalArgumentException("Ya existe una ficha médica registrada para el paciente ID: " + dto.getPacienteId());
            }
            ficha.setPaciente(nuevoPaciente);
        }

        ficha.setGrupoSanguineo(dto.getGrupoSanguineo());
        ficha.setAlergias(dto.getAlergias());
        ficha.setAntecedentes(dto.getAntecedentes());
        ficha.setPeso(dto.getPeso());
        ficha.setAltura(dto.getAltura());
        ficha.setObservaciones(dto.getObservaciones());

        FichaMedica actualizada = fichaMedicaRepository.save(ficha);
        return FichaMedicaResponseDTO.fromEntity(actualizada);
    }

    @Override
    @Transactional
    public void eliminar(Long id) {
        FichaMedica ficha = fichaMedicaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Ficha médica no encontrada con ID: " + id));
        fichaMedicaRepository.delete(ficha);
    }
}
