package ar.edu.centro8.ps.tif.dto.request;

import jakarta.validation.constraints.*;
import lombok.*;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TurnoRequestDTO {

    @NotNull(message = "El ID del paciente es obligatorio")
    private Long pacienteId;

    @NotNull(message = "El ID del médico es obligatorio")
    private Long medicoId;

    @NotNull(message = "La fecha y hora del turno es obligatoria")
    @Future(message = "La fecha y hora del turno debe ser posterior a la fecha y hora actual")
    private LocalDateTime fechaHora;

    @NotBlank(message = "El motivo de la consulta es obligatorio")
    @Size(min = 3, max = 255, message = "El motivo de la consulta debe tener entre 3 y 255 caracteres")
    private String motivoConsulta;

    // =========================================================================
    // REGLA DE NEGOCIO EN EL REQUEST DTO
    // =========================================================================
    /**
     * Regla de Negocio en RequestDTO:
     * Valida que todo turno solicitado se encuentre estrictamente dentro de la franja
     * de atención habilitada por la clínica: días hábiles (lunes a viernes) entre
     * las 08:00 y las 20:00 hs.
     * Esta regla de negocio se ejecuta en la capa de entrada antes de alcanzar los servicios.
     */
    @AssertTrue(message = "Regla de Negocio en RequestDTO: Los turnos únicamente pueden solicitarse de lunes a viernes dentro del horario de atención del consultorio (de 08:00 a 20:00 hs).")
    public boolean isHorarioAtencionValido() {
        if (fechaHora == null) {
            return true; // La obligatoriedad del campo la valida @NotNull
        }
        DayOfWeek dia = fechaHora.getDayOfWeek();
        if (dia == DayOfWeek.SATURDAY || dia == DayOfWeek.SUNDAY) {
            return false;
        }
        LocalTime hora = fechaHora.toLocalTime();
        LocalTime apertura = LocalTime.of(8, 0);
        LocalTime cierre = LocalTime.of(20, 0);
        return !hora.isBefore(apertura) && !hora.isAfter(cierre);
    }
}
