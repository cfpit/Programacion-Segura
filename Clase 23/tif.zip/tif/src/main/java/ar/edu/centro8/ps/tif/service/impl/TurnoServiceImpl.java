package ar.edu.centro8.ps.tif.service.impl;

import ar.edu.centro8.ps.tif.dto.request.CancelarTurnoRequestDTO;
import ar.edu.centro8.ps.tif.dto.request.TurnoRequestDTO;
import ar.edu.centro8.ps.tif.dto.response.TurnoResponseDTO;
import ar.edu.centro8.ps.tif.exception.BusinessException;
import ar.edu.centro8.ps.tif.exception.ResourceNotFoundException;
import ar.edu.centro8.ps.tif.model.Medico;
import ar.edu.centro8.ps.tif.model.Paciente;
import ar.edu.centro8.ps.tif.model.Turno;
import ar.edu.centro8.ps.tif.model.enums.EstadoTurno;
import ar.edu.centro8.ps.tif.repository.MedicoRepository;
import ar.edu.centro8.ps.tif.repository.PacienteRepository;
import ar.edu.centro8.ps.tif.repository.TurnoRepository;
import ar.edu.centro8.ps.tif.service.TurnoService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TurnoServiceImpl implements TurnoService {

    private final TurnoRepository turnoRepository;
    private final MedicoRepository medicoRepository;
    private final PacienteRepository pacienteRepository;

    // =========================================================================
    // ÚNICA REGLA DE NEGOCIO EN LA CAPA SERVICE
    // =========================================================================
    /**
     * REGLA DE NEGOCIO EN SERVICE:
     * Control de disponibilidad y solapamiento de agenda.
     * Garantiza que ningún profesional médico tenga más de un turno activo asignado
     * para el mismo día y hora exacta (se excluyen turnos cancelados).
     * Asimismo, verifica que el paciente no tenga otro turno en simultáneo.
     */
    private void validarDisponibilidadHoraria(Long medicoId, Long pacienteId, LocalDateTime fechaHora, Long turnoIdExcluir) {
        boolean medicoOcupado;
        if (turnoIdExcluir == null) {
            medicoOcupado = turnoRepository.existsByMedicoIdAndFechaHoraAndEstadoNot(medicoId, fechaHora, EstadoTurno.CANCELADO);
        } else {
            medicoOcupado = turnoRepository.existsByMedicoIdAndFechaHoraAndEstadoNotAndIdNot(medicoId, fechaHora, EstadoTurno.CANCELADO, turnoIdExcluir);
        }

        if (medicoOcupado) {
            throw new BusinessException("Regla de Negocio (Service): El profesional médico ya tiene un turno agendado para la fecha y hora: " + fechaHora + ".");
        }

        boolean pacienteOcupado;
        if (turnoIdExcluir == null) {
            pacienteOcupado = turnoRepository.existsByPacienteIdAndFechaHoraAndEstadoNot(pacienteId, fechaHora, EstadoTurno.CANCELADO);
        } else {
            pacienteOcupado = turnoRepository.existsByPacienteIdAndFechaHoraAndEstadoNotAndIdNot(pacienteId, fechaHora, EstadoTurno.CANCELADO, turnoIdExcluir);
        }

        if (pacienteOcupado) {
            throw new BusinessException("Regla de Negocio (Service): El paciente ya posee otro turno médico agendado en la misma fecha y hora: " + fechaHora + ".");
        }
    }

    @Override
    @Transactional
    public TurnoResponseDTO crear(TurnoRequestDTO dto) {
        Paciente paciente = pacienteRepository.findById(dto.getPacienteId())
                .orElseThrow(() -> new ResourceNotFoundException("Paciente no encontrado con ID: " + dto.getPacienteId()));

        Medico medico = medicoRepository.findById(dto.getMedicoId())
                .orElseThrow(() -> new ResourceNotFoundException("Médico no encontrado con ID: " + dto.getMedicoId()));

        if (Boolean.FALSE.equals(medico.getActivo())) {
            throw new BusinessException("No es posible asignar turnos a un profesional que se encuentra inactivo.");
        }

        // Ejecución de la ÚNICA regla de negocio en Service
        validarDisponibilidadHoraria(dto.getMedicoId(), dto.getPacienteId(), dto.getFechaHora(), null);

        Turno turno = Turno.builder()
                .paciente(paciente)
                .medico(medico)
                .fechaHora(dto.getFechaHora())
                .motivoConsulta(dto.getMotivoConsulta())
                .estado(EstadoTurno.PENDIENTE)
                .fechaCreacion(LocalDateTime.now())
                .build();

        Turno guardado = turnoRepository.save(turno);
        return TurnoResponseDTO.fromEntity(guardado);
    }

    @Override
    @Transactional(readOnly = true)
    public List<TurnoResponseDTO> obtenerTodos() {
        return turnoRepository.findAll().stream()
                .map(TurnoResponseDTO::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public TurnoResponseDTO obtenerPorId(Long id) {
        Turno turno = turnoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Turno no encontrado con ID: " + id));
        return TurnoResponseDTO.fromEntity(turno);
    }

    @Override
    @Transactional(readOnly = true)
    public List<TurnoResponseDTO> obtenerPorPaciente(Long pacienteId) {
        if (!pacienteRepository.existsById(pacienteId)) {
            throw new ResourceNotFoundException("Paciente no encontrado con ID: " + pacienteId);
        }
        return turnoRepository.findByPacienteId(pacienteId).stream()
                .map(TurnoResponseDTO::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<TurnoResponseDTO> obtenerPorMedico(Long medicoId) {
        if (!medicoRepository.existsById(medicoId)) {
            throw new ResourceNotFoundException("Médico no encontrado con ID: " + medicoId);
        }
        return turnoRepository.findByMedicoId(medicoId).stream()
                .map(TurnoResponseDTO::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<TurnoResponseDTO> obtenerPorEstado(EstadoTurno estado) {
        return turnoRepository.findByEstado(estado).stream()
                .map(TurnoResponseDTO::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public TurnoResponseDTO actualizar(Long id, TurnoRequestDTO dto) {
        Turno turno = turnoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Turno no encontrado con ID: " + id));

        Paciente paciente = pacienteRepository.findById(dto.getPacienteId())
                .orElseThrow(() -> new ResourceNotFoundException("Paciente no encontrado con ID: " + dto.getPacienteId()));

        Medico medico = medicoRepository.findById(dto.getMedicoId())
                .orElseThrow(() -> new ResourceNotFoundException("Médico no encontrado con ID: " + dto.getMedicoId()));

        if (Boolean.FALSE.equals(medico.getActivo())) {
            throw new BusinessException("No es posible asignar turnos a un profesional que se encuentra inactivo.");
        }

        // Ejecución de la regla de negocio de Service en reprogramación
        validarDisponibilidadHoraria(dto.getMedicoId(), dto.getPacienteId(), dto.getFechaHora(), id);

        turno.setPaciente(paciente);
        turno.setMedico(medico);
        turno.setFechaHora(dto.getFechaHora());
        turno.setMotivoConsulta(dto.getMotivoConsulta());

        Turno actualizado = turnoRepository.save(turno);
        return TurnoResponseDTO.fromEntity(actualizado);
    }

    @Override
    @Transactional
    public TurnoResponseDTO cancelar(Long id, CancelarTurnoRequestDTO dto) {
        Turno turno = turnoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Turno no encontrado con ID: " + id));

        // Dispara la regla de dominio encapsulada en la entidad Turno
        turno.cancelar(dto.getMotivo());

        Turno actualizado = turnoRepository.save(turno);
        return TurnoResponseDTO.fromEntity(actualizado);
    }

    @Override
    @Transactional
    public TurnoResponseDTO atender(Long id) {
        Turno turno = turnoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Turno no encontrado con ID: " + id));

        // Dispara la regla de dominio en la entidad Turno
        turno.marcarAtendido();

        Turno actualizado = turnoRepository.save(turno);
        return TurnoResponseDTO.fromEntity(actualizado);
    }

    @Override
    @Transactional
    public TurnoResponseDTO confirmar(Long id) {
        Turno turno = turnoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Turno no encontrado con ID: " + id));

        // Dispara la regla de dominio en la entidad Turno
        turno.confirmar();

        Turno actualizado = turnoRepository.save(turno);
        return TurnoResponseDTO.fromEntity(actualizado);
    }

    @Override
    @Transactional
    public void eliminar(Long id) {
        Turno turno = turnoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Turno no encontrado con ID: " + id));
        turnoRepository.delete(turno);
    }
}
