package ar.edu.centro8.ps.tif.service;

import ar.edu.centro8.ps.tif.dto.request.PacienteRequestDTO;
import ar.edu.centro8.ps.tif.dto.response.PacienteResponseDTO;

import java.util.List;

public interface PacienteService {
    PacienteResponseDTO crear(PacienteRequestDTO dto);
    List<PacienteResponseDTO> obtenerTodos();
    PacienteResponseDTO obtenerPorId(Long id);
    PacienteResponseDTO actualizar(Long id, PacienteRequestDTO dto);
    void eliminar(Long id);
}
