package ar.edu.centro8.ps.tif.dto.response;

import ar.edu.centro8.ps.tif.model.FichaMedica;
import lombok.*;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FichaMedicaResponseDTO {
    private Long id;
    private Long pacienteId;
    private String pacienteNombreCompleto;
    private String pacienteDni;
    private String grupoSanguineo;
    private String alergias;
    private String antecedentes;
    private Double peso;
    private Double altura;
    private String observaciones;
    private LocalDateTime fechaCreacion;

    // =========================================================================
    // REGLA DE NEGOCIO EN EL RESPONSE DTO
    // =========================================================================
    private Double imc;
    private String diagnosticoNutricional;
    private String alertaClinica;

    /**
     * Regla de Negocio en ResponseDTO:
     * A partir de los datos persistidos de peso y altura de la ficha médica, calcula
     * dinámicamente el Índice de Masa Corporal (IMC), clasifica el diagnóstico nutricional
     * según los rangos clínicos de la OMS y genera una alerta médica preventiva junto con
     * la verificación de antecedentes y alergias del paciente.
     */
    public static FichaMedicaResponseDTO fromEntity(FichaMedica ficha) {
        if (ficha == null) return null;

        Double imcCalculado = null;
        String diagnostico = "Datos biométricos incompletos";
        String alerta = "Sin alertas registradas";

        if (ficha.getPeso() != null && ficha.getAltura() != null && ficha.getAltura() > 0) {
            double imcRaw = ficha.getPeso() / (ficha.getAltura() * ficha.getAltura());
            imcCalculado = Math.round(imcRaw * 100.0) / 100.0;

            if (imcCalculado < 18.5) {
                diagnostico = "Bajo peso";
                alerta = "Alerta: Paciente por debajo del peso saludable. Evaluar soporte nutricional y laboratorio.";
            } else if (imcCalculado < 25.0) {
                diagnostico = "Peso normal (Eutrófico)";
                alerta = "Estado nutricional dentro de parámetros saludables.";
            } else if (imcCalculado < 30.0) {
                diagnostico = "Sobrepeso (Pre-obesidad)";
                alerta = "Atención: Paciente con sobrepeso. Se sugiere pauta dietética y control cardiovascular.";
            } else {
                diagnostico = "Obesidad";
                alerta = "Alerta Crítica: Paciente con diagnóstico de obesidad. Requiere seguimiento médico prioritario.";
            }
        }

        if (ficha.getAlergias() != null && !ficha.getAlergias().trim().isEmpty() && !ficha.getAlergias().equalsIgnoreCase("ninguna")) {
            alerta += " [ATENCIÓN MÉDICA: Alergias reportadas: " + ficha.getAlergias().trim() + "]";
        }

        return FichaMedicaResponseDTO.builder()
                .id(ficha.getId())
                .pacienteId(ficha.getPaciente() != null ? ficha.getPaciente().getId() : null)
                .pacienteNombreCompleto(ficha.getPaciente() != null ? ficha.getPaciente().getApellido() + ", " + ficha.getPaciente().getNombre() : null)
                .pacienteDni(ficha.getPaciente() != null ? ficha.getPaciente().getDni() : null)
                .grupoSanguineo(ficha.getGrupoSanguineo())
                .alergias(ficha.getAlergias())
                .antecedentes(ficha.getAntecedentes())
                .peso(ficha.getPeso())
                .altura(ficha.getAltura())
                .observaciones(ficha.getObservaciones())
                .fechaCreacion(ficha.getFechaCreacion())
                .imc(imcCalculado)
                .diagnosticoNutricional(diagnostico)
                .alertaClinica(alerta)
                .build();
    }
}
