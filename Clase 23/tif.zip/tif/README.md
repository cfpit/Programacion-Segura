# Sistema de Gestión de Consultorio Médico - API RESTful Spring Boot

Aplicación web backend construida con **Spring Boot**, **Spring Data JPA**, **Hibernate** y **MySQL**, organizada en una arquitectura estricta por capas (**Controller**, **Repository**, **Model**, **Service** y **DTO**). Expone una API JSON completa con operaciones CRUD para todas sus entidades y da cumplimiento explícito a las reglas de negocio y de dominio solicitadas.

---

## 📋 Tabla de Contenidos
1. [Descripción General](#-descripción-general)
2. [Tecnologías Utilizadas](#-tecnologías-utilizadas)
3. [Estructura del Proyecto y Arquitectura en Capas](#-estructura-del-proyecto-y-arquitectura-en-capas)
4. [Las 4 Reglas Implementadas (Dominio y Negocio)](#-las-4-reglas-implementadas-dominio-y-negocio)
   - [1. Regla de Negocio en RequestDTO](#1-regla-de-negocio-en-requestdto)
   - [2. Regla de Negocio en ResponseDTO](#2-regla-de-negocio-en-responsedto)
   - [3. Regla de Dominio en el Modelo (Entidad)](#3-regla-de-dominio-en-el-modelo-entidad)
   - [4. La Única Regla de Negocio en la Capa Service](#4-la-única-regla-de-negocio-en-la-capa-service)
5. [Modelo de Datos y Entidades](#-modelo-de-datos-y-entidades)
6. [Paso a Paso de Construcción del Proyecto](#-paso-a-paso-de-construcción-del-proyecto)
7. [Configuración de Base de Datos y Entorno](#-configuración-de-base-de-datos-y-entorno)
8. [Guía de Pruebas](#-guía-de-pruebas)
   - [Colección Bruno (http://localhost:8080)](#colección-bruno)
   - [Pruebas Automatizadas con Maven](#pruebas-automatizadas-con-maven)
   - [Listado de Endpoints y Ejemplos cURL](#listado-de-endpoints-y-ejemplos-curl)

---

## 🏥 Descripción General

El sistema gestiona de forma integral las operaciones de un consultorio médico o clínica ambulatoria:
- **Médicos**: Registro de profesionales de la salud, matrículas habilitantes, especialidades y disponibilidad.
- **Pacientes**: Registro de pacientes con cálculo automático de edad y grupo etario.
- **Fichas Médicas**: Historial clínico y datos biométricos del paciente con cálculo dinámico de IMC, diagnóstico nutricional y generación de alertas preventivas.
- **Turnos**: Agendamiento, confirmación, atención y cancelación de citas médicas, protegiendo los horarios de atención y evitando solapamientos horararios.

---

## 🛠 Tecnologías Utilizadas

- **Java**: 21 / 25
- **Framework**: Spring Boot 4.1.2
- **Persistencia**: Spring Data JPA & Hibernate ORM
- **Base de Datos**: MySQL 8.4 (con driver `mysql-connector-j`)
- **Validación**: Jakarta Validation (`spring-boot-starter-validation` / Hibernate Validator)
- **Productividad**: Project Lombok
- **Gestor de Construcción**: Apache Maven (con Maven Wrapper `mvnw`)
- **Herramienta de Testing de API**: Bruno (archivos `.bru` con `http://localhost:8080`)
- **Testing Unitario / Integración**: JUnit 5, Mockito

---

## 🏛 Estructura del Proyecto y Arquitectura en Capas

El backend está estrictamente desacoplado en capas de responsabilidad única:

```text
src/main/java/ar/edu/centro8/ps/tif/
├── controller/         # Capa Controller: Endpoints REST HTTP y mapeo de códigos de estado
│   ├── FichaMedicaController.java
│   ├── MedicoController.java
│   ├── PacienteController.java
│   └── TurnoController.java
├── service/            # Capa Service: Interfaces e implementaciones con lógica de negocio
│   ├── FichaMedicaService.java
│   ├── MedicoService.java
│   ├── PacienteService.java
│   ├── TurnoService.java
│   └── impl/
│       ├── FichaMedicaServiceImpl.java
│       ├── MedicoServiceImpl.java
│       ├── PacienteServiceImpl.java
│       └── TurnoServiceImpl.java     <-- Contiene la ÚNICA regla de negocio en Service
├── repository/         # Capa Repository: Interfaces Spring Data JPA con Query Methods
│   ├── FichaMedicaRepository.java
│   ├── MedicoRepository.java
│   ├── PacienteRepository.java
│   └── TurnoRepository.java
├── model/              # Capa Model: Entidades JPA con reglas de dominio encapsuladas
│   ├── FichaMedica.java
│   ├── Medico.java
│   ├── Paciente.java
│   ├── Turno.java                    <-- Contiene la regla de dominio del modelo
│   └── enums/
│       └── EstadoTurno.java
├── dto/                # Capa DTO: Objetos de transferencia desacoplados de la base de datos
│   ├── request/
│   │   ├── CancelarTurnoRequestDTO.java
│   │   ├── FichaMedicaRequestDTO.java
│   │   ├── MedicoRequestDTO.java
│   │   ├── PacienteRequestDTO.java
│   │   └── TurnoRequestDTO.java      <-- Contiene la regla de negocio en RequestDTO
│   └── response/
│       ├── ErrorResponseDTO.java
│       ├── FichaMedicaResponseDTO.java <-- Contiene la regla de negocio en ResponseDTO
│       ├── MedicoResponseDTO.java
│       ├── PacienteResponseDTO.java
│       └── TurnoResponseDTO.java
└── exception/          # Manejo centralizado de errores
    ├── BusinessException.java
    ├── DomainException.java
    ├── ResourceNotFoundException.java
    └── GlobalExceptionHandler.java
```

---

## 🎯 Las 4 Reglas Implementadas (Dominio y Negocio)

El proyecto implementa con precisión las 4 reglas específicas requeridas:

### 1. Regla de Negocio en RequestDTO
- **Ubicación**: `ar.edu.centro8.ps.tif.dto.request.TurnoRequestDTO`
- **Mecanismo**: Validación personalizada con la anotación `@AssertTrue` de Jakarta Validation.
- **Descripción**: Todo turno solicitado debe programarse estrictamente en días hábiles (lunes a viernes) y dentro de la franja horaria de atención habilitada por la clínica (de 08:00 a 20:00 hs).
- **Código**:
```java
@AssertTrue(message = "Regla de Negocio en RequestDTO: Los turnos únicamente pueden solicitarse de lunes a viernes dentro del horario de atención del consultorio (de 08:00 a 20:00 hs).")
public boolean isHorarioAtencionValido() {
    if (fechaHora == null) return true; // Valida @NotNull
    DayOfWeek dia = fechaHora.getDayOfWeek();
    if (dia == DayOfWeek.SATURDAY || dia == DayOfWeek.SUNDAY) return false;
    LocalTime hora = fechaHora.toLocalTime();
    return !hora.isBefore(LocalTime.of(8, 0)) && !hora.isAfter(LocalTime.of(20, 0));
}
```
- **Respuesta ante infracción**: Retorna `HTTP 400 Bad Request` indicando el detalle del horario fuera de rango antes de acceder al servicio.

---

### 2. Regla de Negocio en ResponseDTO
- **Ubicación**: `ar.edu.centro8.ps.tif.dto.response.FichaMedicaResponseDTO`
- **Mecanismo**: Cálculo y evaluación dinámica en el método `fromEntity(FichaMedica ficha)`.
- **Descripción**: A partir de los atributos biométricos persistidos (`peso` en kg y `altura` en metros), el ResponseDTO calcula en tiempo de respuesta:
  1. El **Índice de Masa Corporal ($IMC = \frac{\text{peso}}{\text{altura}^2}$)** redondeado a 2 decimales.
  2. La **Clasificación Nutricional de la OMS**: "Bajo peso", "Peso normal (Eutrófico)", "Sobrepeso (Pre-obesidad)" u "Obesidad".
  3. Una **Alerta Clínica Preventiva**: si el paciente presenta obesidad ($IMC \ge 30$), bajo peso ($IMC < 18.5$) o si tiene alergias declaradas, se adjunta una advertencia de interconsulta médica prioritaria.
- **Código**:
```java
if (ficha.getPeso() != null && ficha.getAltura() != null && ficha.getAltura() > 0) {
    double imcRaw = ficha.getPeso() / (ficha.getAltura() * ficha.getAltura());
    imcCalculado = Math.round(imcRaw * 100.0) / 100.0;

    if (imcCalculado < 18.5) {
        diagnostico = "Bajo peso";
        alerta = "Alerta: Paciente por debajo del peso saludable. Evaluar soporte nutricional y laboratorio.";
    } else if (imcCalculado < 25.0) {
        diagnostico = "Peso normal (Eutrófico)";
        alerta = "Estado nutricional dentro de parámetros saludables.";
    } else if (imcCalculado < 30.0) {
        diagnostico = "Sobrepeso (Pre-obesidad)";
        alerta = "Atención: Paciente con sobrepeso. Se sugiere pauta dietética y control cardiovascular.";
    } else {
        diagnostico = "Obesidad";
        alerta = "Alerta Crítica: Paciente con diagnóstico de obesidad. Requiere seguimiento médico prioritario.";
    }
}
```

---

### 3. Regla de Dominio en el Modelo (Entidad)
- **Ubicación**: `ar.edu.centro8.ps.tif.model.Turno`
- **Mecanismo**: Métodos de negocio (`cancelar(motivo)`, `marcarAtendido()`, `confirmar()`) en la propia entidad JPA (modelo rico frente a modelo anémico).
- **Descripción**: La entidad `Turno` protege sus propios invariantes de ciclo de vida:
  1. Un turno solo puede cancelarse si su estado es `PENDIENTE` o `CONFIRMADO`.
  2. Si el turno ya se encuentra en estado `CANCELADO`, lanza `DomainException("Regla de Dominio: El turno ya se encuentra en estado CANCELADO.")`.
  3. Si el turno ya fue `ATENDIDO`, no se permite su cancelación posterior, lanzando `DomainException("Regla de Dominio: No es posible cancelar un turno que ya ha sido ATENDIDO.")`.
  4. La cancelación exige obligatoriamente un motivo justificado no vacío.
- **Código**:
```java
public void cancelar(String motivo) {
    if (this.estado == EstadoTurno.CANCELADO) {
        throw new DomainException("Regla de Dominio: El turno ya se encuentra en estado CANCELADO.");
    }
    if (this.estado == EstadoTurno.ATENDIDO) {
        throw new DomainException("Regla de Dominio: No es posible cancelar un turno que ya ha sido ATENDIDO.");
    }
    if (motivo == null || motivo.trim().isEmpty()) {
        throw new DomainException("Regla de Dominio: Debe proporcionarse obligatoriamente un motivo para cancelar el turno.");
    }
    this.estado = EstadoTurno.CANCELADO;
    this.motivoCancelacion = motivo.trim();
}
```
- **Respuesta ante infracción**: Retorna `HTTP 400 Bad Request` con mensaje de excepción de dominio.

---

### 4. La Única Regla de Negocio en la Capa Service
- **Ubicación**: `ar.edu.centro8.ps.tif.service.impl.TurnoServiceImpl` (método `validarDisponibilidadHoraria`)
- **Mecanismo**: Verificación transaccional mediante query methods en `TurnoRepository`.
- **Descripción**: Al momento de crear o actualizar un turno, el servicio valida que el profesional médico seleccionado **no posea otro turno activo (con estado distinto a CANCELADO) en la misma fecha y hora exacta**. Asimismo, verifica que el paciente no tenga otro turno en simultáneo.
- **Declaración explícita**: Se establece como **la única regla de negocio de la capa Service** del proyecto; las restantes entidades (`Medico`, `Paciente`, `FichaMedica`) realizan persistencia y consultas CRUD directas con control de existencia.
- **Código**:
```java
private void validarDisponibilidadHoraria(Long medicoId, Long pacienteId, LocalDateTime fechaHora, Long turnoIdExcluir) {
    boolean medicoOcupado = (turnoIdExcluir == null)
            ? turnoRepository.existsByMedicoIdAndFechaHoraAndEstadoNot(medicoId, fechaHora, EstadoTurno.CANCELADO)
            : turnoRepository.existsByMedicoIdAndFechaHoraAndEstadoNotAndIdNot(medicoId, fechaHora, EstadoTurno.CANCELADO, turnoIdExcluir);

    if (medicoOcupado) {
        throw new BusinessException("Regla de Negocio (Service): El profesional médico ya tiene un turno agendado para la fecha y hora: " + fechaHora + ".");
    }

    boolean pacienteOcupado = (turnoIdExcluir == null)
            ? turnoRepository.existsByPacienteIdAndFechaHoraAndEstadoNot(pacienteId, fechaHora, EstadoTurno.CANCELADO)
            : turnoRepository.existsByPacienteIdAndFechaHoraAndEstadoNotAndIdNot(pacienteId, fechaHora, EstadoTurno.CANCELADO, turnoIdExcluir);

    if (pacienteOcupado) {
        throw new BusinessException("Regla de Negocio (Service): El paciente ya posee otro turno médico agendado en la misma fecha y hora: " + fechaHora + ".");
    }
}
```
- **Respuesta ante infracción**: Retorna `HTTP 409 Conflict` con mensaje claro de conflicto de agenda.

---

## 🗄 Modelo de Datos y Entidades

### Diagrama Entidad-Relación

```mermaid
erDiagram
    MEDICO ||--o{ TURNO : atiende
    PACIENTE ||--o{ TURNO : solicita
    PACIENTE ||--o| FICHA_MEDICA : posee

    MEDICO {
        bigint id PK
        varchar nombre
        varchar apellido
        varchar dni UK
        varchar matricula UK
        varchar especialidad
        varchar telefono
        varchar email
        boolean activo
    }

    PACIENTE {
        bigint id PK
        varchar nombre
        varchar apellido
        varchar dni UK
        date fecha_nacimiento
        varchar telefono
        varchar email
        varchar obra_social
    }

    FICHA_MEDICA {
        bigint id PK
        bigint paciente_id FK,UK
        varchar grupo_sanguineo
        varchar alergias
        varchar antecedentes
        double peso
        double altura
        text observaciones
        datetime fecha_creacion
    }

    TURNO {
        bigint id PK
        bigint paciente_id FK
        bigint medico_id FK
        datetime fecha_hora
        varchar motivo_consulta
        varchar estado
        varchar motivo_cancelacion
        datetime fecha_creacion
    }
```

---

## 🚀 Paso a Paso de Construcción del Proyecto

A continuación se detalla cronológicamente el proceso llevado a cabo para la construcción completa de la aplicación:

1. **Revisión y Diagnóstico del Esqueleto Inicial**:
   - Inspección del archivo `pom.xml`, estructura de directorios y versión de Spring Boot (4.1.2) sobre Java 21+.
   - Verificación de la compilación inicial mediante `mvnw clean compile`.

2. **Incorporación de Dependencias**:
   - Agregado de `spring-boot-starter-validation` en `pom.xml` para soporte de Bean Validation (Jakarta Validation).
   - Verificación de compatibilidad con `mysql-connector-j` y `lombok`.

3. **Configuración de la Base de Datos**:
   - Configuración de `src/main/resources/application.properties` con parámetros para MySQL (`jdbc:mysql://localhost:3306/consultorio_medico_db`).
   - Configuración de Hibernate en modo `update` (`spring.jpa.hibernate.ddl-auto=update`) y habilitación de logging de sentencias SQL.
   - Creación de la base de datos `consultorio_medico_db` en el servidor MySQL local.

4. **Diseño e Implementación de la Capa de Excepciones**:
   - Creación de excepciones personalizadas: `ResourceNotFoundException` (404), `BusinessException` (409) y `DomainException` (400).
   - Implementación de `GlobalExceptionHandler` con `@RestControllerAdvice` y estructura normalizada `ErrorResponseDTO`.

5. **Diseño de Entidades del Modelo JPA (con Regla de Dominio)**:
   - Creación del enum `EstadoTurno` (`PENDIENTE`, `CONFIRMADO`, `ATENDIDO`, `CANCELADO`).
   - Implementación de `Medico`, `Paciente`, `FichaMedica` y `Turno`.
   - Implementación de la **Regla de Dominio** dentro de `Turno.java` (`cancelar(motivo)`, `marcarAtendido()`, `confirmar()`).

6. **Desarrollo de la Capa DTO (Request y Response)**:
   - Creación de DTOs de solicitud: `MedicoRequestDTO`, `PacienteRequestDTO`, `FichaMedicaRequestDTO` y `CancelarTurnoRequestDTO`.
   - Implementación de la **Regla de Negocio en RequestDTO** en `TurnoRequestDTO.java` mediante validación `@AssertTrue` para días y horarios hábiles de atención.
   - Creación de DTOs de respuesta: `MedicoResponseDTO`, `PacienteResponseDTO`, `TurnoResponseDTO`.
   - Implementación de la **Regla de Negocio en ResponseDTO** en `FichaMedicaResponseDTO.java` calculando IMC, diagnóstico nutricional y alertas clínicas en tiempo de respuesta.

7. **Desarrollo de la Capa Repository**:
   - Creación de interfaces `MedicoRepository`, `PacienteRepository`, `FichaMedicaRepository` y `TurnoRepository`.
   - Implementación de Query Methods para consultas por DNI, matrícula, paciente, médico y consultas de solapamiento horario (`existsByMedicoIdAndFechaHoraAndEstadoNot`).

8. **Desarrollo de la Capa Service (con la Única Regla en Service)**:
   - Definición de interfaces de servicio para cada entidad.
   - Implementación de `TurnoServiceImpl.java` con **la única regla de negocio en la capa Service** (validación de disponibilidad horaria del profesional y paciente).
   - Implementación de servicios CRUD estándar en `MedicoServiceImpl`, `PacienteServiceImpl` y `FichaMedicaServiceImpl`.

9. **Desarrollo de la Capa Controller**:
   - Implementación de `MedicoController`, `PacienteController`, `FichaMedicaController` y `TurnoController`.
   - Exposición de endpoints CRUD completos (POST, GET, GET por ID, PUT, DELETE) y endpoints de acción para turnos (`/confirmar`, `/atender`, `/cancelar`).
   - Habilitación de CORS para facilitar el consumo desde clientes web.

10. **Implementación de Tests Automatizados**:
    - Creación de `ReglasNegocioYDominioTest.java` cubriendo las 4 reglas (RequestDTO, ResponseDTO, Dominio en Modelo y Negocio en Service).
    - Ejecución exitosa de los 12 tests unitarios e integrados mediante `./mvnw test`.

11. **Creación de la Colección de Pruebas Bruno**:
    - Creación del directorio `bruno/` y su manifiesto `bruno.json`.
    - Generación de 27 archivos `.bru` cubriendo todas las operaciones CRUD y casos de prueba de reglas de negocio, con URLs directas `http://localhost:8080`.

12. **Verificación en Ejecución Real**:
    - Inicio de la aplicación con `./mvnw spring-boot:run`.
    - Verificación y prueba de creación de entidades, cálculo de respuestas y rechazo controlado de violaciones de reglas con cURL y PowerShell.

---

## ⚙ Configuración de Base de Datos y Entorno

### Archivo `application.properties`
El archivo se encuentra en `src/main/resources/application.properties`:

```properties
spring.application.name=tif
server.port=8080

spring.datasource.url=jdbc:mysql://localhost:3306/consultorio_medico_db?createDatabaseIfNotExist=true&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=America/Argentina/Buenos_Aires
spring.datasource.username=${DB_USERNAME:root}
spring.datasource.password=${DB_PASSWORD:1234}
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver

spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.format_sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQLDialect
```

> **Nota**: Puedes ajustar el usuario y contraseña modificando el archivo o mediante variables de entorno `DB_USERNAME` y `DB_PASSWORD`.

---

## 🧪 Guía de Pruebas

### Colección Bruno
La carpeta `bruno/` contiene la colección lista para importar directamente en **Bruno**:
- **Sin variables de entorno requeridas**: todas las peticiones apuntan directamente a `http://localhost:8080`.
- **Estructura de carpetas en Bruno**:
  - `1_Medicos/`: Crear, Listar, Obtener por ID, Actualizar, Eliminar.
  - `2_Pacientes/`: Crear, Listar, Obtener por ID, Actualizar, Eliminar.
  - `3_Fichas_Medicas/`: Crear (aplica regla ResponseDTO), Listar, Obtener por ID, Obtener por Paciente ID, Actualizar, Eliminar.
  - `4_Turnos/`: Crear (horario válido), Listar, Obtener por ID, Listar por Paciente, Listar por Médico, Actualizar, Confirmar, Atender, Cancelar, Eliminar.
  - `5_Pruebas_Reglas/`:
    - `Regla 1 - RequestDTO Fin de Semana (Error 400).bru`
    - `Regla 1 - RequestDTO Fuera de Horario (Error 400).bru`
    - `Regla 2 - ResponseDTO Calculo IMC y Alerta (Exito 201).bru`
    - `Regla 3 - Dominio Modelo Cancelar Turno Atendido (Error 400).bru`
    - `Regla 3 - Dominio Modelo Cancelar Sin Motivo (Error 400).bru`
    - `Regla 4 - Service Solapamiento Horario Medico (Error 409).bru`

### Pruebas Automatizadas con Maven
Para compilar y correr la suite de pruebas unitarias y de integración:
```bash
./mvnw clean test
```
Salida esperada:
```text
[INFO] Running ar.edu.centro8.ps.tif.ReglasNegocioYDominioTest
[INFO] Tests run: 11, Failures: 0, Errors: 0, Skipped: 0
[INFO] Running ar.edu.centro8.ps.tif.TifApplicationTests
[INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
```

---

### Listado de Endpoints y Ejemplos cURL

#### Iniciar la aplicación:
```bash
./mvnw spring-boot:run
```

#### 1. Médicos (`/api/medicos`)
| Método | Endpoint | Descripción |
|---|---|---|
| `POST` | `http://localhost:8080/api/medicos` | Registrar médico |
| `GET` | `http://localhost:8080/api/medicos` | Listar todos los médicos |
| `GET` | `http://localhost:8080/api/medicos/{id}` | Obtener médico por ID |
| `PUT` | `http://localhost:8080/api/medicos/{id}` | Actualizar datos del médico |
| `DELETE` | `http://localhost:8080/api/medicos/{id}` | Eliminar médico |

*Ejemplo cURL para crear médico:*
```bash
curl -X POST http://localhost:8080/api/medicos \
  -H "Content-Type: application/json" \
  -d '{
    "nombre": "Gonzalo",
    "apellido": "Martinez",
    "dni": "32145678",
    "matricula": "MN-45920",
    "especialidad": "Cardiologia",
    "telefono": "1155667788",
    "email": "gonzalo.martinez@clinica.com",
    "activo": true
  }'
```

---

#### 2. Pacientes (`/api/pacientes`)
| Método | Endpoint | Descripción |
|---|---|---|
| `POST` | `http://localhost:8080/api/pacientes` | Registrar paciente |
| `GET` | `http://localhost:8080/api/pacientes` | Listar todos los pacientes |
| `GET` | `http://localhost:8080/api/pacientes/{id}` | Obtener paciente por ID |
| `PUT` | `http://localhost:8080/api/pacientes/{id}` | Actualizar paciente |
| `DELETE` | `http://localhost:8080/api/pacientes/{id}` | Eliminar paciente |

*Ejemplo cURL para crear paciente:*
```bash
curl -X POST http://localhost:8080/api/pacientes \
  -H "Content-Type: application/json" \
  -d '{
    "nombre": "Florencia",
    "apellido": "Alvarez",
    "dni": "35890123",
    "fechaNacimiento": "1992-08-15",
    "telefono": "1144332211",
    "email": "florencia.alvarez@gmail.com",
    "obraSocial": "OSDE"
  }'
```

---

#### 3. Fichas Médicas (`/api/fichas-medicas`)
*(Aplica Regla de Negocio en ResponseDTO con cálculo de IMC, diagnóstico y alertas)*

| Método | Endpoint | Descripción |
|---|---|---|
| `POST` | `http://localhost:8080/api/fichas-medicas` | Crear ficha médica |
| `GET` | `http://localhost:8080/api/fichas-medicas` | Listar fichas médicas |
| `GET` | `http://localhost:8080/api/fichas-medicas/{id}` | Obtener ficha por ID |
| `GET` | `http://localhost:8080/api/fichas-medicas/paciente/{pacienteId}` | Obtener ficha por ID de paciente |
| `PUT` | `http://localhost:8080/api/fichas-medicas/{id}` | Actualizar ficha médica |
| `DELETE` | `http://localhost:8080/api/fichas-medicas/{id}` | Eliminar ficha médica |

*Ejemplo cURL para crear ficha médica:*
```bash
curl -X POST http://localhost:8080/api/fichas-medicas \
  -H "Content-Type: application/json" \
  -d '{
    "pacienteId": 1,
    "grupoSanguineo": "A+",
    "alergias": "Penicilina, Ibuprofeno",
    "antecedentes": "Hipertension arterial familiar",
    "peso": 72.5,
    "altura": 1.74,
    "observaciones": "Control semestral preventivo."
  }'
```

---

#### 4. Turnos Médicos (`/api/turnos`)
*(Aplica Regla de RequestDTO, Regla de Dominio y Única Regla en Service)*

| Método | Endpoint | Descripción |
|---|---|---|
| `POST` | `http://localhost:8080/api/turnos` | Crear turno (aplica regla RequestDTO y regla Service) |
| `GET` | `http://localhost:8080/api/turnos` | Listar todos los turnos |
| `GET` | `http://localhost:8080/api/turnos/{id}` | Obtener turno por ID |
| `GET` | `http://localhost:8080/api/turnos/paciente/{pacienteId}` | Listar turnos de un paciente |
| `GET` | `http://localhost:8080/api/turnos/medico/{medicoId}` | Listar turnos de un médico |
| `GET` | `http://localhost:8080/api/turnos/estado/{estado}` | Filtrar turnos por estado |
| `PUT` | `http://localhost:8080/api/turnos/{id}` | Actualizar / reprogramar turno |
| `PUT` | `http://localhost:8080/api/turnos/{id}/confirmar` | Confirmar turno (Regla de Dominio) |
| `PUT` | `http://localhost:8080/api/turnos/{id}/atender` | Atender turno (Regla de Dominio) |
| `PUT` | `http://localhost:8080/api/turnos/{id}/cancelar` | Cancelar turno con motivo (Regla de Dominio) |
| `DELETE` | `http://localhost:8080/api/turnos/{id}` | Eliminar turno |

*Ejemplo cURL para crear turno válido:*
```bash
curl -X POST http://localhost:8080/api/turnos \
  -H "Content-Type: application/json" \
  -d '{
    "pacienteId": 1,
    "medicoId": 1,
    "fechaHora": "2026-11-25T10:00:00",
    "motivoConsulta": "Control cardiologico semestral"
  }'
```

*Ejemplo cURL para cancelar turno (Regla de Dominio):*
```bash
curl -X PUT http://localhost:8080/api/turnos/1/cancelar \
  -H "Content-Type: application/json" \
  -d '{
    "motivo": "El paciente solicita reprogramar la consulta para la siguiente semana."
  }'
```
