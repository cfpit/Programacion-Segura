package ar.edu.centro8.ps.jwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
