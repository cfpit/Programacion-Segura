package ar.edu.centro8.ps.proyectojpa2.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import ar.edu.centro8.ps.proyectojpa2.model.Auto;

@Repository
public interface AutoRepository extends JpaRepository<Auto, Long> {

}
