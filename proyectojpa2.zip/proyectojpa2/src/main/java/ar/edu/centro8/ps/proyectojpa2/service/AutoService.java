package ar.edu.centro8.ps.proyectojpa2.service;

import org.springframework.stereotype.Service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import ar.edu.centro8.ps.proyectojpa2.model.Auto;
import ar.edu.centro8.ps.proyectojpa2.repository.AutoRepository;

@Service
public class AutoService {

    @Autowired
    private AutoRepository autoRepository;

    public Auto guardar(Auto auto) {
        return autoRepository.save(auto);
    }

    public Auto buscarPorId(Long id) {
        return autoRepository.findById(id).orElse(null);
    }

    public void eliminar(Long id) {
        autoRepository.deleteById(id);
    }

    public List<Auto> buscarTodos() {
        return autoRepository.findAll();
    }

    // modificacion de datos de marca y precio a partir de id de Auto
    public Auto modificarMarcaPrecio(Long id, String marca, double precio) {
        Auto auto = buscarPorId(id);
        if (auto != null) {
            auto.setMarca(marca);
            auto.setPrecio(precio);
            return autoRepository.save(auto);
        }
        return null;
    }

}
