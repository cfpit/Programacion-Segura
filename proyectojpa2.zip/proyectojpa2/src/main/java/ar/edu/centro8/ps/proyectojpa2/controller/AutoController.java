package ar.edu.centro8.ps.proyectojpa2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ar.edu.centro8.ps.proyectojpa2.model.Auto;
import ar.edu.centro8.ps.proyectojpa2.service.AutoService;

@RestController
@RequestMapping("/autos")
public class AutoController {
    @Autowired
    private AutoService autoService;

    @GetMapping
    public List<Auto> listarTodosLosAutos() {
        return autoService.buscarTodos();
    }

    @GetMapping("/{id}")
    public Auto obtenerAutoPorId(@PathVariable Long id) {
        return autoService.buscarPorId(id);
    }

    @PostMapping
    public Auto guardarAuto(@RequestBody Auto auto) {
        return autoService.guardar(auto);
    }

    @DeleteMapping("/{id}")
    public void eliminarAuto(@PathVariable Long id) {
        autoService.eliminar(id);
    }

    @PutMapping("/{id}")
    public Auto actualizarAuto(@PathVariable Long id, @RequestBody Auto auto) {
        return autoService.modificarMarcaPrecio(id, auto.getMarca(), auto.getPrecio());
    }

}
