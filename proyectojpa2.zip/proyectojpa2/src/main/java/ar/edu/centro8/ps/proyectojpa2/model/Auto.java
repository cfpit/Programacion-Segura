package ar.edu.centro8.ps.proyectojpa2.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "autos")
@Data
@NoArgsConstructor
@AllArgsConstructor

public class Auto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "codigo")
    private Long id;

    @Column(length = 20, nullable = false)
    private String marca;

    @Column(length = 20, nullable = false)
    private double precio;
}
