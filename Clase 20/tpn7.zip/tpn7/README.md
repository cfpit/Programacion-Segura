# TP7 - Programación Segura: Autenticación y Autorización basada en JWT

Proyecto de Spring Boot que implementa **autenticación y autorización basada en JSON Web Tokens (JWT)** tomando como base el **Trabajo Práctico Nro. 6** (Encriptado de contraseñas con BCrypt y control de acceso RBAC).

---

## 📌 Resumen del Proyecto

Este proyecto combina la robustez del modelo de datos y seguridad de contraseñas de TP6 con un esquema de autenticación **Stateless basada en tokens JWT**, siguiendo la guía de *Ejercicio Autenticación basada en JWT*:

- **Algoritmo de Firma**: HMAC256 con clave privada de 256 bits (`SHA-256`).
- **Emisor (Issuer)**: `CENTRO8-SEC`.
- **Tiempo de Expiración**: 30 minutos (1.800.000 ms).
- **Claims incluidos en el Token**:
  - `sub`: Nombre de usuario autenticado.
  - `authorities`: Cadena separada por comas con todos los Roles (`ROLE_ADMIN`, `ROLE_USER`) y Permisos (`READ`, `CREATE`, etc.) otorgados en BD.
  - `iss`: Emisor del token (`CENTRO8-SEC`).
  - `iat`: Timestamp de emisión.
  - `exp`: Timestamp de expiración.
  - `jti`: Identificador único UUID del token.
  - `nbf`: Válido inmediatamente (`Not Before`).
- **Filtro Personalizado**: `JwtTokenValidator` intercepta peticiones HTTP con encabezado `Authorization: Bearer <token>`.

---

## 🛠️ Stack Tecnológico

- **Java**: 21 LTS
- **Framework**: Spring Boot 3.5.0
- **Seguridad**: Spring Security 6 (Stateless, Method Security con `@PreAuthorize`, BCryptPasswordEncoder)
- **Librería JWT**: `com.auth0:java-jwt` (v4.4.0)
- **Validación**: Jakarta Validation (`spring-boot-starter-validation`)
- **Persistencia**: Spring Data JPA / Hibernate 6
- **Base de Datos**: MySQL 8.4
- **Testing de API**: Colección parametrizada para Bruno API Client

---

## ⚙️ Configuración (`application.properties`)

```properties
spring.application.name=tp7

# Base de Datos MySQL
spring.jpa.hibernate.ddl-auto=update
spring.jpa.database-platform=org.hibernate.dialect.MySQLDialect
spring.datasource.url=jdbc:mysql://localhost:3306/security?createDatabaseIfNotExist=true&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=1234
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver

# Credenciales por defecto
spring.security.user.name=${SS_USER:centro8}
spring.security.user.password=${SS_PASSWORD:1234}

# Configuración de JWT
security.jwt.private.key=${PRIVATE_KEY:3dd76886d75471fcc8422c68a8980ab692d452b29424d6a481b49b2c8e46ce8e}
security.jwt.user.generator=${USER_GENERATOR:CENTRO8-SEC}
```

> **Nota de Seguridad**: Todos los parámetros admiten tanto valores fijos como inyección por variables de entorno (`SS_USER`, `SS_PASSWORD`, `PRIVATE_KEY`, `USER_GENERATOR`).

---

## 🧩 Arquitectura y Flujo de Funcionamiento

### 1. Flujo de Login y Generación del Token (`POST /auth/login`)

```
Cliente HTTP 
    │  POST /auth/login { "username": "centro8", "password": "1234" }
    ▼
AuthenticationController
    │  Llama a userDetailsService.loginUser(...)
    ▼
UserDetailsServiceImp
    │  1. Busca UserSec en BD MySQL
    │  2. Valida la contraseña con passwordEncoder.matches(...) [BCrypt]
    │  3. Carga Roles (ROLE_ADMIN) y Permisos (READ, CREATE)
    │  4. Invoca jwtUtils.createToken(authentication)
    ▼
JwtUtils
    │  Firma con HMAC256 usando private.key y user.generator
    ▼
Cliente HTTP
    ◄─ Devuelve AuthResponseDTO:
       {
         "username": "centro8",
         "message": "login ok",
         "jwt": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
         "status": true
       }
```

### 2. Flujo de Validación e Intercepción (`JwtTokenValidator`)

Para cualquier endpoint protegido:
1. El cliente envía el header `Authorization: Bearer <token>`.
2. `JwtTokenValidator` extrae el token (omitiendo el prefijo `"Bearer "`).
3. `jwtUtils.validateToken(token)` verifica la firma HMAC256 y el emisor (`CENTRO8-SEC`).
4. Si es válido:
   - Se extraen `username` y `authorities`.
   - Se genera una lista de `GrantedAuthority` a partir del claim `authorities`.
   - Se construye `UsernamePasswordAuthenticationToken(username, null, authoritiesList)`.
   - Se establece en `SecurityContextHolder` y se guarda en `RequestAttributeSecurityContextRepository`.
5. Si no es válido o está expirado:
   - Se limpia el contexto de seguridad (`clearContext()`).
   - Spring Security deniega la petición con `401 Unauthorized`.

### 3. Diferencia entre `JwtTokenValidator` y `JwtUtils.validateToken()`

#### ¿Quién valida al final el token generado por el servidor?
* **Criptográfica y técnicamente**: Lo valida **`jwtUtils.validateToken()`** mediante la librería `com.auth0:java-jwt`, verificando la firma HMAC256 contra la clave privada secreta, el emisor y los tiempos de expiración.
* **A nivel de protocolo HTTP y Spring Security**: Lo valida **`JwtTokenValidator`**, que es el **filtro interceptor** que extrae el token del encabezado de la petición HTTP, delega la verificación técnica a `JwtUtils`, y si es válido, registra la identidad y roles del usuario en el `SecurityContextHolder`.

| Característica | `JwtTokenValidator.java` | `JwtUtils.java` (`validateToken`) |
| :--- | :--- | :--- |
| **Capa** | Capa Web / Seguridad HTTP (`OncePerRequestFilter`) | Capa Utilitaria / Criptográfica (`@Component`) |
| **Entrada** | `HttpServletRequest` (analiza encabezados HTTP) | `String token` (cadena JWT pura) |
| **Responsabilidad** | Interceptar peticiones, extraer `Bearer <token>`, poblar `SecurityContext` | Validar firma HMAC256, emisor (`iss`), expiración (`exp`) |
| **Conocimiento de HTTP** | Sí (conoce headers, requests, responses y filtros) | No (es independiente de la capa web) |
| **Resultado si es válido** | Registra el `Authentication` en Spring Security | Retorna el objeto `DecodedJWT` con los claims |
| **Resultado si falla** | Limpia el contexto (`clearContext()`) y continúa la cadena | Lanza `JWTVerificationException` |

```text
Cliente HTTP (Bruno / Postman / Frontend)
    │
    │  GET /holaseg
    │  Header: Authorization: Bearer eyJhbGci...
    ▼
[ JwtTokenValidator ] (Filtro HTTP - OncePerRequestFilter)
    │  1. Lee el encabezado "Authorization"
    │  2. Extrae el string eliminando "Bearer "
    │
    ├──► [ jwtUtils.validateToken(token) ] (Validador Criptográfico)
    │        │  - Verifica algoritmo HMAC256
    │        │  - Verifica firma con clave privada
    │        │  - Verifica vigencia (exp, nbf) y emisor (iss)
    │        ▼
    │     ¿Es válido el token?
    │        ├── No  ──► Lanza excepción -> Limpia contexto -> 401 Unauthorized
    │        └── Sí  ──► Retorna DecodedJWT con claims
    │
    │  3. Extrae username ("seguidor") y roles ("ROLE_USER", "READ")
    │  4. Crea UsernamePasswordAuthenticationToken y lo asigna a SecurityContextHolder
    ▼
[ Controlador / Endpoint: HelloWorldController ]
    │  @PreAuthorize("hasRole('ADMIN')")
    ▼
¿Tiene el rol ADMIN requerido?
    ├── Sí (centro8)  ──► 200 OK ("¡Hola con Seguridad!")
    └── No (seguidor) ──► 403 Forbidden (Acceso Denegado)
```

---

## 🔒 Matriz de Endpoints y Reglas de Autorización

| Endpoint | Método | Acceso / Regla `@PreAuthorize` | Token Requerido |
| :--- | :---: | :--- | :---: |
| `/auth/login` | POST | `permitAll()` (Público) | No |
| `/holanoseg` | GET | `permitAll()` (Público) | No |
| `/holaseg` | GET | `hasRole('ADMIN')` | Sí (Rol ADMIN) |
| `/api/permissions` | GET | `hasAnyRole('ADMIN', 'USER')` | Sí (ADMIN o USER) |
| `/api/permissions/{id}` | GET | `hasAnyRole('ADMIN', 'USER')` | Sí (ADMIN o USER) |
| `/api/permissions` | POST | `hasRole('ADMIN') and hasAuthority('CREATE')` | Sí (ADMIN + Permiso CREATE) |
| `/api/roles` | GET | `hasAnyRole('ADMIN', 'USER')` | Sí (ADMIN o USER) |
| `/api/roles/{id}` | GET | `hasAnyRole('ADMIN', 'USER')` | Sí (ADMIN o USER) |
| `/api/roles` | POST | `hasRole('ADMIN') and hasAuthority('CREATE')` | Sí (ADMIN + Permiso CREATE) |
| `/api/roles/{id}` | PATCH | `hasRole('ADMIN')` | Sí (Rol ADMIN) |
| `/api/users` | GET | `hasAnyRole('ADMIN', 'USER')` | Sí (ADMIN o USER) |
| `/api/users/{id}` | GET | `hasAnyRole('ADMIN', 'USER')` | Sí (ADMIN o USER) |
| `/api/users` | POST | `hasRole('ADMIN') and hasAuthority('CREATE')` | Sí (ADMIN + Permiso CREATE) |

---

## 🧪 Suite de Pruebas en Bruno API Client

La carpeta `/bruno` contiene la colección parametrizada lista para ejecutar:

```text
tpn7/bruno/
├── bruno.json
├── collection.bru
├── environments/
│   └── Local.bru                                    # Define baseUrl, token_admin, token_user
├── 01-Autenticacion (Login)/
│   ├── 01-Login ADMIN - centro8 (Obtener Token).bru  # Guarda automáticamente {{token_admin}}
│   ├── 02-Login USER - seguidor (Obtener Token).bru  # Guarda automáticamente {{token_user}}
│   ├── 03-Login Fallido - Password Incorrecta.bru   # Retorna 401 Unauthorized
│   └── 04-Login Fallido - Usuario Inexistente.bru   # Retorna 401 Unauthorized
├── 02-Pruebas de Seguridad JWT/
│   ├── 01-GET Hola Sin Seguridad (Publico - Sin Token).bru # 200 OK
│   ├── 02-GET Hola Con Seguridad - Bearer Token ADMIN centro8.bru # 200 OK ("¡Hola con Seguridad!")
│   ├── 03-GET Hola Con Seguridad - Bearer Token USER seguidor (403 Forbidden).bru # 403 Forbidden
│   ├── 04-GET Hola Con Seguridad - Sin Token (401 Unauthorized).bru # 401 Unauthorized
│   └── 05-GET Hola Con Seguridad - Token Invalido (401 Unauthorized).bru # 401 Unauthorized
├── 03-Permisos/
│   ├── 01-Listar Permisos - Token ADMIN.bru         # 200 OK
│   ├── 02-Listar Permisos - Token USER.bru          # 200 OK
│   ├── 03-Crear Permiso - Token ADMIN con CREATE.bru # 200 OK
│   └── 04-Crear Permiso - Token USER (403 Forbidden).bru # 403 Forbidden
├── 04-Roles/
│   ├── 01-Listar Roles - Token ADMIN.bru            # 200 OK
│   ├── 02-Listar Roles - Token USER.bru             # 200 OK
│   ├── 03-PATCH Modificar Rol - Token ADMIN.bru     # 200 OK
│   └── 04-PATCH Modificar Rol - Token USER (403 Forbidden).bru # 403 Forbidden
└── 05-Usuarios/
    ├── 01-Listar Usuarios - Token ADMIN.bru         # 200 OK
    ├── 02-Listar Usuarios - Token USER.bru          # 200 OK
    ├── 03-Crear Usuario - Token ADMIN con CREATE.bru # 200 OK (Contraseña hasheada con BCrypt)
    └── 04-Crear Usuario - Token USER (403 Forbidden).bru # 403 Forbidden
```

---

## 🚀 Cómo Ejecutar el Proyecto

1. **Requisitos previos**:
   - JDK 21 instalado (`JAVA_HOME` apuntando a Java 21).
   - MySQL Server 8.x corriendo en el puerto `3306` (usuario `root`, contraseña `1234`).
   - La base de datos `security` se actualiza/crea automáticamente (`ddl-auto=update`).

2. **Compilar y ejecutar**:
   ```bash
   cd tpn7
   ./mvnw spring-boot:run
   ```

3. **Ejecutar Pruebas**:
   - Abrir Bruno API Client.
   - Cargar la carpeta `tpn7/bruno`.
   - Seleccionar el entorno `Local`.
   - Ejecutar en orden:
     1. `01-Autenticacion (Login) -> 01-Login ADMIN - centro8 (Obtener Token)` (guarda el token de admin).
     2. `01-Autenticacion (Login) -> 02-Login USER - seguidor (Obtener Token)` (guarda el token de user).
     3. Ejecutar las carpetas `02-Pruebas de Seguridad JWT`, `03-Permisos`, `04-Roles` y `05-Usuarios`.
