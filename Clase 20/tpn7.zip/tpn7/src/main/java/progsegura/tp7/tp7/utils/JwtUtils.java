package progsegura.tp7.tp7.utils;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

@Component
public class JwtUtils {

    // Clave privada para firmar los tokens JWT (garantiza autenticidad e integridad)
    @Value("${security.jwt.private.key}")
    private String privateKey;

    // Nombre de usuario / emisor del token (Issuer)
    @Value("${security.jwt.user.generator}")
    private String userGenerator;

    /**
     * Genera un token JWT firmado a partir de la autenticación del usuario.
     */
    public String createToken(Authentication authentication) {
        Algorithm algorithm = Algorithm.HMAC256(this.privateKey);

        // Nombre de usuario autenticado
        String username = authentication.getPrincipal().toString();

        // Permisos y roles del usuario separados por coma
        String authorities = authentication.getAuthorities()
                .stream()
                .map(GrantedAuthority::getAuthority)
                .collect(Collectors.joining(","));

        // Creación y firma del token JWT
        String jwtToken = JWT.create()
                .withIssuer(this.userGenerator) // Emisor
                .withSubject(username) // Sujeto / destinatario del token
                .withClaim("authorities", authorities) // Claims con roles y permisos
                .withIssuedAt(new Date()) // Fecha de emisión
                .withExpiresAt(new Date(System.currentTimeMillis() + 1800000)) // Expira en 30 minutos (1.800.000 ms)
                .withJWTId(UUID.randomUUID().toString()) // Identificador único del token
                .withNotBefore(new Date(System.currentTimeMillis())) // Válido desde ahora
                .sign(algorithm); // Firma con el algoritmo HMAC256 y la clave secreta

        return jwtToken;
    }

    /**
     * Valida y decodifica un token JWT. Lanza JWTVerificationException si no es válido.
     */
    public DecodedJWT validateToken(String token) {
        try {
            Algorithm algorithm = Algorithm.HMAC256(this.privateKey);
            JWTVerifier verifier = JWT.require(algorithm)
                    .withIssuer(this.userGenerator)
                    .build();

            return verifier.verify(token);
        } catch (JWTVerificationException exception) {
            throw new JWTVerificationException("Invalid token. Not authorized");
        }
    }

    /**
     * Extrae el nombre de usuario (Subject) del token decodificado.
     */
    public String extractUsername(DecodedJWT decodedJWT) {
        return decodedJWT.getSubject();
    }

    /**
     * Extrae un Claim específico del token decodificado.
     */
    public Claim getSpecificClaim(DecodedJWT decodedJWT, String claimName) {
        return decodedJWT.getClaim(claimName);
    }

    /**
     * Retorna todos los Claims contenidos en el token decodificado.
     */
    public Map<String, Claim> returnAllClaims(DecodedJWT decodedJWT) {
        return decodedJWT.getClaims();
    }
}
