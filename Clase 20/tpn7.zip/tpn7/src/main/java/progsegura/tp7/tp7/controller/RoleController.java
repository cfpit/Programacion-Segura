package progsegura.tp7.tp7.controller;

import progsegura.tp7.tp7.model.Role;
import progsegura.tp7.tp7.model.Permission;
import progsegura.tp7.tp7.service.IPermissionService;
import progsegura.tp7.tp7.service.IRoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@RestController
@RequestMapping("/api/roles")
public class RoleController {

    @Autowired
    private IRoleService roleService;

    @Autowired
    private IPermissionService permiService;

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'USER')")
    public ResponseEntity<List<Role>> getAllRoles() {
        List<Role> roles = roleService.findAll();
        return ResponseEntity.ok(roles);
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'USER')")
    public ResponseEntity<Role> getRoleById(@PathVariable Long id) {
        Optional<Role> role = roleService.findById(id);
        return role.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN') and hasAuthority('CREATE')")
    public ResponseEntity<Role> createRole(@RequestBody Role role) {
        Set<Permission> permiList = new HashSet<>();
        Permission readPermission;

        // Recuperar las Permissions por su ID
        for (Permission per : role.getPermissionsList()) {
            readPermission = permiService.findById(per.getId()).orElse(null);
            if (readPermission != null) {
                permiList.add(readPermission);
            }
        }

        role.setPermissionsList(permiList);
        Role newRole = roleService.save(role);
        return ResponseEntity.ok(newRole);
    }

    @PatchMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Role> updateRolePermissions(@PathVariable Long id, @RequestBody Role roleDetails) {
        Optional<Role> roleOpt = roleService.findById(id);
        if (roleOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Role role = roleOpt.get();

        if (roleDetails.getRole() != null && !roleDetails.getRole().isEmpty()) {
            role.setRole(roleDetails.getRole());
        }

        if (roleDetails.getPermissionsList() != null) {
            Set<Permission> permiList = new HashSet<>();
            for (Permission per : roleDetails.getPermissionsList()) {
                Permission readPermission = permiService.findById(per.getId()).orElse(null);
                if (readPermission != null) {
                    permiList.add(readPermission);
                }
            }
            role.setPermissionsList(permiList);
        }

        Role updatedRole = roleService.update(role);
        return ResponseEntity.ok(updatedRole);
    }
}