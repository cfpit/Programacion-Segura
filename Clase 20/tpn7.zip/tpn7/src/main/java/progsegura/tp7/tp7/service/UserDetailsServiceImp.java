package progsegura.tp7.tp7.service;

import progsegura.tp7.tp7.dto.AuthLoginRequestDTO;
import progsegura.tp7.tp7.dto.AuthResponseDTO;
import progsegura.tp7.tp7.model.UserSec;
import progsegura.tp7.tp7.repository.IUserRepository;
import progsegura.tp7.tp7.utils.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserDetailsServiceImp implements UserDetailsService {

    @Autowired
    private IUserRepository userRepo;

    @Autowired
    private JwtUtils jwtUtils;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        // Traer el Usuario desde la Base de Datos
        UserSec userSec = userRepo.findUserEntityByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("El usuario " + username + " no fue encontrado"));

        // Lista de autoridades (Roles y Permisos)
        List<SimpleGrantedAuthority> authorityList = new ArrayList<>();

        // Agregado de los Roles como Autoridades (prefijados con "ROLE_")
        userSec.getRolesList().forEach(role ->
                authorityList.add(new SimpleGrantedAuthority("ROLE_" + role.getRole()))
        );

        // Agregado de los Permisos correspondientes a cada Role
        userSec.getRolesList().stream()
                .flatMap(role -> role.getPermissionsList().stream())
                .forEach(permission ->
                        authorityList.add(new SimpleGrantedAuthority(permission.getPermissionName()))
                );

        // Retorno del usuario en formato Spring Security UserDetails
        return new User(
                userSec.getUsername(),
                userSec.getPassword(),
                userSec.isEnabled(),
                userSec.isAccountNotExpired(),
                userSec.isCredentialNotExpired(),
                userSec.isAccountNotLocked(),
                authorityList
        );
    }

    /**
     * Valida credenciales y genera el token JWT para el usuario.
     */
    public AuthResponseDTO loginUser(AuthLoginRequestDTO authLoginRequest) {
        String username = authLoginRequest.username();
        String password = authLoginRequest.password();

        Authentication authentication = this.authenticate(username, password);

        // Establecer autenticación en el contexto de seguridad
        SecurityContextHolder.getContext().setAuthentication(authentication);

        // Crear token JWT firmado con claims y roles/permisos
        String accessToken = jwtUtils.createToken(authentication);

        return new AuthResponseDTO(username, "login ok", accessToken, true);
    }

    /**
     * Autentica el usuario validando su contraseña hasheada con BCrypt.
     */
    public Authentication authenticate(String username, String password) {
        UserDetails userDetails = this.loadUserByUsername(username);

        if (userDetails == null) {
            throw new BadCredentialsException("Invalid username or password");
        }

        // Validación de la contraseña con BCryptPasswordEncoder
        if (!passwordEncoder.matches(password, userDetails.getPassword())) {
            throw new BadCredentialsException("Invalid password");
        }

        return new UsernamePasswordAuthenticationToken(username, userDetails.getPassword(), userDetails.getAuthorities());
    }
}
