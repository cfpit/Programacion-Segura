package progsegura.tp7.tp7.service;

import progsegura.tp7.tp7.model.Role;
import java.util.List;
import java.util.Optional;

public interface IRoleService {
    List<Role> findAll();
    Optional<Role> findById(Long id);
    Role save(Role role);
    void deleteById(Long id);
    Role update(Role role);
}