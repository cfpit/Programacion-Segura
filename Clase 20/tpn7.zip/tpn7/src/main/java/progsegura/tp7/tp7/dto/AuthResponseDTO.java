package progsegura.tp7.tp7.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/*
 * Cuando una clase se declara como un registro (record), el compilador de Java genera
 * automáticamente ciertos métodos como constructor, equals(), hashCode() y toString().
 */
@JsonPropertyOrder({"username", "message", "jwt", "status"})
public record AuthResponseDTO(String username, String message, String jwt, boolean status) {
}
