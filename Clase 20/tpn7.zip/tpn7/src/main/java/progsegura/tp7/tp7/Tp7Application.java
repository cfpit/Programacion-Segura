package progsegura.tp7.tp7;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;

@SpringBootApplication
public class Tp7Application {

	public static void main(String[] args) {
		SpringApplication.run(Tp7Application.class, args);
	}

	@Bean
	public CommandLineRunner initData(JdbcTemplate jdbcTemplate, PasswordEncoder passwordEncoder) {
		return args -> {
			try {
				Integer userCount = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM users", Integer.class);
				if (userCount == null || userCount == 0) {
					jdbcTemplate.execute("INSERT INTO permissions (id, permission_name) VALUES (1, 'READ'), (2, 'CREATE') ON DUPLICATE KEY UPDATE permission_name=VALUES(permission_name)");
					jdbcTemplate.execute("INSERT INTO roles (id, role) VALUES (1, 'ADMIN'), (2, 'USER') ON DUPLICATE KEY UPDATE role=VALUES(role)");
					jdbcTemplate.execute("INSERT IGNORE INTO roles_permissions (role_id, permission_id) VALUES (1, 1), (1, 2), (2, 1)");

					String passCentro8 = passwordEncoder.encode("1234");
					String passSeguidor = passwordEncoder.encode("1234");
					jdbcTemplate.update(
						"INSERT INTO users (id, username, password, enabled, account_not_expired, account_not_locked, credential_not_expired) " +
						"VALUES (1, 'centro8', ?, true, true, true, true), (2, 'seguidor', ?, true, true, true, true) " +
						"ON DUPLICATE KEY UPDATE password=VALUES(password)",
						passCentro8, passSeguidor
					);
					jdbcTemplate.execute("INSERT IGNORE INTO user_roles (user_id, role_id) VALUES (1, 1), (2, 2)");
				}
			} catch (Exception e) {
				// Si las tablas aún no se han creado en algún entorno de prueba específico, se omite silenciosamente
			}
		};
	}
}
