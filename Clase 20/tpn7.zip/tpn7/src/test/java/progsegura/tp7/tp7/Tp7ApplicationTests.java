package progsegura.tp7.tp7;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class Tp7ApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	private final ObjectMapper mapper = new ObjectMapper();

	@Test
	void testHolaSegAccessControl() throws Exception {
		// 1. Login como ADMIN (centro8) -> debe acceder 200 OK
		String loginAdminBody = "{\"username\":\"centro8\",\"password\":\"1234\"}";
		MvcResult loginAdminResult = mockMvc.perform(post("/auth/login")
						.contentType(MediaType.APPLICATION_JSON)
						.content(loginAdminBody))
				.andExpect(status().isOk())
				.andReturn();
		String tokenAdmin = mapper.readTree(loginAdminResult.getResponse().getContentAsString()).get("jwt").asText();

		mockMvc.perform(get("/holaseg")
						.header("Authorization", "Bearer " + tokenAdmin))
				.andExpect(status().isOk())
				.andExpect(content().string("¡Hola con Seguridad!"));

		// 2. Login como USER (seguidor) -> debe recibir 403 Forbidden (está autenticado pero no es ADMIN)
		String loginUserBody = "{\"username\":\"seguidor\",\"password\":\"1234\"}";
		MvcResult loginUserResult = mockMvc.perform(post("/auth/login")
						.contentType(MediaType.APPLICATION_JSON)
						.content(loginUserBody))
				.andExpect(status().isOk())
				.andReturn();
		String tokenUser = mapper.readTree(loginUserResult.getResponse().getContentAsString()).get("jwt").asText();

		mockMvc.perform(get("/holaseg")
						.header("Authorization", "Bearer " + tokenUser))
				.andExpect(status().isForbidden());

		// 3. Sin Token -> 401 Unauthorized
		mockMvc.perform(get("/holaseg"))
				.andExpect(status().isUnauthorized());

		// 4. Token Inválido / Expirado -> 401 Unauthorized
		mockMvc.perform(get("/holaseg")
						.header("Authorization", "Bearer token_falso_invalido"))
				.andExpect(status().isUnauthorized());
	}
}
