package ar.edu.centro8.ps.rolesbd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RolesbdApplication {

	public static void main(String[] args) {
		SpringApplication.run(RolesbdApplication.class, args);
	}

}
