package ar.edu.centro8.ps.rolesbd.config;

import ar.edu.centro8.ps.rolesbd.model.Permission;
import ar.edu.centro8.ps.rolesbd.model.Role;
import ar.edu.centro8.ps.rolesbd.model.UserSec;
import ar.edu.centro8.ps.rolesbd.repository.IPermissionRepository;
import ar.edu.centro8.ps.rolesbd.repository.IRoleRepository;
import ar.edu.centro8.ps.rolesbd.repository.IUserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Configuration
public class DataInitializerConfig {

    @Bean
    public CommandLineRunner initData(IUserRepository userRepository,
                                      IRoleRepository roleRepository,
                                      IPermissionRepository permissionRepository) {
        return args -> {
            // 1. Obtener o crear los permisos
            List<String> permNames = List.of("READ", "CREATE", "UPDATE", "DELETE");
            Set<Permission> permissions = new HashSet<>();

            for (String name : permNames) {
                Permission p = permissionRepository.findByPermissionName(name)
                        .orElseGet(() -> {
                            Permission newP = new Permission();
                            newP.setPermissionName(name);
                            return permissionRepository.save(newP);
                        });
                permissions.add(p);
            }

            // 2. Obtener o crear el rol ADMIN
            Role adminRole = roleRepository.findByRole("ADMIN")
                    .orElseGet(() -> {
                        Role newRole = new Role();
                        newRole.setRole("ADMIN");
                        newRole.setPermissionsList(permissions);
                        return roleRepository.save(newRole);
                    });

            // 3. Crear usuario admin inicial si no existe
            if (userRepository.findUserEntityByUsername("admin").isEmpty()) {
                UserSec adminUser = new UserSec();
                adminUser.setUsername("admin");
                adminUser.setPassword("123");
                adminUser.setEnabled(true);
                adminUser.setAccountNotExpired(true);
                adminUser.setAccountNotLocked(true);
                adminUser.setCredentialNotExpired(true);
                adminUser.setRolesList(Set.of(adminRole));

                userRepository.save(adminUser);
                System.out.println(">>> Usuario inicial 'admin' con rol 'ADMIN' listo.");
            }
        };
    }
}
