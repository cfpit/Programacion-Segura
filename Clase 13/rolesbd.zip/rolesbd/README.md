# RolesBD - Sistema de Autenticación y Autorización Basado en Roles y Permisos (RBAC)

Este proyecto es una aplicación desarrollada con **Spring Boot 3.4.3** y **Java 25**, enfocada en implementar un esquema de **seguridad declarativa y persistente en base de datos** utilizando **Spring Security 6**, **Spring Data JPA** y **MySQL**.

---

## 📑 Tabla de Contenidos

1. [Visión General de la Arquitectura](#visión-general-de-la-arquitectura)
2. [Modelo de Dominio y Base de Datos (RBAC)](#modelo-de-dominio-y-base-de-datos-rbac)
3. [Implementación Detallada de Seguridad](#implementación-detallada-de-seguridad)
   - [Flujo de Autenticación HTTP](#1-flujo-de-autenticación-http)
   - [Configuración de Filtros (SecurityConfig)](#2-configuración-de-filtros-securityconfig)
   - [Carga Dinámica de Credenciales (UserDetailsServiceImp)](#3-carga-dinámica-de-credenciales-userdetailsserviceimp)
   - [Mapeo de Roles y Permisos a GrantedAuthority](#4-mapeo-de-roles-y-permisos-a-grantedauthority)
   - [Protección a Nivel de Métodos (@PreAuthorize)](#5-protección-a-nivel-de-métodos-preauthorize)
   - [Codificación de Contraseñas (PasswordEncoder)](#6-codificación-de-contraseñas-passwordencoder)
4. [Configuración y Requisitos](#configuración-y-requisitos)
5. [Endpoints Disponibles](#endpoints-disponibles)
6. [Flujo Práctico de Inicialización y Prueba](#flujo-práctico-de-inicialización-y-prueba)

---

## 🏗 Visión General de la Arquitectura

La aplicación adopta una arquitectura en capas tradicional:

```mermaid
graph TD
    Client[Cliente / Bruno / Frontend] -->|HTTP Request con Basic Auth| SecurityFilter[SecurityFilterChain]
    SecurityFilter -->|Delega autenticación| AuthManager[AuthenticationManager]
    AuthManager -->|Consulta proveedor| DaoAuthProvider[DaoAuthenticationProvider]
    DaoAuthProvider -->|Invoca carga de usuario| UDS[UserDetailsServiceImp]
    UDS -->|Busca en BD| UserRepo[IUserRepository]
    UserRepo -->|Lee tablas| MySQL[(Base de Datos MySQL)]
    DaoAuthProvider -->|Verifica contraseña| PasswordEncoder[PasswordEncoder]
    SecurityFilter -->|Autorizado| Controller[Controladores REST]
    Controller -->|Lógica| Service[Servicios]
    Service -->|Persistencia| Repositories[Repositorios JPA]
```

---

## 🗄 Modelo de Dominio y Base de Datos (RBAC)

El modelo implementa **Role-Based Access Control (RBAC)** con soporte granular de **permisos individuales**:

```mermaid
erDiagram
    USERS ||--o{ USER_ROLES : has
    ROLES ||--o{ USER_ROLES : assigned_to
    ROLES ||--o{ ROLES_PERMISSIONS : includes
    PERMISSIONS ||--o{ ROLES_PERMISSIONS : assigned_to

    USERS {
        bigint id PK
        varchar username UK
        varchar password
        boolean enabled
        boolean account_not_expired
        boolean account_not_locked
        boolean credential_not_expired
    }

    ROLES {
        bigint id PK
        varchar role
    }

    PERMISSIONS {
        bigint id PK
        varchar permission_name UK
    }
```

### Entidades Clave:

1. **[UserSec](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/ps/Clase%2012/rolesbd/src/main/java/ar/edu/centro8/ps/rolesbd/model/UserSec.java)**:
   - Representa al usuario del sistema.
   - Contiene banderas de estado requeridas por el contrato de Spring Security:
     - `enabled`: usuario habilitado/activo.
     - `accountNotExpired`: cuenta vigente.
     - `accountNotLocked`: cuenta no bloqueada.
     - `credentialNotExpired`: credenciales vigentes.
   - Relación `@ManyToMany(fetch = FetchType.EAGER)` con `Role` unida en la tabla intermedia `user_roles`.

2. **[Role](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/ps/Clase%2012/rolesbd/src/main/java/ar/edu/centro8/ps/rolesbd/model/Role.java)**:
   - Representa una agrupación de privilegios (ej. `ADMIN`, `USER`, `EDITOR`).
   - Relación `@ManyToMany(fetch = FetchType.EAGER)` con `Permission` unida en `roles_permissions`.

3. **[Permission](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/ps/Clase%2012/rolesbd/src/main/java/ar/edu/centro8/ps/rolesbd/model/Permission.java)**:
   - Representa una acción u operación atómica permitida en el sistema (ej. `READ`, `CREATE`, `UPDATE`, `DELETE`).

> [!NOTE]
> Se utiliza `FetchType.EAGER` en las colecciones `Set` para que al momento de autenticar un usuario, JPA cargue en memoria de inmediato toda la jerarquía de roles y sus correspondientes permisos, evitando excepciones de tipo `LazyInitializationException` al evaluar las autoridades fuera de una sesión transaccional.

---

## 🔒 Implementación Detallada de Seguridad

### 1. Flujo de Autenticación HTTP

1. El cliente envía una petición HTTP con el encabezado estándar:
   ```http
   Authorization: Basic base64(username:password)
   ```
2. `BasicAuthenticationFilter` intercepta la petición y extrae las credenciales.
3. El `AuthenticationManager` delega al `DaoAuthenticationProvider`.
4. El proveedor invoca a `UserDetailsServiceImp.loadUserByUsername(username)`.
5. Se consulta la base de datos MySQL mediante [IUserRepository](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/ps/Clase%2012/rolesbd/src/main/java/ar/edu/centro8/ps/rolesbd/repository/IUserRepository.java).
6. Si el usuario existe y las contraseñas coinciden (según el `PasswordEncoder` configurado), se genera un `Authentication` con las autoridades y se almacena en el `SecurityContextHolder`.

---

### 2. Configuración de Filtros (SecurityConfig)

Ubicada en [SecurityConfig.java](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/ps/Clase%2012/rolesbd/src/main/java/ar/edu/centro8/ps/rolesbd/security/config/SecurityConfig.java):

```java
@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
        return httpSecurity
                .csrf(csrf -> csrf.disable())
                .httpBasic(Customizer.withDefaults())
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .build();
    }
    ...
}
```

Aspectos clave:
* **`csrf.disable()`**: Como la API está diseñada como un servicio REST stateless (sin sesiones de navegador por cookie), CSRF no es necesario para clientes HTTP/API.
* **`httpBasic(Customizer.withDefaults())`**: Habilita la autenticación Basic Auth.
* **`sessionCreationPolicy(SessionCreationPolicy.STATELESS)`**: Spring Security no crea ni guarda sesiones HTTP `JSESSIONID`; cada solicitud se autentica independientemente.
* **`@EnableMethodSecurity`**: Habilita el control de accesos declarativo mediante anotaciones como `@PreAuthorize` en controladores y métodos de servicio.

---

### 3. Carga Dinámica de Credenciales (UserDetailsServiceImp)

El servicio [UserDetailsServiceImp.java](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/ps/Clase%2012/rolesbd/src/main/java/ar/edu/centro8/ps/rolesbd/service/UserDetailsServiceImp.java) implementa la interfaz `UserDetailsService` de Spring Security, siendo el puente directo entre la base de datos y el motor de seguridad:

```java
@Override
public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
    UserSec userSec = userRepo.findUserEntityByUsername(username)
            .orElseThrow(() -> new UsernameNotFoundException("El usuario " + username + " no fue encontrado"));

    List<SimpleGrantedAuthority> authorityList = new ArrayList<>();

    // 1. Convertir roles a SimpleGrantedAuthority con prefijo ROLE_
    userSec.getRolesList()
            .forEach(role -> authorityList.add(new SimpleGrantedAuthority("ROLE_".concat(role.getRole()))));

    // 2. Aplanar y convertir permisos individuales
    userSec.getRolesList().stream()
            .flatMap(role -> role.getPermissionsList().stream())
            .forEach(permission -> authorityList.add(new SimpleGrantedAuthority(permission.getPermissionName())));

    // 3. Crear el UserDetails de Spring Security con estados de cuenta
    return new User(
            userSec.getUsername(),
            userSec.getPassword(),
            userSec.isEnabled(),
            userSec.isAccountNotExpired(),
            userSec.isCredentialNotExpired(),
            userSec.isAccountNotLocked(),
            authorityList
    );
}
```

---

### 4. Mapeo de Roles y Permisos a GrantedAuthority

En Spring Security, tanto los roles como los permisos son instancias de `GrantedAuthority`:
* **Roles**: Se prefijan con `ROLE_` (ejemplo: `ROLE_ADMIN`, `ROLE_USER`). Esto permite utilizar expresiones como `hasRole('ADMIN')`.
* **Permisos**: Se agregan con su nombre tal cual (ejemplo: `READ`, `CREATE`, `UPDATE`, `DELETE`). Esto permite utilizar expresiones como `hasAuthority('READ')`.

Un usuario con rol `ADMIN` que a su vez contiene el permiso `READ` tendrá en su lista de autoridades:
```
["ROLE_ADMIN", "READ"]
```

---

### 5. Protección a Nivel de Métodos (@PreAuthorize)

En [HelloWorldController.java](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/ps/Clase%2012/rolesbd/src/main/java/ar/edu/centro8/ps/rolesbd/controller/HelloWorldController.java) se demuestra la seguridad a nivel de método:

```java
@RestController
@PreAuthorize("denyAll()") // Por defecto rechaza cualquier método no autorizado explícitamente
public class HelloWorldController {

    @GetMapping("/holaseg")
    @PreAuthorize("hasAuthority('READ')") // Requiere la autoridad READ
    public String secHelloWorld() {
        return "Hola Mundo con seguridad";
    }

    @GetMapping("/holanoseg")
    @PreAuthorize("permitAll()") // Permite acceso público anónimo
    public String noSecHelloWorld() {
        return "Hola mundo sin seguridad";
    }
}
```

* `@PreAuthorize("denyAll()")` en la clase actúa como política de denegación por defecto (seguridad defensiva).
* `@PreAuthorize("permitAll()")` abre el método anónimamente.
* `@PreAuthorize("hasAuthority('READ')")` verifica si el usuario autenticado posee ese permiso en su conjunto de autoridades.

---

### 6. Codificación de Contraseñas (PasswordEncoder)

En la clase `SecurityConfig` se expone el bean:

```java
@Bean
public PasswordEncoder passwordEncoder() {
    return NoOpPasswordEncoder.getInstance();
}
```

> [!WARNING]
> Actualmente el proyecto utiliza `NoOpPasswordEncoder` para fines académicos y pruebas locales (las contraseñas se almacenan y comparan en texto plano en la BD).
> Para entornos productivos, se debe descomentar `return new BCryptPasswordEncoder();` y asegurar que las contraseñas se guarden hasheadas con BCrypt.

---

## ⚙ Configuración y Requisitos

- **Java**: 25 (OpenJDK / Oracle JDK 25)
- **Maven**: 3.9+
- **MySQL Server**: `localhost:3306`

Archivo `src/main/resources/application.properties`:
```properties
spring.application.name=rolesbd
spring.jpa.hibernate.ddl-auto=update
spring.datasource.url=jdbc:mysql://localhost:3306/security?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=1234
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
```

---

## 📡 Endpoints Disponibles

| Método | Endpoint | Descripción | Requisito de Seguridad |
|---|---|---|---|
| `GET` | `/holanoseg` | Saludo público | Público (`permitAll`) |
| `GET` | `/holaseg` | Saludo protegido | Requiere `hasAuthority('READ')` |
| `GET` | `/api/permissions` | Listar todos los permisos | Autenticado |
| `GET` | `/api/permissions/{id}` | Buscar permiso por ID | Autenticado |
| `POST` | `/api/permissions` | Crear nuevo permiso | Autenticado |
| `GET` | `/api/roles` | Listar todos los roles | Autenticado |
| `GET` | `/api/roles/{id}` | Buscar rol por ID | Autenticado |
| `POST` | `/api/roles` | Crear rol con lista de permisos | Autenticado |
| `GET` | `/api/users` | Listar todos los usuarios | Autenticado |
| `GET` | `/api/users/{id}` | Buscar usuario por ID | Autenticado |
| `POST` | `/api/users` | Crear usuario con roles asignados | Autenticado |

---

## 🚀 Flujo Práctico de Inicialización y Prueba

Para probar el flujo completo con la colección provista en [bruno/](file:///c:/Users/smata/OneDrive/Documentos/Nueva%20carpeta/ps/Clase%2012/rolesbd/bruno):

1. **Crear un Permiso** (`POST /api/permissions`):
   ```json
   {
     "permissionName": "READ"
   }
   ```
   *(Supongamos que devuelve `id: 1`)*

2. **Crear un Rol** (`POST /api/roles`):
   ```json
   {
     "role": "ADMIN",
     "permissionsList": [
       { "id": 1 }
     ]
   }
   ```
   *(Supongamos que devuelve `id: 1`)*

3. **Crear un Usuario** (`POST /api/users`):
   ```json
   {
     "username": "admin",
     "password": "123",
     "enabled": true,
     "accountNotExpired": true,
     "accountNotLocked": true,
     "credentialNotExpired": true,
     "rolesList": [
       { "id": 1 }
     ]
   }
   ```

4. **Verificar Acceso**:
   - Enviar `GET /holanoseg` $\to$ **200 OK** (`Hola mundo sin seguridad`).
   - Enviar `GET /holaseg` con Basic Auth (`admin` / `123`) $\to$ **200 OK** (`Hola Mundo con seguridad`).
   - Enviar `GET /holaseg` sin credenciales o con credenciales incorrectas $\to$ **401 Unauthorized**.
   - Enviar `GET /holaseg` con un usuario que no tenga el permiso `READ` $\to$ **403 Forbidden**.
