# RolesBD - Colección de Pruebas Bruno

Esta carpeta contiene la colección de requests para probar la API REST con el cliente **Bruno**.

## Cómo usar en Bruno:

1. Abrir **Bruno**.
2. Seleccionar **Open Collection** y elegir la carpeta `rolesbd/bruno`.
3. Seleccionar el entorno **Local** en el selector superior derecho (define `baseUrl: http://localhost:8080`, `username: admin`, `password: 123`).
4. Si creas otro usuario o usas otra contraseña, puedes ajustar las variables de entorno en Bruno.

---

## Estructura de Endpoints incluidos:

### 1. `HelloWorld`
- **Hola-No-Seguro** (`GET /holanoseg`): Endpoint público sin autenticación (`permitAll()`).
- **Hola-Seguro** (`GET /holaseg`): Requiere autenticación Basic Auth y permiso `READ`.

### 2. `Permissions` (`/api/permissions`)
- **Get-All-Permissions** (`GET /api/permissions`): Lista todos los permisos guardados.
- **Get-Permission-By-Id** (`GET /api/permissions/1`): Obtiene un permiso por su ID.
- **Create-Permission** (`POST /api/permissions`): Crea un nuevo permiso (ej. `{"permissionName": "READ"}`).

### 3. `Roles` (`/api/roles`)
- **Get-All-Roles** (`GET /api/roles`): Lista todos los roles guardados.
- **Get-Role-By-Id** (`GET /api/roles/1`): Obtiene un rol por su ID.
- **Create-Role** (`POST /api/roles`): Crea un nuevo rol vinculándolo con IDs de permisos existentes (ej. `{"role": "ADMIN", "permissionsList": [{"id": 1}]}`).

### 4. `Users` (`/api/users`)
- **Get-All-Users** (`GET /api/users`): Lista todos los usuarios.
- **Get-User-By-Id** (`GET /api/users/1`): Obtiene un usuario por su ID.
- **Create-User** (`POST /api/users`): Crea un nuevo usuario y le asocia los roles por ID (ej. `{"username": "admin", "password": "123", "enabled": true, ...}`).

---

## Flujo recomendado de prueba:

1. **Crear permisos**: Crear al menos los permisos `READ`, `CREATE`, `UPDATE`, `DELETE`.
2. **Crear rol**: Crear por ejemplo el rol `ADMIN` asociando el ID del permiso creado.
3. **Crear usuario**: Crear un usuario (ej. `admin` con clave `123`) asociando el rol creado.
4. **Probar seguridad**: Ejecutar `GET /holaseg` usando las credenciales del usuario creado para verificar que responde `Hola Mundo con seguridad`.
