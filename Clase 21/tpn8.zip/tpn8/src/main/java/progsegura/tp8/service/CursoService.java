package progsegura.tp8.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import progsegura.tp8.dto.CursoDTO;
import progsegura.tp8.model.Curso;
import progsegura.tp8.model.Estudiante;
import progsegura.tp8.model.Profesor;
import progsegura.tp8.repository.ICursoRepository;
import progsegura.tp8.repository.IEstudianteRepository;
import progsegura.tp8.repository.IProfesorRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CursoService implements ICursoService {

    @Autowired
    private ICursoRepository cursoRepository;

    @Autowired
    private IProfesorRepository profesorRepository;

    @Autowired
    private IEstudianteRepository estudianteRepository;

    @Override
    public List<Curso> findAll() {
        return cursoRepository.findAll();
    }

    @Override
    public Optional<Curso> findById(Long id) {
        return cursoRepository.findById(id);
    }

    @Override
    public Curso save(CursoDTO cursoDTO) {
        Curso curso = new Curso();
        curso.setNombre(cursoDTO.nombre());

        if (cursoDTO.profesorId() != null) {
            Profesor profesor = profesorRepository.findById(cursoDTO.profesorId())
                    .orElseThrow(() -> new RuntimeException("Profesor no encontrado con id: " + cursoDTO.profesorId()));
            curso.setProfesor(profesor);
        }

        if (cursoDTO.estudianteIds() != null && !cursoDTO.estudianteIds().isEmpty()) {
            List<Estudiante> estudiantes = estudianteRepository.findAllById(cursoDTO.estudianteIds());
            curso.setEstudiantes(estudiantes);
        }

        return cursoRepository.save(curso);
    }

    @Override
    public Curso update(Long id, CursoDTO cursoDTO, String currentUsername, boolean isAdmin) {
        Curso curso = cursoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Curso no encontrado con id: " + id));

        // Requerimiento Extra: Los profesores solo pueden editar los cursos donde son profesores
        if (!isAdmin) {
            boolean esProfesorDelCurso = curso.getProfesor() != null &&
                    (curso.getProfesor().getEmail().equalsIgnoreCase(currentUsername) ||
                     curso.getProfesor().getNombre().equalsIgnoreCase(currentUsername));

            if (!esProfesorDelCurso) {
                throw new AccessDeniedException("Acceso denegado: El profesor solo tiene permiso de edición sobre sus propios cursos");
            }
        }

        if (cursoDTO.nombre() != null && !cursoDTO.nombre().isBlank()) {
            curso.setNombre(cursoDTO.nombre());
        }

        // Si es admin, puede reasignar el profesor
        if (isAdmin && cursoDTO.profesorId() != null) {
            Profesor profesor = profesorRepository.findById(cursoDTO.profesorId())
                    .orElseThrow(() -> new RuntimeException("Profesor no encontrado con id: " + cursoDTO.profesorId()));
            curso.setProfesor(profesor);
        }

        // Si se especifican estudiantes
        if (cursoDTO.estudianteIds() != null) {
            List<Estudiante> estudiantes = estudianteRepository.findAllById(cursoDTO.estudianteIds());
            curso.setEstudiantes(estudiantes);
        }

        return cursoRepository.save(curso);
    }

    @Override
    public void deleteById(Long id) {
        cursoRepository.deleteById(id);
    }
}

