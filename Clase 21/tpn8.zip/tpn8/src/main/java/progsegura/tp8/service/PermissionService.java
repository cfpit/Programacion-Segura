package progsegura.tp8.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import progsegura.tp8.model.Permission;
import progsegura.tp8.repository.IPermissionRepository;

import java.util.List;
import java.util.Optional;

@Service
public class PermissionService implements IPermissionService {

    @Autowired
    private IPermissionRepository permissionRepository;

    @Override
    public List<Permission> findAll() {
        return permissionRepository.findAll();
    }

    @Override
    public Optional<Permission> findById(Long id) {
        return permissionRepository.findById(id);
    }

    @Override
    public Permission save(Permission permission) {
        return permissionRepository.save(permission);
    }

    @Override
    public void deleteById(Long id) {
        permissionRepository.deleteById(id);
    }

    @Override
    public Permission update(Long id, Permission permission) {
        return permissionRepository.findById(id).map(existing -> {
            existing.setPermissionName(permission.getPermissionName());
            return permissionRepository.save(existing);
        }).orElseThrow(() -> new RuntimeException("Permiso no encontrado con id: " + id));
    }
}

