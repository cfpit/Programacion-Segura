package progsegura.tp8.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import progsegura.tp8.model.UserSec;
import progsegura.tp8.repository.IUserRepository;

import java.util.List;
import java.util.Optional;

@Service
public class UserService implements IUserService {

    @Autowired
    private IUserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public List<UserSec> findAll() {
        return userRepository.findAll();
    }

    @Override
    public Optional<UserSec> findById(Long id) {
        return userRepository.findById(id);
    }

    @Override
    public UserSec save(UserSec userSec) {
        if (userSec.getPassword() != null && !userSec.getPassword().isEmpty()) {
            userSec.setPassword(encriptPassword(userSec.getPassword()));
        }
        return userRepository.save(userSec);
    }

    @Override
    public void deleteById(Long id) {
        userRepository.deleteById(id);
    }

    @Override
    public UserSec update(Long id, UserSec userSec) {
        return userRepository.findById(id).map(existing -> {
            existing.setUsername(userSec.getUsername());
            if (userSec.getPassword() != null && !userSec.getPassword().isEmpty()
                    && !userSec.getPassword().equals(existing.getPassword())) {
                existing.setPassword(encriptPassword(userSec.getPassword()));
            }
            existing.setEnabled(userSec.isEnabled());
            existing.setAccountNotExpired(userSec.isAccountNotExpired());
            existing.setAccountNotLocked(userSec.isAccountNotLocked());
            existing.setCredentialNotExpired(userSec.isCredentialNotExpired());
            if (userSec.getRolesList() != null && !userSec.getRolesList().isEmpty()) {
                existing.setRolesList(userSec.getRolesList());
            }
            return userRepository.save(existing);
        }).orElseThrow(() -> new RuntimeException("Usuario no encontrado con id: " + id));
    }

    @Override
    public String encriptPassword(String password) {
        return passwordEncoder.encode(password);
    }
}
