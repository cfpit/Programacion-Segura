package progsegura.tp8.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import progsegura.tp8.model.Profesor;

import java.util.Optional;

@Repository
public interface IProfesorRepository extends JpaRepository<Profesor, Long> {
    Optional<Profesor> findByEmail(String email);
}

