package progsegura.tp8;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.password.PasswordEncoder;
import progsegura.tp8.model.*;
import progsegura.tp8.repository.*;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@SpringBootApplication
public class Tp8Application {

	public static void main(String[] args) {
		SpringApplication.run(Tp8Application.class, args);
	}

	@Bean
	public CommandLineRunner initData(
			IUserRepository userRepository,
			IRoleRepository roleRepository,
			IPermissionRepository permissionRepository,
			IProfesorRepository profesorRepository,
			IEstudianteRepository estudianteRepository,
			ICursoRepository cursoRepository,
			PasswordEncoder passwordEncoder) {
		return args -> {
			// 1. Obtener o Crear Permisos de forma idempotente
			Permission pRead = permissionRepository.findByPermissionName("READ")
					.orElseGet(() -> permissionRepository.save(new Permission(null, "READ")));
			Permission pCreate = permissionRepository.findByPermissionName("CREATE")
					.orElseGet(() -> permissionRepository.save(new Permission(null, "CREATE")));
			Permission pUpdate = permissionRepository.findByPermissionName("UPDATE")
					.orElseGet(() -> permissionRepository.save(new Permission(null, "UPDATE")));
			Permission pDelete = permissionRepository.findByPermissionName("DELETE")
					.orElseGet(() -> permissionRepository.save(new Permission(null, "DELETE")));

			// 2. Obtener o Crear Roles
			Role roleAdmin = roleRepository.findByRole("ADMINISTRADOR")
					.orElseGet(() -> roleRepository.save(new Role(null, "ADMINISTRADOR", new HashSet<>(Set.of(pRead, pCreate, pUpdate, pDelete)))));
			Role roleProfesor = roleRepository.findByRole("PROFESOR")
					.orElseGet(() -> roleRepository.save(new Role(null, "PROFESOR", new HashSet<>(Set.of(pRead, pUpdate)))));
			Role roleEstudiante = roleRepository.findByRole("ESTUDIANTE")
					.orElseGet(() -> roleRepository.save(new Role(null, "ESTUDIANTE", new HashSet<>(Set.of(pRead)))));

			// 3. Crear Usuarios si no existen
			if (userRepository.findUserEntityByUsername("admin").isEmpty()) {
				userRepository.save(new UserSec(null, "admin", passwordEncoder.encode("1234"), true, true, true, true, Set.of(roleAdmin)));
			}
			if (userRepository.findUserEntityByUsername("profe.juan").isEmpty()) {
				userRepository.save(new UserSec(null, "profe.juan", passwordEncoder.encode("1234"), true, true, true, true, Set.of(roleProfesor)));
			}
			if (userRepository.findUserEntityByUsername("profe.maria").isEmpty()) {
				userRepository.save(new UserSec(null, "profe.maria", passwordEncoder.encode("1234"), true, true, true, true, Set.of(roleProfesor)));
			}
			if (userRepository.findUserEntityByUsername("alumno.carlos").isEmpty()) {
				userRepository.save(new UserSec(null, "alumno.carlos", passwordEncoder.encode("1234"), true, true, true, true, Set.of(roleEstudiante)));
			}
			if (userRepository.findUserEntityByUsername("alumno.ana").isEmpty()) {
				userRepository.save(new UserSec(null, "alumno.ana", passwordEncoder.encode("1234"), true, true, true, true, Set.of(roleEstudiante)));
			}

			// 4. Crear Profesores
			Profesor profJuan = profesorRepository.findByEmail("profe.juan")
					.orElseGet(() -> profesorRepository.save(new Profesor(null, "Prof. Juan Perez", "profe.juan", new java.util.ArrayList<>())));
			Profesor profMaria = profesorRepository.findByEmail("profe.maria")
					.orElseGet(() -> profesorRepository.save(new Profesor(null, "Prof. Maria Lopez", "profe.maria", new java.util.ArrayList<>())));

			// 5. Crear Estudiantes
			Estudiante estCarlos = estudianteRepository.findByEmail("carlos@universidad.edu")
					.orElseGet(() -> estudianteRepository.save(new Estudiante(null, "Carlos Gomez", "carlos@universidad.edu", new java.util.ArrayList<>())));
			Estudiante estAna = estudianteRepository.findByEmail("ana@universidad.edu")
					.orElseGet(() -> estudianteRepository.save(new Estudiante(null, "Ana Diaz", "ana@universidad.edu", new java.util.ArrayList<>())));
			Estudiante estLucas = estudianteRepository.findByEmail("lucas@universidad.edu")
					.orElseGet(() -> estudianteRepository.save(new Estudiante(null, "Lucas Paz", "lucas@universidad.edu", new java.util.ArrayList<>())));

			// 6. Crear Cursos iniciales si no existen
			if (cursoRepository.count() == 0) {
				Curso cursoProg = new Curso(null, "Programación Segura", profJuan, List.of(estCarlos, estAna));
				Curso cursoBD = new Curso(null, "Bases de Datos", profMaria, List.of(estCarlos, estLucas));
				cursoRepository.saveAll(List.of(cursoProg, cursoBD));
			}
		};
	}
}
