package progsegura.tp8.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import progsegura.tp8.model.Estudiante;
import progsegura.tp8.repository.IEstudianteRepository;

import java.util.List;
import java.util.Optional;

@Service
public class EstudianteService implements IEstudianteService {

    @Autowired
    private IEstudianteRepository estudianteRepository;

    @Override
    public List<Estudiante> findAll() {
        return estudianteRepository.findAll();
    }

    @Override
    public Optional<Estudiante> findById(Long id) {
        return estudianteRepository.findById(id);
    }

    @Override
    public Estudiante save(Estudiante estudiante) {
        return estudianteRepository.save(estudiante);
    }

    @Override
    public void deleteById(Long id) {
        estudianteRepository.deleteById(id);
    }

    @Override
    public Estudiante update(Long id, Estudiante estudiante) {
        return estudianteRepository.findById(id).map(existing -> {
            existing.setNombre(estudiante.getNombre());
            existing.setEmail(estudiante.getEmail());
            return estudianteRepository.save(existing);
        }).orElseThrow(() -> new RuntimeException("Estudiante no encontrado con id: " + id));
    }
}

