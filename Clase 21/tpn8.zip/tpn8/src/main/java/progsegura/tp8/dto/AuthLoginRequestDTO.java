package progsegura.tp8.dto;

import jakarta.validation.constraints.NotBlank;

public record AuthLoginRequestDTO(
        @NotBlank(message = "El nombre de usuario no puede estar vacio")
        String username,
        @NotBlank(message = "La contraseña no puede estar vacia")
        String password
) {
}

