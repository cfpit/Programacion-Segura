package progsegura.tp8.service;

import progsegura.tp8.model.UserSec;

import java.util.List;
import java.util.Optional;

public interface IUserService {
    List<UserSec> findAll();
    Optional<UserSec> findById(Long id);
    UserSec save(UserSec userSec);
    void deleteById(Long id);
    UserSec update(Long id, UserSec userSec);
    String encriptPassword(String password);
}

