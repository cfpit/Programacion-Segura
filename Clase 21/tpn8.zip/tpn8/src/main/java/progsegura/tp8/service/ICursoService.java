package progsegura.tp8.service;

import progsegura.tp8.dto.CursoDTO;
import progsegura.tp8.model.Curso;

import java.util.List;
import java.util.Optional;

public interface ICursoService {
    List<Curso> findAll();

    Optional<Curso> findById(Long id);

    Curso save(CursoDTO cursoDTO);

    Curso update(Long id, CursoDTO cursoDTO, String currentUsername, boolean isAdmin);

    void deleteById(Long id);
}
