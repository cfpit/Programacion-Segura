package progsegura.tp8.service;

import progsegura.tp8.model.Profesor;

import java.util.List;
import java.util.Optional;

public interface IProfesorService {
    List<Profesor> findAll();
    Optional<Profesor> findById(Long id);
    Profesor save(Profesor profesor);
    void deleteById(Long id);
    Profesor update(Long id, Profesor profesor);
}

