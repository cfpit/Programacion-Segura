package progsegura.tp8.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import progsegura.tp8.model.Curso;

import java.util.List;

@Repository
public interface ICursoRepository extends JpaRepository<Curso, Long> {
    List<Curso> findByProfesorId(Long profesorId);
}

