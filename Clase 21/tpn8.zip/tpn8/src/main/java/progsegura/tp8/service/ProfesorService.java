package progsegura.tp8.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import progsegura.tp8.model.Profesor;
import progsegura.tp8.repository.IProfesorRepository;

import java.util.List;
import java.util.Optional;

@Service
public class ProfesorService implements IProfesorService {

    @Autowired
    private IProfesorRepository profesorRepository;

    @Override
    public List<Profesor> findAll() {
        return profesorRepository.findAll();
    }

    @Override
    public Optional<Profesor> findById(Long id) {
        return profesorRepository.findById(id);
    }

    @Override
    public Profesor save(Profesor profesor) {
        return profesorRepository.save(profesor);
    }

    @Override
    public void deleteById(Long id) {
        profesorRepository.deleteById(id);
    }

    @Override
    public Profesor update(Long id, Profesor profesor) {
        return profesorRepository.findById(id).map(existing -> {
            existing.setNombre(profesor.getNombre());
            existing.setEmail(profesor.getEmail());
            return profesorRepository.save(existing);
        }).orElseThrow(() -> new RuntimeException("Profesor no encontrado con id: " + id));
    }
}

