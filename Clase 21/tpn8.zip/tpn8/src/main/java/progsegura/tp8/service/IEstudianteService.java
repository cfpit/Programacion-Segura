package progsegura.tp8.service;

import progsegura.tp8.model.Estudiante;

import java.util.List;
import java.util.Optional;

public interface IEstudianteService {
    List<Estudiante> findAll();
    Optional<Estudiante> findById(Long id);
    Estudiante save(Estudiante estudiante);
    void deleteById(Long id);
    Estudiante update(Long id, Estudiante estudiante);
}

