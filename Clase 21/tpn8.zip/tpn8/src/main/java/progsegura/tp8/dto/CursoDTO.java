package progsegura.tp8.dto;

import java.util.List;

public record CursoDTO(
        Long id,
        String nombre,
        Long profesorId,
        List<Long> estudianteIds
) {
}

