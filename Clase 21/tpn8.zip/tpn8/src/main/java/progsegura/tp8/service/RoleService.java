package progsegura.tp8.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import progsegura.tp8.model.Role;
import progsegura.tp8.repository.IRoleRepository;

import java.util.List;
import java.util.Optional;

@Service
public class RoleService implements IRoleService {

    @Autowired
    private IRoleRepository roleRepository;

    @Override
    public List<Role> findAll() {
        return roleRepository.findAll();
    }

    @Override
    public Optional<Role> findById(Long id) {
        return roleRepository.findById(id);
    }

    @Override
    public Role save(Role role) {
        return roleRepository.save(role);
    }

    @Override
    public void deleteById(Long id) {
        roleRepository.deleteById(id);
    }

    @Override
    public Role update(Long id, Role role) {
        return roleRepository.findById(id).map(existing -> {
            existing.setRole(role.getRole());
            if (role.getPermissionsList() != null) {
                existing.setPermissionsList(role.getPermissionsList());
            }
            return roleRepository.save(existing);
        }).orElseThrow(() -> new RuntimeException("Rol no encontrado con id: " + id));
    }
}

