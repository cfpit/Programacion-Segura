package progsegura.tp8;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class Tp8ApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	private final ObjectMapper mapper = new ObjectMapper();

	private String tokenAdmin;
	private String tokenProfeJuan;
	private String tokenProfeMaria;
	private String tokenAlumno;

	@BeforeEach
	void setUp() throws Exception {
		tokenAdmin = obtainToken("admin", "1234");
		tokenProfeJuan = obtainToken("profe.juan", "1234");
		tokenProfeMaria = obtainToken("profe.maria", "1234");
		tokenAlumno = obtainToken("alumno.carlos", "1234");
	}

	private String obtainToken(String username, String password) throws Exception {
		String body = String.format("{\"username\":\"%s\",\"password\":\"%s\"}", username, password);
		MvcResult result = mockMvc.perform(post("/auth/login")
						.contentType(MediaType.APPLICATION_JSON)
						.content(body))
				.andExpect(status().isOk())
				.andReturn();
		JsonNode node = mapper.readTree(result.getResponse().getContentAsString());
		return node.get("jwt").asText();
	}

	@Test
	void testAutenticacionFallida() throws Exception {
		// Contraseña incorrecta -> 401
		mockMvc.perform(post("/auth/login")
						.contentType(MediaType.APPLICATION_JSON)
						.content("{\"username\":\"admin\",\"password\":\"wrong\"}"))
				.andExpect(status().isUnauthorized());
	}

	@Test
	void testPermisosEstudiante() throws Exception {
		// Estudiante puede leer cursos -> 200 OK
		mockMvc.perform(get("/api/cursos")
						.header("Authorization", "Bearer " + tokenAlumno))
				.andExpect(status().isOk());

		// Estudiante puede leer estudiantes -> 200 OK
		mockMvc.perform(get("/api/estudiantes")
						.header("Authorization", "Bearer " + tokenAlumno))
				.andExpect(status().isOk());

		// Estudiante NO puede leer profesores -> 403 Forbidden
		mockMvc.perform(get("/api/profesores")
						.header("Authorization", "Bearer " + tokenAlumno))
				.andExpect(status().isForbidden());

		// Estudiante NO puede crear cursos -> 403 Forbidden
		mockMvc.perform(post("/api/cursos")
						.header("Authorization", "Bearer " + tokenAlumno)
						.contentType(MediaType.APPLICATION_JSON)
						.content("{\"nombre\":\"Hack Course\"}"))
				.andExpect(status().isForbidden());

		// Estudiante NO puede crear usuarios -> 403 Forbidden
		mockMvc.perform(post("/api/users")
						.header("Authorization", "Bearer " + tokenAlumno)
						.contentType(MediaType.APPLICATION_JSON)
						.content("{\"username\":\"nuevo\"}"))
				.andExpect(status().isForbidden());
	}

	@Test
	void testPermisosProfesor() throws Exception {
		// Profesor puede leer cursos, profesores y estudiantes -> 200 OK
		mockMvc.perform(get("/api/cursos")
						.header("Authorization", "Bearer " + tokenProfeJuan))
				.andExpect(status().isOk());

		mockMvc.perform(get("/api/profesores")
						.header("Authorization", "Bearer " + tokenProfeJuan))
				.andExpect(status().isOk());

		mockMvc.perform(get("/api/estudiantes")
						.header("Authorization", "Bearer " + tokenProfeJuan))
				.andExpect(status().isOk());

		// Profesor NO puede crear profesores -> 403 Forbidden
		mockMvc.perform(post("/api/profesores")
						.header("Authorization", "Bearer " + tokenProfeJuan)
						.contentType(MediaType.APPLICATION_JSON)
						.content("{\"nombre\":\"Prof. Falso\",\"email\":\"falso@u.edu\"}"))
				.andExpect(status().isForbidden());
	}

	@Test
	void testEdicionCursoProfesorPropioVsAjeno() throws Exception {
		// Curso 1 es dictado por Juan ("profe.juan")
		// Profe Juan EDITA su propio curso -> 200 OK
		mockMvc.perform(put("/api/cursos/1")
						.header("Authorization", "Bearer " + tokenProfeJuan)
						.contentType(MediaType.APPLICATION_JSON)
						.content("{\"nombre\":\"Programación Segura y Avanzada\"}"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.nombre").value("Programación Segura y Avanzada"));

		// Profe Maria intenta editar el curso 1 de Juan -> 403 Forbidden
		mockMvc.perform(put("/api/cursos/1")
						.header("Authorization", "Bearer " + tokenProfeMaria)
						.contentType(MediaType.APPLICATION_JSON)
						.content("{\"nombre\":\"Intento de Edición No Autorizada\"}"))
				.andExpect(status().isForbidden());

		// Admin puede editar cualquier curso -> 200 OK
		mockMvc.perform(put("/api/cursos/1")
						.header("Authorization", "Bearer " + tokenAdmin)
						.contentType(MediaType.APPLICATION_JSON)
						.content("{\"nombre\":\"Programación Segura (Oficial)\"}"))
				.andExpect(status().isOk());
	}

	@Test
	void testPermisosAdministradorTotal() throws Exception {
		// Admin puede crear un nuevo estudiante -> 201 Created
		String uniqueEmail = "nuevo_" + System.currentTimeMillis() + "@u.edu";
		mockMvc.perform(post("/api/estudiantes")
						.header("Authorization", "Bearer " + tokenAdmin)
						.contentType(MediaType.APPLICATION_JSON)
						.content("{\"nombre\":\"Nuevo Alumno\",\"email\":\"" + uniqueEmail + "\"}"))
				.andExpect(status().isCreated());

		// Admin puede gestionar usuarios -> 200 OK
		mockMvc.perform(get("/api/users")
						.header("Authorization", "Bearer " + tokenAdmin))
				.andExpect(status().isOk());
	}

	@Test
	void testPeticionSinToken() throws Exception {
		mockMvc.perform(get("/api/cursos"))
				.andExpect(status().isUnauthorized());
	}
}
