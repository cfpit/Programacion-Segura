# TP8 - Autenticación JWT y Plataforma Educativa

Proyecto desarrollado con **Spring Boot 3.5.0**, **Spring Security 6**, **JPA / Hibernate** y **JWT (JSON Web Tokens)** que implementa el sistema de gestión de usuarios y plataforma educativa universitaria correspondiente al **Trabajo Práctico Nro. 8**.

---

## 📌 Resumen de los Requerimientos Implementados

### Ejercicio Nº 1: Gestión de Usuarios y Seguridad JWT
1. **Modelo de Seguridad RBAC**: Entidades `UserSec`, `Role` y `Permission`. Roles definidos: `ADMINISTRADOR`, `PROFESOR` y `ESTUDIANTE`.
2. **Seguridad Stateless con JWT**:
   - Algoritmo de firma `HMAC256` con clave secreta y emisor `UNIVERSIDAD-SEC`.
   - Vencimiento de tokens a los 30 minutos.
   - Claims incluidos: `sub` (username), `authorities` (roles y permisos), `iat`, `exp`, `nbf`, `jti`.
3. **Endpoint de Autenticación**: `POST /auth/login` de acceso público para emitir JWTs.
4. **Protección de Endpoints**:
   - **SOLO los usuarios con rol `ADMINISTRADOR` pueden crear o editar usuarios, roles y permisos** (`/api/users/**`, `/api/roles/**`, `/api/permissions/**`).

### Ejercicio Nº 2: Incremento a la Plataforma Educativa
1. **Modelado de Dominio (atributos mínimos y relaciones exactas)**:
   - **Profesor**: `id`, `nombre`, `email`. Relación `@OneToMany` hacia `Curso` (*un profesor puede dictar varios cursos*).
   - **Estudiante**: `id`, `nombre`, `email`. Relación `@ManyToMany` hacia `Curso` (*un alumno puede tener uno o varios cursos asignados*).
   - **Curso**: `id`, `nombre`. Relación `@ManyToOne` con `Profesor` (*un curso tiene un único profesor asignado*) y `@ManyToMany` con `Estudiante` (*un curso tiene una lista de alumnos*).
2. **Matriz de Permisos y Control de Acceso**:
   - **Administradores**: Acceso CRUD total sobre todas las entidades (`users`, `roles`, `permissions`, `cursos`, `estudiantes`, `profesores`).
   - **Estudiantes**: Únicamente pueden consultar/leer los cursos y estudiantes disponibles.
   - **Profesores**: Pueden consultar cursos, profesores y estudiantes.
   - **Requerimiento Extra (Opcional)**: Los profesores tienen permiso de **EDICIÓN** (`PUT /api/cursos/{id}`) **exclusivamente sobre los cursos donde ellos son los profesores asignados**. Si intentan editar un curso ajeno, el sistema deniega el acceso con `403 Forbidden`.

---

## 🗄️ Modelo de Datos y Relaciones

```
  ┌───────────────┐                  ┌───────────────┐
  │   UserSec     │◄───(N)────(M)───►│     Role      │
  └───────────────┘                  └───────────────┘
                                             │
                                           (N)
                                             │
                                           (M)
                                             ▼
                                     ┌───────────────┐
                                     │  Permission   │
                                     └───────────────┘

  ┌───────────────┐ 1              N ┌───────────────┐
  │   Profesor    │─────────────────►│     Curso     │
  └───────────────┘                  └───────────────┘
                                             │
                                           (N)
                                             │
                                           (M)
                                             ▼
                                     ┌───────────────┐
                                     │  Estudiante   │
                                     └───────────────┘
```

### 💡 Separación Arquitectónica: Módulo de Seguridad vs. Dominio Académico

En el diseño y en la base de datos relacional generada se aprecian **dos módulos completamente desacoplados** sin claves foráneas físicas (`FOREIGN KEY`) entre la tabla `users` y las tablas de negocio (`profesores`, `estudiantes`, `cursos`):

1. **Separación de Responsabilidades (*Security* vs. *Domain*)**:
   - **Módulo de Seguridad (`users`, `user_roles`, `roles`, `roles_permissions`, `permissions`)**: Se encarga exclusivamente de la autenticación y autorización (quién accede, validación de contraseñas con BCrypt, emisión/verificación de tokens JWT y control de acceso RBAC a endpoints).
   - **Módulo de Dominio Académico (`profesores`, `cursos`, `estudiantes`, `curso_estudiantes`)**: Modela el negocio educativo estipulado en la consigna (cursos dictados por profesores y estudiantes inscriptos).

2. **Vinculación Lógica a Nivel de Aplicación**:
   - En lugar de forzar un acoplamiento rígido con relaciones `@OneToOne` en la base de datos, la asociación entre el usuario autenticado y su perfil de dominio se resuelve **lógicamente mediante el `username` / `email`**:
     - El usuario se autentica con `username = "profe.juan"`.
     - Su entidad correspondiente en el dominio posee `email = "profe.juan"`.
   - En la capa de servicios (`CursoService.java`), el sistema valida los permisos específicos de negocio comparando el `username` del token JWT con el profesor asignado al curso:
     ```java
     boolean esProfesorDelCurso = curso.getProfesor() != null &&
             (curso.getProfesor().getEmail().equalsIgnoreCase(currentUsername) ||
              curso.getProfesor().getNombre().equalsIgnoreCase(currentUsername));
     ```
   - Este enfoque mantiene desacoplado el motor de seguridad de las entidades de negocio, permitiendo que la seguridad sea independiente, limpia y extensible.

---

## 🔒 Matriz de Control de Acceso por Endpoint

| Endpoint | Método | Regla de Autorización | Acceso Permitido |
| :--- | :---: | :--- | :--- |
| `/auth/login` | `POST` | `permitAll()` | Público (Sin token) |
| `/api/users/**` | `GET, POST, PUT, DELETE` | `hasRole('ADMINISTRADOR')` | Solo Administradores |
| `/api/roles/**` | `GET, POST, PUT, DELETE` | `hasRole('ADMINISTRADOR')` | Solo Administradores |
| `/api/permissions/**` | `GET, POST, PUT, DELETE` | `hasRole('ADMINISTRADOR')` | Solo Administradores |
| `/api/estudiantes` | `GET` | `hasAnyRole('ADMINISTRADOR', 'PROFESOR', 'ESTUDIANTE')` | Administrador, Profesor y Estudiante |
| `/api/estudiantes/{id}` | `GET` | `hasAnyRole('ADMINISTRADOR', 'PROFESOR', 'ESTUDIANTE')` | Administrador, Profesor y Estudiante |
| `/api/estudiantes/**` | `POST, PUT, DELETE` | `hasRole('ADMINISTRADOR')` | Solo Administradores |
| `/api/profesores` | `GET` | `hasAnyRole('ADMINISTRADOR', 'PROFESOR')` | Administrador y Profesor (Estudiante **NO**) |
| `/api/profesores/{id}` | `GET` | `hasAnyRole('ADMINISTRADOR', 'PROFESOR')` | Administrador y Profesor (Estudiante **NO**) |
| `/api/profesores/**` | `POST, PUT, DELETE` | `hasRole('ADMINISTRADOR')` | Solo Administradores |
| `/api/cursos` | `GET` | `hasAnyRole('ADMINISTRADOR', 'PROFESOR', 'ESTUDIANTE')` | Administrador, Profesor y Estudiante |
| `/api/cursos/{id}` | `GET` | `hasAnyRole('ADMINISTRADOR', 'PROFESOR', 'ESTUDIANTE')` | Administrador, Profesor y Estudiante |
| `/api/cursos` | `POST` | `hasRole('ADMINISTRADOR')` | Solo Administradores |
| `/api/cursos/{id}` | `PUT` | `hasAnyRole('ADMINISTRADOR', 'PROFESOR')` | Admin o **Profesor titular del curso** |
| `/api/cursos/{id}` | `DELETE` | `hasRole('ADMINISTRADOR')` | Solo Administradores |

---

## 👥 Usuarios Precargados para Pruebas (`initData`)

Al iniciar el proyecto, se cargan automáticamente en la base de datos MySQL (`tp8_plataforma`) con contraseñas cifradas con BCrypt y salts individuales:

| Usuario | Contraseña | Rol Asignado | Permisos Principales |
| :--- | :---: | :--- | :--- |
| `admin` | `1234` | `ADMINISTRADOR` | Control total sobre todas las entidades |
| `profe.juan` | `1234` | `PROFESOR` | Consulta cursos/estudiantes/profesores; edita su curso 1 |
| `profe.maria` | `1234` | `PROFESOR` | Consulta cursos/estudiantes/profesores; edita su curso 2 |
| `alumno.carlos` | `1234` | `ESTUDIANTE` | Consulta cursos y estudiantes disponibles |
| `alumno.ana` | `1234` | `ESTUDIANTE` | Consulta cursos y estudiantes disponibles |

### Cursos precargados:
* **Curso 1**: `"Programación Segura"` - Profesor asignado: `Prof. Juan Perez` (`profe.juan`).
* **Curso 2**: `"Bases de Datos"` - Profesora asignada: `Prof. Maria Lopez` (`profe.maria`).

---

## 🚀 Cómo Ejecutar el Proyecto

1. **Requisitos previos**:
   - Java 21 LTS instalado.
   - MySQL Server corriendo en el puerto `3306` con usuario `root` y contraseña `1234`. La base de datos `tp8_plataforma` se crea automáticamente.

2. **Compilar y Correr la Aplicación**:
   ```bash
   cd tpn8
   ./mvnw spring-boot:run
   ```

3. **Ejecutar la Suite de Pruebas Automatizadas**:
   ```bash
   ./mvnw test
   ```
   *(Incluye 6 pruebas de integración que verifican login, permisos de cada rol, restricción de edición de cursos y peticiones no autorizadas).*

---

## 🧪 Pruebas con Bruno API Client

La colección de Bruno se encuentra en la carpeta `tpn8/bruno` y está configurada utilizando **directamente `http://localhost:8080`** en cada petición (sin depender de `baseUrl`).

### Estructura de la Colección:

```text
tpn8/bruno/
├── 01-Autenticacion (Login)/
│   ├── 01-Login ADMIN (Obtener Token).bru               # Guarda {{token_admin}}
│   ├── 02-Login PROFESOR - Juan (Obtener Token).bru     # Guarda {{token_profesor}}
│   ├── 03-Login ESTUDIANTE - Carlos (Obtener Token).bru # Guarda {{token_estudiante}}
│   └── 04-Login Fallido - Password Incorrecta.bru       # Retorna 401 Unauthorized
├── 02-Gestion Usuarios (Ejercicio 1)/
│   ├── 01-Listar Usuarios - Token ADMIN (200 OK).bru
│   ├── 02-Listar Usuarios - Token ESTUDIANTE (403 Forbidden).bru
│   ├── 03-Crear Usuario - Token ADMIN (201 Created).bru
│   ├── 04-Crear Usuario - Token PROFESOR (403 Forbidden).bru
│   ├── 05-Listar Roles - Token ADMIN (200 OK).bru
│   └── 06-Listar Permisos - Token ADMIN (200 OK).bru
├── 03-Cursos (Ejercicio 2)/
│   ├── 01-Listar Cursos - Token ESTUDIANTE (200 OK).bru
│   ├── 02-Listar Cursos - Token PROFESOR (200 OK).bru
│   ├── 03-Crear Curso - Token ADMIN (201 Created).bru
│   ├── 04-Crear Curso - Token ESTUDIANTE (403 Forbidden).bru
│   ├── 05-Editar Curso Propio - Token PROFESOR Juan (200 OK).bru
│   ├── 06-Editar Curso Ajeno - Token PROFESOR Juan (403 Forbidden).bru
│   ├── 07-Eliminar Curso - Token PROFESOR (403 Forbidden).bru
│   └── 08-Eliminar Curso - Token ADMIN (204 No Content).bru
├── 04-Estudiantes (Ejercicio 2)/
│   ├── 01-Listar Estudiantes - Token ESTUDIANTE (200 OK).bru
│   ├── 02-Listar Estudiantes - Token PROFESOR (200 OK).bru
│   ├── 03-Crear Estudiante - Token ADMIN (201 Created).bru
│   └── 04-Crear Estudiante - Token ESTUDIANTE (403 Forbidden).bru
├── 05-Profesores (Ejercicio 2)/
│   ├── 01-Listar Profesores - Token PROFESOR (200 OK).bru
│   ├── 02-Listar Profesores - Token ESTUDIANTE (403 Forbidden).bru
│   ├── 03-Crear Profesor - Token ADMIN (201 Created).bru
│   └── 04-Crear Profesor - Token PROFESOR (403 Forbidden).bru
└── 06-Pruebas Generales de Seguridad/
    ├── 01-Acceso Sin Token (401 Unauthorized).bru
    └── 02-Acceso Con Token Invalido (401 Unauthorized).bru
```

### Guía para Probar en Bruno:
1. Abre **Bruno** y selecciona **Open Collection** -> Selecciona la carpeta `tpn8/bruno`.
2. En el menú de entornos, selecciona el entorno **Local**.
3. Ejecuta primero las peticiones de `01-Autenticacion (Login)` para guardar automáticamente en el entorno:
   - `{{token_admin}}`
   - `{{token_profesor}}`
   - `{{token_estudiante}}`
4. Ejecuta las demás carpetas: verás cómo las operaciones autorizadas responden con **200 OK** o **201 Created**, y las no autorizadas responden limpiamente con **403 Forbidden** o **401 Unauthorized** en JSON.

