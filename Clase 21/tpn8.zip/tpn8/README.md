# TP8 - Autenticación JWT y Plataforma Educativa

Proyecto desarrollado con **Spring Boot 3.5.0**, **Spring Security 6**, **JPA / Hibernate** y **JWT (JSON Web Tokens)** que implementa el sistema de gestión de usuarios y plataforma educativa universitaria correspondiente al **Trabajo Práctico Nro. 8**.

---

## 📌 Resumen de los Requerimientos Implementados

### Ejercicio Nº 1: Gestión de Usuarios y Seguridad JWT

1. **Modelo de Seguridad RBAC**: Entidades `UserSec`, `Role` y `Permission`. Roles definidos: `ADMINISTRADOR`, `PROFESOR` y `ESTUDIANTE`.
2. **Seguridad Stateless con JWT**:
   - Algoritmo de firma `HMAC256` con clave secreta y emisor `UNIVERSIDAD-SEC`.
   - Vencimiento de tokens a los 30 minutos.
   - Claims incluidos: `sub` (username), `authorities` (roles y permisos), `iat`, `exp`, `nbf`, `jti`.
3. **Endpoint de Autenticación**: `POST /auth/login` de acceso público para emitir JWTs.
4. **Protección de Endpoints**:
   - **SOLO los usuarios con rol `ADMINISTRADOR` pueden crear o editar usuarios, roles y permisos** (`/api/users/**`, `/api/roles/**`, `/api/permissions/**`).

### Ejercicio Nº 2: Incremento a la Plataforma Educativa

1. **Modelado de Dominio (atributos mínimos y relaciones exactas)**:
   - **Profesor**: `id`, `nombre`, `email`. Relación `@OneToMany` hacia `Curso` (_un profesor puede dictar varios cursos_).
   - **Estudiante**: `id`, `nombre`, `email`. Relación `@ManyToMany` hacia `Curso` (_un alumno puede tener uno o varios cursos asignados_).
   - **Curso**: `id`, `nombre`. Relación `@ManyToOne` con `Profesor` (_un curso tiene un único profesor asignado_) y `@ManyToMany` con `Estudiante` (_un curso tiene una lista de alumnos_).
2. **Matriz de Permisos y Control de Acceso**:
   - **Administradores**: Acceso CRUD total sobre todas las entidades (`users`, `roles`, `permissions`, `cursos`, `estudiantes`, `profesores`).
   - **Estudiantes**: Únicamente pueden consultar/leer los cursos y estudiantes disponibles.
   - **Profesores**: Pueden consultar cursos, profesores y estudiantes.
   - **Requerimiento Extra (Opcional)**: Los profesores tienen permiso de **EDICIÓN** (`PUT /api/cursos/{id}`) **exclusivamente sobre los cursos donde ellos son los profesores asignados**. Si intentan editar un curso ajeno, el sistema deniega el acceso con `403 Forbidden`.

---

## 🗄️ Modelo de Datos y Relaciones

```
  ┌───────────────┐                  ┌───────────────┐
  │   UserSec     │◄───(N)────(M)───►│     Role      │
  └───────────────┘                  └───────────────┘
                                             │
                                           (N)
                                             │
                                           (M)
                                             ▼
                                     ┌───────────────┐
                                     │  Permission   │
                                     └───────────────┘

  ┌───────────────┐ 1              N ┌───────────────┐
  │   Profesor    │─────────────────►│     Curso     │
  └───────────────┘                  └───────────────┘
                                             │
                                           (N)
                                             │
                                           (M)
                                             ▼
                                     ┌───────────────┐
                                     │  Estudiante   │
                                     └───────────────┘
```

### 💡 Separación Arquitectónica: Módulo de Seguridad vs. Dominio Académico

En el diseño y en la base de datos relacional generada se aprecian **dos módulos completamente desacoplados** sin claves foráneas físicas (`FOREIGN KEY`) entre la tabla `users` y las tablas de negocio (`profesores`, `estudiantes`, `cursos`):

1. **Separación de Responsabilidades (_Security_ vs. _Domain_)**:
   - **Módulo de Seguridad (`users`, `user_roles`, `roles`, `roles_permissions`, `permissions`)**: Se encarga exclusivamente de la autenticación y autorización (quién accede, validación de contraseñas con BCrypt, emisión/verificación de tokens JWT y control de acceso RBAC a endpoints).
   - **Módulo de Dominio Académico (`profesores`, `cursos`, `estudiantes`, `curso_estudiantes`)**: Modela el negocio educativo estipulado en la consigna (cursos dictados por profesores y estudiantes inscriptos).

2. **Vinculación Lógica a Nivel de Aplicación**:
   - En lugar de forzar un acoplamiento rígido con relaciones `@OneToOne` en la base de datos, la asociación entre el usuario autenticado y su perfil de dominio se resuelve **lógicamente mediante el `username` / `email`**:
     - El usuario se autentica con `username = "profe.juan"`.
     - Su entidad correspondiente en el dominio posee `email = "profe.juan"`.
   - En la capa de servicios (`CursoService.java`), el sistema valida los permisos específicos de negocio comparando el `username` del token JWT con el profesor asignado al curso:
     ```java
     boolean esProfesorDelCurso = curso.getProfesor() != null &&
             (curso.getProfesor().getEmail().equalsIgnoreCase(currentUsername) ||
              curso.getProfesor().getNombre().equalsIgnoreCase(currentUsername));
     ```
   - Este enfoque mantiene desacoplado el motor de seguridad de las entidades de negocio, permitiendo que la seguridad sea independiente, limpia y extensible.

---

## 🛡️ Arquitectura y Componentes Clave de Seguridad JWT

El sistema de autenticación y autorización se apoya en tres componentes fundamentales que interactúan armónicamente dentro del ciclo de vida de cada petición HTTP en Spring Security:

```
[ Petición HTTP ]
       │
       ▼  (Header Authorization: "Bearer <token>")
┌────────────────────────────────────────────────────────┐
│ 1. JwtTokenValidator (Filtro OncePerRequestFilter)      │
│    - Intercepta la petición HTTP                       │
│    - Extrae el token descartando prefijo "Bearer "     │
│    - Delega la verificación criptográfica               │
└───────────────────────┬────────────────────────────────┘
                        │
                        ▼ (Llama a validateToken)
┌────────────────────────────────────────────────────────┐
│ 2. JwtUtils (Componente Criptográfico)                 │
│    - Verifica firma HMAC256 con secretKey              │
│    - Verifica caducidad (exp), emisor (iss) y nbf      │
│    - Retorna DecodedJWT                                │
└───────────────────────┬────────────────────────────────┘
                        │
                        ▼ (Retorna claims)
┌────────────────────────────────────────────────────────┐
│ 1. JwtTokenValidator (Continuación)                    │
│    - Extrae username y authorities (roles/permisos)    │
│    - Crea UsernamePasswordAuthenticationToken          │
│    - Establece el contexto en SecurityContextHolder    │
└───────────────────────┬────────────────────────────────┘
                        │
                        ▼
┌────────────────────────────────────────────────────────┐
│ 3. SecurityConfig (Cadena de Seguridad & Filtros)      │
│    - Control de rutas (permitAll / authenticated)      │
│    - Stateless Session Policy (sin sesiones HTTP)      │
│    - Manejo de excepciones JSON (401 y 403)            │
│    - Evaluación de @PreAuthorize en Controllers        │
└────────────────────────────────────────────────────────┘
```

---

### 1. `SecurityConfig.java`

#### ¿Para qué sirve?

Es la **clase central de configuración de seguridad** de la aplicación basada en **Spring Security 6**. Su propósito es orquestar la política de defensa del sistema: define qué rutas son públicas y cuáles privadas, desactiva la gestión de estado de sesiones (forzando una arquitectura _Stateless_ basada en tokens), registra los filtros personalizados en el orden adecuado, estandariza las respuestas de error 401 y 403 en formato JSON, y expone los beans de infraestructura necesarios para la autenticación (como `AuthenticationManager`, `DaoAuthenticationProvider` y `BCryptPasswordEncoder`).

#### Explicación detallada de su código:

```java
@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true)
public class SecurityConfig { ... }
```

- **Anotaciones de clase**:
  - `@Configuration`: Indica a Spring que esta clase declara métodos `@Bean` que configuran el contenedor de dependencias.
  - `@EnableWebSecurity`: Activa el soporte de seguridad web de Spring Security en la aplicación.
  - `@EnableMethodSecurity(prePostEnabled = true)`: Habilita el control de acceso a nivel de método mediante anotaciones como `@PreAuthorize("hasRole('ADMINISTRADOR')")` o `@PreAuthorize("hasAnyRole(...)")` en servicios y controladores.

- **Inyección de `JwtUtils`**:

  ```java
  @Autowired
  private JwtUtils jwtUtils;
  ```

  Permite pasar la instancia utilitaria de JWT al filtro `JwtTokenValidator` cuando se instancia manualmente en la cadena de filtros.

- **Método `securityFilterChain(HttpSecurity httpSecurity)`**:
  Define la cadena de filtros HTTP (`SecurityFilterChain`) que evaluará cada petición:
  1. `csrf(csrf -> csrf.disable())`: Deshabilita la protección CSRF (Cross-Site Request Forgery) porque la API es REST y no utiliza cookies de sesión en navegadores; los tokens JWT viajan en encabezados HTTP, lo que elimina intrínsecamente la vulnerabilidad CSRF.
  2. `httpBasic(httpBasic -> httpBasic.disable())`: Desactiva la autenticación básica HTTP tradicional (emergente del navegador).
  3. `sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))`: Establece la política de sesiones como **STATELESS** (sin estado). Spring Security no creará ni consultará objetos `HttpSession` en el servidor; cada petición debe ser autónoma y autenticarse con su propio token.
  4. `authorizeHttpRequests(...)`:
     - `.dispatcherTypeMatchers(DispatcherType.ERROR).permitAll()`: Permite el despacho interno hacia el controlador de errores sin requerir autenticación previa, asegurando que ante una excepción no se produzca un bucle de redirección.
     - `.requestMatchers("/auth/login", "/error").permitAll()`: Permite el acceso público irrestricto al endpoint de autenticación para obtener el token (`/auth/login`) y a la ruta por defecto de errores (`/error`).
     - `.anyRequest().authenticated()`: Cualquier otra URL del sistema exige que el usuario esté debidamente autenticado.
  5. `exceptionHandling(...)`:
     - `authenticationEntryPoint`: Se ejecuta cuando una petición no autenticada o con token ausente/inválido intenta acceder a un recurso protegido. Responde con HTTP **401 Unauthorized** y un cuerpo JSON claro: `{"status":401,"error":"Unauthorized","message":"No autenticado o token invalido/expirado"}`.
     - `accessDeniedHandler`: Se ejecuta cuando el usuario sí está autenticado pero **no posee el rol o permiso suficiente** para ejecutar la acción. Responde con HTTP **403 Forbidden** y cuerpo JSON: `{"status":403,"error":"Forbidden","message":"Acceso denegado: No posee los roles o permisos requeridos"}`.
  6. `.addFilterBefore(new JwtTokenValidator(jwtUtils), BasicAuthenticationFilter.class)`: Inserta el filtro `JwtTokenValidator` antes del filtro estándar `BasicAuthenticationFilter`, garantizando que el token sea procesado y la identidad cargada en el contexto antes de que se tomen decisiones de autorización.

- **Métodos Beans de Soporte**:
  - `authenticationManager(...)`: Expone el `AuthenticationManager` estándar de Spring para que el servicio de autenticación pueda validar credenciales (usuario y contraseña) contra la base de datos durante el login.
  - `authenticationProvider(UserDetailsService userDetailsService)`: Configura el `DaoAuthenticationProvider`, vinculando el servicio que recupera los usuarios de la base de datos (`UserDetailsService`) con el algoritmo de hash de contraseñas.
  - `passwordEncoder()`: Registra una instancia de `BCryptPasswordEncoder`, garantizando que las contraseñas se almacenen y comparen con un hash seguro con salt aleatorio.

---

### 2. `JwtUtils.java`

#### ¿Para qué sirve?

Es un componente utilitario (`@Component`) que encapsula toda la **lógica criptográfica de bajo nivel y manipulación de tokens JWT** utilizando la biblioteca externa `auth0-jwt` (`com.auth0:java-jwt`). Sus funciones son: generar y firmar digitalmente los tokens al momento del login, verificar su autenticidad e integridad temporal cuando se reciben en peticiones posteriores, y extraer de ellos los claims o atributos requeridos (como el nombre de usuario y sus roles/permisos).

#### Explicación detallada de su código:

- **Parámetros configurables (`@Value`)**:

  ```java
  @Value("${security.jwt.private.key}")
  private String privateKey;

  @Value("${security.jwt.user.generator}")
  private String userGenerator;
  ```

  Inyecta desde `application.properties` la clave secreta compartida utilizada para la firma simétrica y el nombre del emisor oficial del token (`UNIVERSIDAD-SEC`).

- **Método `createToken(Authentication authentication)`**:
  Construye el token tras una autenticación exitosa:
  1. `Algorithm algorithm = Algorithm.HMAC256(this.privateKey);`: Define el algoritmo simétrico HMAC-SHA256 con la clave secreta del sistema.
  2. `String username = authentication.getPrincipal().toString();`: Extrae el nombre de usuario autenticado.
  3. `String authorities = authentication.getAuthorities().stream().map(GrantedAuthority::getAuthority).collect(Collectors.joining(","));`: Concatena todas las autoridades (roles con prefijo `ROLE_` y permisos) en una sola cadena separada por comas.
  4. `JWT.create()...sign(algorithm)`:
     - `.withIssuer(this.userGenerator)`: Define el claim `iss` (quién emitió el token).
     - `.withSubject(username)`: Define el claim `sub` (identidad del usuario).
     - `.withClaim("authorities", authorities)`: Inserta el claim personalizado con la lista de permisos y roles.
     - `.withIssuedAt(new Date())`: Timestamp de creación (`iat`).
     - `.withExpiresAt(new Date(System.currentTimeMillis() + 1800000))`: Vencimiento a los 30 minutos (1.800.000 ms) (`exp`).
     - `.withJWTId(UUID.randomUUID().toString())`: Asigna un identificador único al token para evitar ataques de repetición (`jti`).
     - `.withNotBefore(new Date(System.currentTimeMillis() - 1000))`: Otorga una tolerancia de 1 segundo para amortiguar discrepancias mínimas de reloj entre servidores (`nbf`).
     - `.sign(algorithm)`: Firma digitalmente la cabecera y el cuerpo del token, produciendo el string en formato `Header.Payload.Signature`.

- **Método `validateToken(String token)`**:
  1. Configura un verificador `JWTVerifier` con el algoritmo HMAC256 y la clave secreta, requiriendo explícitamente que el emisor coincida con `this.userGenerator`.
  2. Ejecuta `verifier.verify(token)`: Este método valida internamente:
     - Que la firma coincida con el secreto (integridad del mensaje).
     - Que la fecha actual sea anterior a `ExpiresAt` (que no esté expirado).
     - Que la fecha actual sea posterior a `NotBefore`.
     - Que el emisor (`Issuer`) sea el configurado.
  3. Si la verificación tiene éxito, devuelve el objeto `DecodedJWT`. Si el token fue adulterado, expiró o es inválido, atrapa `JWTVerificationException` y arroja una excepción legible: `"Token invalido o expirado"`.

- **Métodos de extracción de claims**:
  - `extractUsername(DecodedJWT decodedJWT)`: Obtiene el `sub` del token decodificado.
  - `getSpecificClaim(DecodedJWT decodedJWT, String claimName)`: Obtiene un claim puntual (por ejemplo, `"authorities"`).
  - `returnAllClaims(DecodedJWT decodedJWT)`: Retorna el mapa completo de atributos contenidos en el token.

---

### 3. `JwtTokenValidator.java`

#### ¿Para qué sirve?

Es un **filtro HTTP personalizado** que extiende de `OncePerRequestFilter`. Se ubica en la tubería de entrada de peticiones de Spring Security y se ejecuta **exactamente una vez por cada solicitud HTTP**. Su propósito es interceptar la petición, inspeccionar los encabezados HTTP en busca de un token Bearer, orquestar su validación apoyándose en `JwtUtils`, y si el token es legítimo, transformar los datos del usuario en un objeto `Authentication` que se deposita en el `SecurityContextHolder`, logrando que la aplicación reconozca formalmente al usuario y sus permisos durante el ciclo de vida de esa petición.

#### Explicación detallada de su código:

```java
public class JwtTokenValidator extends OncePerRequestFilter {
    private final JwtUtils jwtUtils;
    private final SecurityContextRepository securityContextRepository = new RequestAttributeSecurityContextRepository();
    ...
}
```

- **Herencia y dependencias**:
  - Extiende `OncePerRequestFilter`, garantizando que el filtro no se ejecute múltiples veces sobre una misma petición ante reenvíos o inclusiones internas del servlet container.
  - Recibe `JwtUtils` por constructor para la verificación de tokens.
  - `RequestAttributeSecurityContextRepository`: Repositorio que almacena el contexto de seguridad como atributo del request HTTP, requerido por Spring Security 6 para asegurar la propagación correcta del contexto durante toda la solicitud.

- **Método `doFilterInternal(request, response, filterChain)`**:
  1. **Exclusión de endpoint público**:
     ```java
     String path = request.getRequestURI();
     if ("/auth/login".equals(path)) {
         filterChain.doFilter(request, response);
         return;
     }
     ```
     Verifica si la petición va dirigida al login (`/auth/login`). Si es así, no procesa tokens y cede el control inmediatamente al siguiente filtro en la cadena.
  2. **Lectura de la cabecera HTTP**:
     ```java
     String jwtToken = request.getHeader(HttpHeaders.AUTHORIZATION);
     ```
     Inspecciona el encabezado estándar `Authorization`.
  3. **Comprobación del prefijo protocolar "Bearer "**:
     ```java
     if (jwtToken != null && jwtToken.startsWith("Bearer ")) {
         jwtToken = jwtToken.substring(7); // Quita "Bearer "
         ...
     ```
     Si el header existe y sigue el esquema Bearer, descarta los primeros 7 caracteres (`"Bearer "`) para aislar la cadena pura del token. Si no existe o no tiene dicho formato, omite el bloque `if` y pasa la petición tal cual (Spring Security detectará luego la falta de autenticación y rechazará la petición si el endpoint era privado).
  4. **Validación, extracción y establecimiento del contexto**:

     ```java
     try {
         DecodedJWT decodedJWT = jwtUtils.validateToken(jwtToken);

         String username = jwtUtils.extractUsername(decodedJWT);
         String authorities = jwtUtils.getSpecificClaim(decodedJWT, "authorities").asString();

         Collection<? extends GrantedAuthority> authoritiesList =
                 AuthorityUtils.commaSeparatedStringToAuthorityList(authorities);

         SecurityContext context = SecurityContextHolder.createEmptyContext();
         Authentication authentication = new UsernamePasswordAuthenticationToken(username, null, authoritiesList);
         context.setAuthentication(authentication);
         SecurityContextHolder.setContext(context);
         securityContextRepository.saveContext(context, request, response);
     } catch (Exception e) {
         SecurityContextHolder.clearContext();
     }
     ```

     - Llama a `jwtUtils.validateToken(jwtToken)` para decodificar y validar criptográficamente el token.
     - Extrae el `username` y la lista de `authorities`.
     - Convierte la cadena separada por comas en una colección `Collection<? extends GrantedAuthority>` comprensible por Spring Security.
     - Crea un contexto de seguridad vacío (`SecurityContextHolder.createEmptyContext()`), construye el token de autenticación (`UsernamePasswordAuthenticationToken`) con el usuario y sus roles, lo almacena en el `SecurityContextHolder` y lo persiste en la petición con `securityContextRepository.saveContext(...)`.
     - **Manejo de excepciones**: Si ocurre un error (token expirado, firma alterada, formato dañado), captura la excepción y ejecuta `SecurityContextHolder.clearContext()`, garantizando que ningún dato de autenticación erróneo o residual quede asociado al hilo de ejecución actual.

  5. **Continuación de la cadena de filtros**:
     ```java
     filterChain.doFilter(request, response);
     ```
     Pasa el control al siguiente filtro para que Spring Security verifique las reglas de autorización (`hasRole`, `authenticated`, etc.).

---

### 4. ⚖️ Diferencia en la Validación: `JwtTokenValidator` vs. `JwtUtils.validateToken(...)`

Aunque ambos componentes intervienen en el proceso de validación, **operan en capas conceptuales y niveles de abstracción totalmente diferentes**, cumpliendo responsabilidades complementarias:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       JwtTokenValidator (Capa HTTP Web)                     │
│  - ¿Es la ruta /auth/login? (Omitir filtro si es login)                     │
│  - ¿Existe el header 'Authorization'?                                       │
│  - ¿Empieza con el prefijo 'Bearer '?                                       │
│  - Extrae el string del token puro y llama a validateToken                  │
│                                                                             │
│        ┌──────────────────────────────────────────────────────────────┐     │
│        │        JwtUtils.validateToken (Capa Criptográfica)           │     │
│        │  - ¿La firma HMAC256 coincide con privateKey?                │     │
│        │  - ¿El emisor coincide con userGenerator?                    │     │
│        │  - ¿El token está vigente? (exp > currentTime && nbf)        │     │
│        │  - Retorna DecodedJWT o lanza JWTVerificationException       │     │
│        └──────────────────────────────────────────────────────────────┘     │
│                                                                             │
│  - Si validateToken aprueba: Convierte authorities a GrantedAuthority       │
│  - Establece Authentication en el SecurityContextHolder de Spring Security  │
│  - Si falla: Limpia el contexto (clearContext()) y delega error a Spring    │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### Cuadro Comparativo Detallado:

| Criterio de Comparación              | `JwtTokenValidator.java`                                                                                                                                                                                                             | `JwtUtils.validateToken(String)`                                                                                                                                                                                              |
| :----------------------------------- | :----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Capa Arquitectónica**              | **Capa Web / HTTP Servlet** (`OncePerRequestFilter`).                                                                                                                                                                                | **Capa de Utilidad / Criptografía** (`@Component`).                                                                                                                                                                           |
| **Naturaleza de la Validación**      | **Validación Protocolar y de Flujo HTTP**: Verifica la estructura de la petición, presencia de cabeceras, formato del esquema Bearer y rutas excluidas.                                                                              | **Validación Criptográfica y de Integridad**: Verifica la firma digital del token, su no alteración, emisor y vigencia temporal.                                                                                              |
| **Parámetros de Entrada**            | Objetos del protocolo HTTP: `HttpServletRequest`, `HttpServletResponse`, `FilterChain`.                                                                                                                                              | Cadena de texto cruda: `String token`.                                                                                                                                                                                        |
| **Qué valida específicamente**       | 1. Que la URI no sea `/auth/login`.<br>2. Que el header `Authorization` no sea nulo.<br>3. Que comience con el prefijo `"Bearer "` textual.<br>4. Que los claims extraídos puedan deserializarse en una lista de `GrantedAuthority`. | 1. Integridad de la firma HMAC256 usando `privateKey`.<br>2. Coincidencia del claim `iss` con `userGenerator`.<br>3. Que la fecha actual no supere `ExpiresAt` (`exp`).<br>4. Que la fecha actual cumpla `NotBefore` (`nbf`). |
| **Resultado / Retorno**              | No retorna un valor (`void`); su efecto colateral es poblar el `SecurityContext` de la petición.                                                                                                                                     | Retorna una instancia de `DecodedJWT` lista para consultar claims.                                                                                                                                                            |
| **Comportamiento ante Falla**        | Captura cualquier excepción, ejecuta `SecurityContextHolder.clearContext()` para dejar al usuario como anónimo y deja que Spring Security dispare el `authenticationEntryPoint` (401 JSON).                                          | Lanza una excepción de la librería Auth0: `JWTVerificationException("Token invalido o expirado")`.                                                                                                                            |
| **Acoplamiento con Spring Security** | **Alto**: Depende directamente de `SecurityContextHolder`, `UsernamePasswordAuthenticationToken`, `GrantedAuthority` y `SecurityContextRepository`.                                                                                  | **Nulo**: Es una función de utilidad puramente algorítmica/criptográfica; no depende de la sesión de Spring Security ni de conceptos de servlets.                                                                             |

> [!NOTE]
> En síntesis: **`JwtUtils.validateToken` se encarga de determinar si el token es matemáticamente y temporalmente auténtico**, mientras que **`JwtTokenValidator` se encarga de gestionar cómo ese token viaja en una petición HTTP y cómo su validez impacta en la sesión de Spring Security**.

---

## 🔒 Matriz de Control de Acceso por Endpoint

| Endpoint                |          Método          | Regla de Autorización                                   | Acceso Permitido                             |
| :---------------------- | :----------------------: | :------------------------------------------------------ | :------------------------------------------- |
| `/auth/login`           |          `POST`          | `permitAll()`                                           | Público (Sin token)                          |
| `/api/users/**`         | `GET, POST, PUT, DELETE` | `hasRole('ADMINISTRADOR')`                              | Solo Administradores                         |
| `/api/roles/**`         | `GET, POST, PUT, DELETE` | `hasRole('ADMINISTRADOR')`                              | Solo Administradores                         |
| `/api/permissions/**`   | `GET, POST, PUT, DELETE` | `hasRole('ADMINISTRADOR')`                              | Solo Administradores                         |
| `/api/estudiantes`      |          `GET`           | `hasAnyRole('ADMINISTRADOR', 'PROFESOR', 'ESTUDIANTE')` | Administrador, Profesor y Estudiante         |
| `/api/estudiantes/{id}` |          `GET`           | `hasAnyRole('ADMINISTRADOR', 'PROFESOR', 'ESTUDIANTE')` | Administrador, Profesor y Estudiante         |
| `/api/estudiantes/**`   |   `POST, PUT, DELETE`    | `hasRole('ADMINISTRADOR')`                              | Solo Administradores                         |
| `/api/profesores`       |          `GET`           | `hasAnyRole('ADMINISTRADOR', 'PROFESOR')`               | Administrador y Profesor (Estudiante **NO**) |
| `/api/profesores/{id}`  |          `GET`           | `hasAnyRole('ADMINISTRADOR', 'PROFESOR')`               | Administrador y Profesor (Estudiante **NO**) |
| `/api/profesores/**`    |   `POST, PUT, DELETE`    | `hasRole('ADMINISTRADOR')`                              | Solo Administradores                         |
| `/api/cursos`           |          `GET`           | `hasAnyRole('ADMINISTRADOR', 'PROFESOR', 'ESTUDIANTE')` | Administrador, Profesor y Estudiante         |
| `/api/cursos/{id}`      |          `GET`           | `hasAnyRole('ADMINISTRADOR', 'PROFESOR', 'ESTUDIANTE')` | Administrador, Profesor y Estudiante         |
| `/api/cursos`           |          `POST`          | `hasRole('ADMINISTRADOR')`                              | Solo Administradores                         |
| `/api/cursos/{id}`      |          `PUT`           | `hasAnyRole('ADMINISTRADOR', 'PROFESOR')`               | Admin o **Profesor titular del curso**       |
| `/api/cursos/{id}`      |         `DELETE`         | `hasRole('ADMINISTRADOR')`                              | Solo Administradores                         |

---

## 👥 Usuarios Precargados para Pruebas (`initData`)

Al iniciar el proyecto, se cargan automáticamente en la base de datos MySQL (`tp8_plataforma`) con contraseñas cifradas con BCrypt y salts individuales:

| Usuario         | Contraseña | Rol Asignado    | Permisos Principales                                     |
| :-------------- | :--------: | :-------------- | :------------------------------------------------------- |
| `admin`         |   `1234`   | `ADMINISTRADOR` | Control total sobre todas las entidades                  |
| `profe.juan`    |   `1234`   | `PROFESOR`      | Consulta cursos/estudiantes/profesores; edita su curso 1 |
| `profe.maria`   |   `1234`   | `PROFESOR`      | Consulta cursos/estudiantes/profesores; edita su curso 2 |
| `alumno.carlos` |   `1234`   | `ESTUDIANTE`    | Consulta cursos y estudiantes disponibles                |
| `alumno.ana`    |   `1234`   | `ESTUDIANTE`    | Consulta cursos y estudiantes disponibles                |

### Cursos precargados:

- **Curso 1**: `"Programación Segura"` - Profesor asignado: `Prof. Juan Perez` (`profe.juan`).
- **Curso 2**: `"Bases de Datos"` - Profesora asignada: `Prof. Maria Lopez` (`profe.maria`).

---

## 🚀 Cómo Ejecutar el Proyecto

1. **Requisitos previos**:
   - Java 21 LTS instalado.
   - MySQL Server corriendo en el puerto `3306` con usuario `root` y contraseña `1234`. La base de datos `tp8_plataforma` se crea automáticamente.

2. **Compilar y Correr la Aplicación**:

   ```bash
   cd tpn8
   ./mvnw spring-boot:run
   ```

3. **Ejecutar la Suite de Pruebas Automatizadas**:
   ```bash
   ./mvnw test
   ```
   _(Incluye 6 pruebas de integración que verifican login, permisos de cada rol, restricción de edición de cursos y peticiones no autorizadas)._

---

## 🧪 Pruebas con Bruno API Client

La colección de Bruno se encuentra en la carpeta `tpn8/bruno` y está configurada utilizando **directamente `http://localhost:8080`** en cada petición (sin depender de `baseUrl`).

### Estructura de la Colección:

```text
tpn8/bruno/
├── 01-Autenticacion (Login)/
│   ├── 01-Login ADMIN (Obtener Token).bru               # Guarda {{token_admin}}
│   ├── 02-Login PROFESOR - Juan (Obtener Token).bru     # Guarda {{token_profesor}}
│   ├── 03-Login ESTUDIANTE - Carlos (Obtener Token).bru # Guarda {{token_estudiante}}
│   └── 04-Login Fallido - Password Incorrecta.bru       # Retorna 401 Unauthorized
├── 02-Gestion Usuarios (Ejercicio 1)/
│   ├── 01-Listar Usuarios - Token ADMIN (200 OK).bru
│   ├── 02-Listar Usuarios - Token ESTUDIANTE (403 Forbidden).bru
│   ├── 03-Crear Usuario - Token ADMIN (201 Created).bru
│   ├── 04-Crear Usuario - Token PROFESOR (403 Forbidden).bru
│   ├── 05-Listar Roles - Token ADMIN (200 OK).bru
│   └── 06-Listar Permisos - Token ADMIN (200 OK).bru
├── 03-Cursos (Ejercicio 2)/
│   ├── 01-Listar Cursos - Token ESTUDIANTE (200 OK).bru
│   ├── 02-Listar Cursos - Token PROFESOR (200 OK).bru
│   ├── 03-Crear Curso - Token ADMIN (201 Created).bru
│   ├── 04-Crear Curso - Token ESTUDIANTE (403 Forbidden).bru
│   ├── 05-Editar Curso Propio - Token PROFESOR Juan (200 OK).bru
│   ├── 06-Editar Curso Ajeno - Token PROFESOR Juan (403 Forbidden).bru
│   ├── 07-Eliminar Curso - Token PROFESOR (403 Forbidden).bru
│   └── 08-Eliminar Curso - Token ADMIN (204 No Content).bru
├── 04-Estudiantes (Ejercicio 2)/
│   ├── 01-Listar Estudiantes - Token ESTUDIANTE (200 OK).bru
│   ├── 02-Listar Estudiantes - Token PROFESOR (200 OK).bru
│   ├── 03-Crear Estudiante - Token ADMIN (201 Created).bru
│   └── 04-Crear Estudiante - Token ESTUDIANTE (403 Forbidden).bru
├── 05-Profesores (Ejercicio 2)/
│   ├── 01-Listar Profesores - Token PROFESOR (200 OK).bru
│   ├── 02-Listar Profesores - Token ESTUDIANTE (403 Forbidden).bru
│   ├── 03-Crear Profesor - Token ADMIN (201 Created).bru
│   └── 04-Crear Profesor - Token PROFESOR (403 Forbidden).bru
└── 06-Pruebas Generales de Seguridad/
    ├── 01-Acceso Sin Token (401 Unauthorized).bru
    └── 02-Acceso Con Token Invalido (401 Unauthorized).bru
```

### Guía para Probar en Bruno:

1. Abre **Bruno** y selecciona **Open Collection** -> Selecciona la carpeta `tpn8/bruno`.
2. En el menú de entornos, selecciona el entorno **Local**.
3. Ejecuta primero las peticiones de `01-Autenticacion (Login)` para guardar automáticamente en el entorno:
   - `{{token_admin}}`
   - `{{token_profesor}}`
   - `{{token_estudiante}}`
4. Ejecuta las demás carpetas: verás cómo las operaciones autorizadas responden con **200 OK** o **201 Created**, y las no autorizadas responden limpiamente con **403 Forbidden** o **401 Unauthorized** en JSON.
